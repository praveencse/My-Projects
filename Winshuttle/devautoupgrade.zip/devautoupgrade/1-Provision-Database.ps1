﻿<#.SYNOPSIS
Creates Azure Database and executes schema scripts for Given Customer and  slot
.DESCRIPTION
Creates Azure Database and runs schema scripts
Throws an exception if the creation/execution fails.
.EXAMPLE
.\Provision-Database -JsonFilePath $JsonFilePath -ProvisionAcctName -$ProvisionAcctName -SlotName $SlotName
	
.NOTES
Author:		Padma Peddigari
Version:    1.1
#>


param(
   
    [string]$JsonFilePath=$(throw "Please pass the input json file" ),
    [string]$ProvisionAcctName=$(throw "Please pass the account name for provisioning"),
    [string]$BuildVersion=$(throw "Please pass the account name for provisioning"),
    [string]$SlotName=$(throw "Please pass the account name for provisioning")

)

Function Provision-Database
{
try
{
        IF($SlotName -ne "Temp" -and $SlotName -ne "BackUp")
        {

        # reading the Json file with given username and Password

        $jsonFile=[string]::Concat("\json\",$ProvisionAcctName,"-",$SlotName,"-ProvisionData.json")
        $ProvisionData= Join-Path $JsonFilePath $jsonFile -ErrorAction Stop
        $Content= ConvertFrom-Json -InputObject (gc $ProvisionData -Raw) -ErrorAction Stop

       
        # Decrypt.exe path
        $executablesPath= Join-Path $JsonFilePath "\Executable"
        $DecryptexePath= Join-Path $executablesPath "Decrypt\Decrypt.exe"

        $subusername=$Content.'Provisioninfo'.SubscriptionUsername
        $subpassword=$Content.'Provisioninfo'.SubscriptionPassword
        $SubID=$Content.'Provisioninfo'.SubscriptionId

        # Decrypting Sunscription Username and password
        
        $Serviceusername = & $DecryptexePath 'W1n$hutt13C10ud' $subusername
        $Servicepassword = & $DecryptexePath 'W1n$hutt13C10ud' $subpassword 

        # User Id and Password to do log-in on Azure Portal.
        
        Write-Host "Disabling Azure Data Collection"

            #Disable-AzureDataCollection 

                  
            
            #$Serviceusername=$subusername;
            #$Servicepassword=$subpassword;


            $secpasswd = ConvertTo-SecureString $Servicepassword -AsPlainText -Force
            $credential = New-Object -TypeName System.Management.Automation.PSCredential ($Serviceusername, $secpasswd)
            $cred = Get-Credential -cred $credential
            Write-Host "-----------------------------------------------" -ForegroundColor Green
            Write-Host " ***** Authenticating to Azure ***** " -ForegroundColor Green
            Write-Host "-----------------------------------------------" -ForegroundColor Green
            $account = Add-AzureRmAccount -Credential $cred -ErrorAction Stop -SubscriptionId $SubID
          

        # Switch to Azure mode by using below mentioned command
        #Switch-AzureMode -Name AzureResourceManager 

        #  Execute the below mentioned query to get the required values needed to create the new azure database.
        $ServerName = $Content.'Provisioninfo'.ServerName;
        $DatabaseName = $Content.'Provisioninfo'.DatabaseName;
       
        $UserNameEn = $Content.'Provisioninfo'.UserName;
        $PasswordEn = $Content.'Provisioninfo'.Password;


        $UserName = & $DecryptexePath 'W1n$hutt13C10ud' $UserNameEn
        $Password = & $DecryptexePath 'W1n$hutt13C10ud' $PasswordEn

        $EncryptedASBQueueCredentials = $Content.'Provisioninfo'.EncryptedASBQueueCredentials;
        $QueueConfiguration = $Content.'Provisioninfo'.QueueConfiguration;
        $StartUrl = $Content.'Provisioninfo'.StartUrl + "/" + "winshuttleserver/";
       
        $DBResourceGroupName = $Content.'Provisioninfo'.DBResourceGroupName;
        #$BuildVersion=$content.'Provisioninfo'.BuildVersion;
        $buildPath=$content.'Provisioninfo'.BuildPath;
        $IsHA=$Content.Provisioninfo.IsHA;
        $SQLScriptsPath=[string]::Concat("$buildPath","\",$BuildVersion,"\Publish\Scripts\ZUpgradeScripts");
        $MaxSizeBytes=$Content.Provisioninfo.MaxSizeBytes;
        $Edition=$Content.Provisioninfo.Edition;
        $TierLevel=$Content.Provisioninfo.TierLevel;


       

        
         
                write-host "************* SUBSCRIPTION DEATILS ***************" -ForegroundColor Green
                Write-Host "Subscription UserName ::"$Serviceusername


                write-host "************* PROPERTIES FOR CREATING AZURE SQL DATABASE ***************" -ForegroundColor Green
                write-host "ServerName : "$ServerName -ForegroundColor Yellow
                write-host "DatabaseName : "$DatabaseName -ForegroundColor Yellow
                #write-host "UserName : "$UserName -ForegroundColor Yellow
                #write-host "Password : "$Password -ForegroundColor Yellow
                write-host "EncryptedASBQueueCredentials : "$EncryptedASBQueueCredentials -ForegroundColor Yellow
                write-host "QueueConfiguration : "$QueueConfiguration -ForegroundColor Yellow
                write-host "StartUrl : "$StartUrl -ForegroundColor Yellow
        
                write-host "DBResourceGroupName : "$DBResourceGroupName -ForegroundColor Yellow
                write-host "BuildVersion":$BuildVersion -ForegroundColor Yellow
                write-host "BuildPath":$buildPath -ForegroundColor Yellow
                write-host "IsHA":$IsHA -ForegroundColor Yellow
                write-host "SQLScriptsPath":$SQLScriptsPath -ForegroundColor Yellow
                write-host "MaxSizeBytes":$MaxSizeBytes -ForegroundColor Yellow
                write-host "Edition":$Edition -ForegroundColor Yellow
                write-host "TierLevel":$TierLevel -ForegroundColor Yellow

        $ifDBExists=Get-AzureRmSqlDatabase -ServerName "$ServerName" -DatabaseName "$DatabaseName" -ResourceGroupName "$DBResourceGroupName" -ErrorAction SilentlyContinue

        if ($ifDBExists -eq $null)
        {
<#            Write-Host " -------------------------------------------------------------------------" -ForegroundColor Green
            Write-host " ***** Creating New DB *****" -ForegroundColor Green
            Write-Host " ---------------------------------------------------------------------------" -ForegroundColor Green
            Write-Host "New-AzureRMSqlDatabase –ResourceGroupName $DBResourceGroupName -ServerName $ServerName -DatabaseName $DatabaseName -MaxSizeBytes $MaxSizeBytes -Edition $Edition -RequestedServiceObjectiveName $TierLevel -Collation SQL_Latin1_General_CP1_CI_AS -ErrorAction Stop" -ForegroundColor Green
                        New-AzureRMSqlDatabase –ResourceGroupName $DBResourceGroupName -ServerName $ServerName -DatabaseName $DatabaseName -MaxSizeBytes $MaxSizeBytes -Edition $Edition -RequestedServiceObjectiveName $TierLevel -Collation SQL_Latin1_General_CP1_CI_AS -ErrorAction Stop#>

                        #New-AzureRMSqlDatabase –ResourceGroupName $DBResourceGroupName -ServerName $ServerName -DatabaseName $DatabaseName -MaxSizeBytes 536870912000 -Edition Premium -Collation SQL_Latin1_General_CP1_CI_AS -ErrorAction Stop

            Write-Host " -------------------------------------------------------------------------" -ForegroundColor Green
            Write-host " ***** $DatabaseName in $ServerName does not exists. Please check ******** " -ForegroundColor Green
            Write-Host " ------------------------------------------------------------------------" -ForegroundColor Green
        }
        Else 
        {
            Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
            Write-Host " ***** DB exists ***** " -ForegroundColor Gray
            Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
        

             Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
             Write-Host " ***** Updating Sql Scripts USE [`$(DatabaseName)] with empty string and $ with ^#^ ***** " -ForegroundColor Green
             Write-Host " -------------------------------------------------------------------" -ForegroundColor Green

            Get-ChildItem "$SQLScriptsPath" *.sql* -Recurse -ErrorAction Stop | Select-Object FullName | ForEach-Object {(Get-Content $_.FullName).Replace('USE [$(DatabaseName)]',"") | Set-Content $_.FullName} -ErrorAction Stop
            Get-ChildItem "$SQLScriptsPath" *05_InsertScripts_Plugin.sql* -Recurse -ErrorAction Stop | Select-Object FullName | ForEach-Object {(Get-Content $_.FullName).Replace("$","^#^") | Set-Content $_.FullName} -ErrorAction Stop

            $AzureFirewallRuleName="ClientIP-CloudAutomation";

             Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
             Write-host " ***** Checking for firewall rule ***** "
             Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
            #$IPExists=Get-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -RuleName "ClientIP-CloudAutomation" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue -Verbose 
            $IPExists=Get-AzureRmSqlServerFirewallRule -ServerName "$ServerName" -FirewallRuleName "$AzureFirewallRuleName" -ErrorAction SilentlyContinue -ResourceGroupName $DBResourceGroupName -WarningAction SilentlyContinue


            #Write-host "At Client IP"
           #$ClienIPAddress = (Invoke-WebRequest -Uri http://myexternalip.com/raw -UseBasicParsing -ErrorAction SilentlyContinue -Method Get).Content

           $wc=New-Object net.webclient 
           #Write-host "here"
           #$ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()
           $ClienIPAddress = (New-Object net.webclient).downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]"
           #[string]$ClienIPAddress=$ClientI
            

        if($IPExists -eq $null)
        {

             Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
             Write-Host " ***** Creating Firewall Rule ***** " -ForegroundColor Green
             Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
             Write-Host "New-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -RuleName "$AzureFirewallRuleName" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue -Force" -ForegroundColor Green
                        New-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -RuleName "$AzureFirewallRuleName" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue -Force

              #write-host "New-AzureRmSqlServerFirewallRule -FirewallRuleName $AzureFirewallRuleName -ResourceGroupName $DBResourceGroupName -ServerName $ServerName -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                          #New-AzureRmSqlServerFirewallRule -FirewallRuleName $AzureFirewallRuleName -ResourceGroupName $DBResourceGroupName -ServerName $ServerName -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue
        }
        else 
        {
            Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
            Write-Host " ***** Firewall Rule  exists, Hence updating with latest IP if any ***** " -ForegroundColor Green 
            Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
            Write-host "Set-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -Rule "$AzureFirewallRuleName" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue -Force"
                        Set-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -Rule "$AzureFirewallRuleName" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue -Force
            #Write-host "Set-AzureRmSqlServerFirewallRule -FirewallRuleName $AzureFirewallRuleName -ResourceGroupName $DBResourceGroupName -ServerName $ServerName -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                       #Set-AzureRmSqlServerFirewallRule -FirewallRuleName $AzureFirewallRuleName -ResourceGroupName $DBResourceGroupName -ServerName $ServerName -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue

        }


       
            [Collections.Generic.List[String]]$SQLScripts =  [IO.Directory]::GetFiles("$SQLScriptsPath","*.*", 'AllDirectories') | Sort-Object
        foreach($file in $SQLScripts)
        {
            Write-Host "Executing ......"
            Write-Host "$file "

           
            sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -i "$file"
        }

        # Updating the tables in mentioned stored procedures on newly created database

       <# $Sqlstring ="Update ManagerSettings Set InfoValue = `'$QueueConfiguration`' where InfoKey = 'QueueConfig';" | Out-File "tempfile.sql"
        sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -Q "Update PluginPage SET Xml = REPLACE(Xml,'^#^','$');"
        sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -Q "Update PluginPage SET XSLT = REPLACE(XSLT,'^#^','$');"
        sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -Q "Update PluginPage SET LocaleXml = REPLACE(LocaleXml,'^#^','$');"
        sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -Q "Update PluginPage SET MasterDataXml = REPLACE(MasterDataXml,'^#^','$')"
        sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -Q "Update FarmConfiguration Set Value ='Enterprise' where ConfigurationKey = 'CentralMode';"
        sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -Q "Update FarmConfiguration Set Value ='1' where ConfigurationKey = 'HostAuthentication';"
        sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -Q "Update ManagerSettings Set InfoValue ='1' where InfoKey = 'DeploymentType';"
        sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -Q "Update ManagerSettings Set InfoValue ='100' where InfoKey = 'AllowedWorkers';"
        sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -Q "Update ManagerSettings Set InfoValue ='$StartUrl' where InfoKey = 'CloudServiceURL';"
        #sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -Q "Update ManagerSettings Set InfoValue ='$QueueConfiguration' where InfoKey = 'QueueConfig';"
        sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -Q "Update ManagerSettings Set InfoValue ='$EncryptedASBQueueCredentials' where InfoKey = 'QueueCredentials';"
        sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -i "tempfile.sql"
        Remove-Item -Path "tempfile.sql" #>

        

       <# Write-Host "Drop and create Site Configuration - start"
               
        $dropcfile= Join-Path $JsonFilePath "PSScripts\DropCreateSiteConfig.sql"
        sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -i "$dropcfile"
        
        Write-Host "Drop and create Site Configuration - compelte"#>



         Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
         Write-Host " ***** Deleting the Firewall Rule ***** " -ForegroundColor Green
         Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
         
         Clear-AzureProfile -Force 
         $account = Add-AzureAccount -Credential $cred -ErrorAction Stop

         Write-host "Remove-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -RuleName "$AzureFirewallRuleName""
                     Remove-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -RuleName "$AzureFirewallRuleName"


      <#  if ($IsHA -eq "True")
        {
                
                 $PairedServer = $Content.'Provisioninfo'.PairedServer;
                 
                 #$DBResourceGroupNameSecondary=[string]::Concat("Default-sql-",$Content.Provisioninfo.SecondaryLocation.Replace(" ",""));
                 $DBResourceGroupNameSecondary=$Content.Provisioninfo.SecondaryDBResourceGroup;
                 write-host "PairedServer : "$PairedServer -ForegroundColor Yellow                  
                 write-host "DBResourceGroupNameSecondary : "$DBResourceGroupNameSecondary -ForegroundColor Yellow  
                 
                                 
                #Creating Secondary DB and making it as replicating server with continous sync with Primary DB
                # ASM cmdlets
                #$RepDBExists=Get-AzureSqlDatabaseCopy -ServerName “$ServerName” -DatabaseName “$DatabaseName” -PartnerServer “$PairedServer”


                $RepDBExists=Get-AzureRmSqlDatabaseReplicationLink -PartnerResourceGroupName $DBResourceGroupNameSecondary -PartnerServerName "$PairedServer" -ResourceGroupName $DBResourceGroupName -ServerName “$ServerName” -DatabaseName “$DatabaseName” -ErrorAction SilentlyContinue
            
            if($RepDBExists -eq $null)
            {

               Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
               Write-Host " ***** Creation Replication for Primary Database **** " -ForegroundColor Green
               Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
               
               Write-host "New-AzureRmSqlDatabaseSecondary -DatabaseName “$DatabaseName” -ServerName “$ServerName” -PartnerServerName “$PairedServer” -ErrorAction Stop -PartnerResourceGroupName $DBResourceGroupNameSecondary -ResourceGroupName $DBResourceGroupName"
                           New-AzureRmSqlDatabaseSecondary -DatabaseName “$DatabaseName” -ServerName “$ServerName” -PartnerServerName “$PairedServer” -ErrorAction Stop -PartnerResourceGroupName $DBResourceGroupNameSecondary -ResourceGroupName $DBResourceGroupName
            
                # ASM cmdlets
                #Write-Host "Start-AzureSqlDatabaseCopy -ServerName “$ServerName” -DatabaseName “$DatabaseName” -PartnerServer “$PairedServer” –ContinuousCopy" -ForegroundColor Green
                            #Start-AzureSqlDatabaseCopy -ServerName “$ServerName” -DatabaseName “$DatabaseName” -PartnerServer “$PairedServer” –ContinuousCopy -ErrorAction Stop
             }
            else
            { 
                 Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
                 Write-Host " ***** Replication aleady exists ***** " -ForegroundColor Green}
                 Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
            }#>
       }

       }
        ELSE
        {
          Write-Host " !!!  No Database upgrade for $SlotName is required !!!"
        }
}
Catch [System.Exception]
{
       
        write-host "Exception Block"
		write-host $_.exception.message
        Exit 1

        
}


	

}


Provision-Database -JsonFilePath $JsonFilePath -ProvisionAcctName -$ProvisionAcctName -SlotName $SlotName
