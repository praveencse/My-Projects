﻿



Param(

    [string]$JsonPath=$(throw "Please pass Folder path to RegisterApp.exe" ),
    [string]$ProvisionAcctName=$(throw "Please pass the account name for provisioning"),
    [string]$SlotName=$(throw "Please pass SlotName"),
    [string]$Action=$(throw "Please pass To start/Stop App")
    
)

Function ManageApps
{

try
{
            $jsonFile=[string]::Concat("\json\",$ProvisionAcctName,"-",$SlotName,"-ProvisionData.json")            
            $ProvisionData= Join-Path $JsonPath $jsonFile
            $Content= ConvertFrom-Json -InputObject (gc $ProvisionData -Raw)


            # Decrypt.exe path
            $executablesPath= Join-Path $JsonPath "\Executable"
            $DecryptexePath= Join-Path $executablesPath "Decrypt\Decrypt.exe"

            $subusername=$Content.'Provisioninfo'.SubscriptionUsername
            $subpassword=$Content.'Provisioninfo'.SubscriptionPassword
            $SubID=$Content.'Provisioninfo'.SubscriptionId

            # Decrypting Sunscription Username and password
            $Serviceusername = & $DecryptexePath 'W1n$hutt13C10ud' $subusername
            $Servicepassword = & $DecryptexePath 'W1n$hutt13C10ud' $subpassword
            
            #Authenticating to Azure
            $secpasswd = ConvertTo-SecureString $Servicepassword -AsPlainText -Force
            $credential = New-Object -TypeName System.Management.Automation.PSCredential ($Serviceusername, $secpasswd)
            $cred = Get-Credential -cred $credential

            Write-Host "Authenticating to Azure" -ForegroundColor Green
            $account = Add-AzureRmAccount -Credential $cred 


            $ResourceGroupsName=$Content.Provisioninfo.ResourceGroupsName;
            $AzureSiteName=$Content.Provisioninfo.AzureSiteName;
            $IsHA=$Content.Provisioninfo.IsHA;
            

            Write-Host " RegisterAppExePath: "$RegisterAppExePath
            Write-Host " ResourceGroupsName "$ResourceGroupsName
            Write-Host " AzureSiteName: "$AzureSiteName
            Write-Host " IsHA: "$IsHA

                if ($Action -eq "Start") {
                    Start-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsName -Name $AzureSiteName -Slot $SlotName -ErrorAction Stop  | Out-Null
                    Write-Host "Started web app '$AzureSiteName::$SlotName'"
                }
                if ($Action -eq "Stop") {
                    Stop-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsName -Name $AzureSiteName -Slot $SlotName -ErrorAction Stop | Out-Null
                    Write-Host "Stopped web app '$AzureSiteName::$SlotName'"
                }

       

        IF($IsHA -eq "True")
        {
                $SecondaryWebsite=$Content.Provisioninfo.SecondaryAzureSiteName;
                $ResourceGroupsNameSecondary=$Content.Provisioninfo.ResourceGroupsNameSecondary;
        
                if ($Action -eq "Start")
                {
                    Start-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsNameSecondary -Name $SecondaryWebsite -Slot $SlotName -ErrorAction Stop  | Out-Null
                    Write-Host "Started web app '$SecondaryWebsite::$SlotName'"
                }
                if ($Action -eq "Stop") 
                {
                    Stop-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsNameSecondary -Name $SecondaryWebsite -Slot $SlotName -ErrorAction Stop | Out-Null
                    Write-Host "Stopped web app '$SecondaryWebsite::$SlotName'"
                }
           
        }
        
}
Catch [System.Exception]
{
       
        Write-Host "Exception Block"
		Write-Host $_.exception.message
        Exit 1

}
}

ManageApps -JsonPath $JsonPath -ProvisionAcctName $ProvisionAcctName -SlotName $SlotName -Action $Action