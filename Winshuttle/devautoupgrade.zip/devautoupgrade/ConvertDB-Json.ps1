﻿<#.SYNOPSIS
Update the sql scripts on newly created database with updated version.
.DESCRIPTION
This function will update the database with new uodated sql scripts.
Throws an exception if the update fails.
.EXAMPLE
.\Provision-Database -JsonFilePath $JsonFilePath -Subusername $Subusername -Subpassword $Subpassword
	
.NOTES
Author:		 Padma Peddigari
Version:    1.0
#>

PARAM(

[STRING]$Jsonpath=$(throw "Please pass the path for storing the Input Json for Porvisioning"),
[string]$AccountName=$(throw "Please pass the account name for Provisioning"),
[string]$slot=$(throw "Please pass the Slot for Provisioning")
)

Function ConvertDB
{

try
{
$executablePath= Join-Path $Jsonpath "Executable\Decrypt\Decrypt.exe"

#$connectionstring="Server=hyd-en-plp5\SQLEXPRESS;Database=Provisioning;Integrated Security=true;"
#$connectionstring="Server=HYD-EN-VSTNG3\SQLEXPRESS;Database=ProvisioningDB1;User Id=sa;Password=`$abcd1234;"
$connectionstring="Server=tcp:sqlserver-andsun.database.windows.net,1433;Initial Catalog=ProvisioningDB;Persist Security Info=False;User ID=andsunpod;Password=`$abcd1234;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30"
$Jsonpath = Join-Path $Jsonpath "Json"
$SqlConnection1 = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection1.ConnectionString = $connectionstring
$SqlCmd1 = New-Object System.Data.SqlClient.SqlCommand


$SqlCmd1.CommandText="Select st.ID,acc.Name,f.HA 'IsHA',SetupInfo.AccountId,st.Slot_name,ResourceGroupId,AzureSiteName, SiteName 'DatabaseName',sitename,
IsPrimary,TrafficeManagerName,secret,SetupInfo.Clientid,Setupinfo.WinshuttleAdmin,Setupinfo.WinshuttleAppAdmin,Setupinfo.AzureAppClientID,Setupinfo.AzureAppIDURI,
 StartUrl, ResourceGroups.Name 'ResourceGroupsName', ResourceGroups.WebHostingPlan, ST.Tier 'TierLevel', ST.MaxSizeBytes,ST.Edition, GA.Name 'Location',
 GA.CloudServiceName 'PrimaryCloudServiceName',GA.Jobcollectionname 'primaryJobcollectionname', 
 GA.WebSpace 'PrimaryWSP',SQ.Id, SQ.Name 'ServerName',SQ.UserName, SQ.Password, 
SQ.DBResourceGroupName, SB.Certificate 'SubcriptionCertificate', SB.SubscriptionId, SB.NewRelicKey,SB.UserName 'SubscriptionUsername',SB.Password 'SubscriptionPassword',
SB.Name 'SubscriptionName', SQ1.Name 'PairedServer', 
SCB.ConnectionString 'QueueConfiguration', SCB.Credential 'EncryptedASBQueueCredentials',
BV.Version 'BuildVersion', BV.Path 'BuildPath', GA1.Name 'SecondaryLocation',GA1.WebSpace 'SecondaryWSN',
GA1.DefaultResourceGroupName 'ResourceGroupsNameSecondary',
GA1.CloudServiceName 'SecondaryCloudServiceName' , GA1.Jobcollectionname 'SecondaryJobcollectionname',
d.suffixe 'Domain' ,d.CertThumbPrint, d.CertificatePassword,SetupInfo.TenancyId 'TenancyId' from SetupInfo
Inner join ResourceGroups ON SetupInfo.ResourceGroupId=ResourceGroups.ID 
Inner Join GeoLocations GA ON GA.Id= ResourceGroups.GeoLocationId 
Inner Join Subscriptions SB ON SB.Id= SB.Id 
Inner Join SqlServers SQ ON SQ.GeoLocationId= GA.Id
Inner Join SqlServers sq1 on sq1.Id=SQ.PairedSQLServerID
Inner Join ServiceBuses SCB ON SCB.GeoLocationId= GA.Id  
inner Join BuildVersions  BV on BV.ID=SetupInfo.BuildversionID
Inner Join GeoLocations GA1 on GA1.Id=sq1.Id
inner join domains d on setupinfo.domainid=d.id
inner join Accounts acc on acc.id=setupinfo.accountid
inner join slots st on st.id=SetupInfo.Slotid
inner join Fulfillment f on f .Account  = SetupInfo.AccountId
where sq.Enabled='true' and SetupInfo.ProvisioningStatusId=4 and SetupInfo.Slotid = (select id from Slots where Slot_Name ='$slot') and AccountId = (select Id from Accounts where Name='$AccountName')"

$SqlCmd1.Connection = $SqlConnection1
$SqlAdapter1 = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter1.SelectCommand = $SqlCmd1
$DataSet1 = New-Object System.Data.DataSet
$SqlAdapter1.Fill($DataSet1)
$SqlConnection1.Close()
$SQLData = $DataSet1.Tables[0]

$DataSet1.Tables[0].Rows | % {if($_.IsPrimary -eq $true) {$_.IsPrimary}}



#$dbusername= & "$executablePath" 'W1n$hutt13C10ud' $DataSet1.Tables[0].Rows[0].UserName
#$dbpassword= & "$executablePath" 'W1n$hutt13C10ud' $DataSet1.Tables[0].Rows[0].Password

#$DataSet1.Tables[0].Columns.Remove("Password")
#$DataSet1.Tables[0].Columns.Remove("UserName")

#creating a text file fot storing encypted database login password
<#$securepwdpath=Join-Path $Jsonpath ([string]::Concat($DataSet1.Tables[0].Rows[0].Name,"-",$DataSet1.Tables[0].Rows[0].Slot_name,".txt"));

if ( Test-Path -Path $securepwdpath)
{
Remove-Item -Path $securepwdpath
}
#Converting and storing the encrypted password
ConvertTo-SecureString -string $DataSet1.Tables[0].Rows[0].Password -asplaintext -force | convertfrom-securestring | out-file $securepwdpath 

$DataSet1.Tables[0].Columns.Remove("Password");#>

#($DataSet.Tables[0] | select $DataSet.Tables[0].Columns.ColumnName ) | ConvertTo-Json| Out-File D:\Padma\WSOnline\Script\demo.json

#working($DataSet1.Tables[0].Rows[0] | select $DataSet1.Tables[0].Columns.ColumnName ) | ConvertTo-Json| Out-File $Jsonpath\Intermediate.json -Force | Where-Object $_.IsPrimary -EQ $true

$DataSet1.Tables[0].Rows | select $DataSet1.Tables[0].Columns.ColumnName | Where-Object {$_.IsPrimary -eq $true} | ConvertTo-Json | Out-File $Jsonpath\Intermediate.json -Force 
# $SecondaryazureSitename=$DataSet1.Tables[0].Rows | select $DataSet1.Tables[0].Columns.ColumnName | Where-Object {$_.IsPrimary -eq $false} | Select AzureSiteName
 $SecondaryDataSet= New-Object System.Data.DataSet
 $SecondaryDataSet=$DataSet1.Tables[0].Rows | select $DataSet1.Tables[0].Columns.ColumnName | Where-Object {$_.IsPrimary -eq $false} 


$DBJson = New-Object PSObject
$x= ConvertFrom-Json -InputObject (Gc $Jsonpath\Intermediate.json -Raw)


Add-Member -InputObject $DBJson -MemberType NoteProperty -Name Provisioninfo -Value $x




<#if($DataSet1.Tables[0].Rows.Count -eq 2)
{$DBJson.Provisioninfo | Add-Member -Name IsHA -Value True -MemberType NoteProperty}
else
{$DBJson.Provisioninfo | Add-Member -Name IsHA -Value False -MemberType NoteProperty}#>
$DBJson.Provisioninfo | Add-Member -Name SecondaryAzureSiteName -Value $SecondaryDataSet.AzureSiteName -MemberType NoteProperty
$DBJson.Provisioninfo | Add-Member -Name SecondaryDBResourceGroup -Value $SecondaryDataSet.DBResourceGroupName -MemberType NoteProperty
$DBJson.Provisioninfo | Add-Member -Name SecondaryWHP -Value $SecondaryDataSet.WebHostingPlan -MemberType NoteProperty
#$DBJson.Provisioninfo | Add-Member -Name UserName -Value $dbusername -MemberType NoteProperty
#$DBJson.Provisioninfo | Add-Member -Name Password -Value $dbpassword -MemberType NoteProperty

$StatisContent= ConvertFrom-Json -InputObject (Gc (Join-Path $Jsonpath "StaticProvisioiningData.json") -Raw) -ErrorAction Stop

Add-Member -InputObject $DBJson -MemberType NoteProperty -Name StaticData -Value $StatisContent -Force

$JsonFile=[string]::Concat($AccountName,"-",$slot,"-ProvisionData.json")

Write-host "Provisioning Account :"$AccountName
Write-Host "Provisioning JsonFile path :" (Join-Path $Jsonpath $JsonFile)

# ConvertFrom-Json -InputObject (Gc $x -Raw) | Out-File $Jsonpath\ProvisionData.json
if ( Test-Path -Path (Join-Path $Jsonpath $JsonFile))
{
 Remove-Item -Path ( Join-Path $Jsonpath $JsonFile)

}
ConvertTo-Json -InputObject $DBJson -Depth 20 | out-file (Join-Path $Jsonpath $JsonFile)


#Write-Host "Updating Provisioning status for $AccountName::$slot to In-Progress -Start"

       #sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 2 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
#Write-Host "Updating Provisioning status for $AccountName::$slot to In-Progress - updated "

Remove-Item -Path (Join-Path $Jsonpath "Intermediate.json")
}

Catch [System.Exception]
{
       
        write-host "Exception Block"
		write-host $_.exception.message
throw $LASTEXITCODE

        
	}

}

ConvertDB -Jsonpath $Jsonpath -AccountName $AccountName 



