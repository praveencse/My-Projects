﻿<#
.SYNOPSIS
Creates Azure AppService Plan
.DESCRIPTION
Creates Azure AppService Plan
.EXAMPLE
.\Provision-WebHostingPlan -JsonFilePath $JsonFilePath -ProvisionAcctName -$ProvisionAcctName -SlotName $SlotName 
	
.NOTES
Author:	Padma P Peddigari	
Version:    1.1
#>


param(
   
    [string]$JsonFilePath=$(throw "Please pass the input Json ProvisionData file" ),
    [string]$ProvisionAcctName=$(throw "Please pass the account name for provisioning"),
    [string]$slotname=$(throw "Please enter the slotname")
)


Function Provision-WebHostingPlan
{

  try
  {

            # reading the Json file with given username and Password
            $jsonFile=[string]::Concat("\json\",$ProvisionAcctName,"-",$slotname,"-ProvisionData.json")
            $ProvisionData=Join-Path $JsonFilePath $jsonFile -ErrorAction Stop
            #$WebSiteResource= ConvertFrom-Json -InputObject (GC  (Join-Path $JsonFilePath "\Json\Resource.json") -Raw) -ErrorAction Stop
            $Content= ConvertFrom-Json -InputObject (gc $ProvisionData -Raw) -ErrorAction Stop


            # Decrypt.exe path
            $executablesPath= Join-Path $JsonFilePath "\Executable"
            $DecryptexePath= Join-Path $executablesPath "Decrypt\Decrypt.exe"

            $subusername=$Content.'Provisioninfo'.SubscriptionUsername
            $subpassword=$Content.'Provisioninfo'.SubscriptionPassword
            $SubID=$Content.'Provisioninfo'.SubscriptionId

            # Decrypting Sunscription Username and password           

            $Serviceusername = & $DecryptexePath 'W1n$hutt13C10ud' $subusername
            $Servicepassword = & $DecryptexePath 'W1n$hutt13C10ud' $subpassword

            
            # User Id and Password to do log-in on Azure Portal.
            #$Serviceusername=$subusername;
            #$Servicepassword=$subpassword;
            $secpasswd = ConvertTo-SecureString $Servicepassword -AsPlainText -Force
            $credential = New-Object -TypeName System.Management.Automation.PSCredential ($Serviceusername, $secpasswd)
            $cred = Get-Credential -cred $credential
            Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
            Write-Host "Authenticating to Azure" -ForegroundColor Green
            Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
            $account = Add-AzureRmAccount -Credential $cred -ErrorAction Stop -SubscriptionId $SubID

            
            
         



            # Switch to Azure mode by using below mentioned command
            #Switch-AzureMode -Name AzureResourceManager 

            #  Execute the below mentioned query to get the required values needed to create the new azure database.

            $AzureSiteName=$Content.Provisioninfo.AzureSiteName;
            $Location=$content.Provisioninfo.Location;
            $WebHostingPlan=$Content.Provisioninfo.WebHostingPlan;
            $ProviderApiVersion=$Content.StaticData.Webhosting.ProviderApiVersion;
            $ProviderNamespace=$Content.StaticData.Webhosting.ProviderNamespace;
            $WebHostingsku=$Content.StaticData.Webhosting.WebHostingsku;
            $WebHostingworkerSize="2";
            $WebHostingworkerSizeId="2";
            $WebHostingnumberOfWorkers="1";
            $webspaceName=$Content.Provisioninfo.PrimaryWSP;
            $SubscriptionName=$Content.Provisioninfo.SubscriptionName;
            $ResourceGroupsName=$Content.Provisioninfo.ResourceGroupsName;           
            $IsHA=$Content.Provisioninfo.IsHA;

            $PropertyObject=@{"sku"=$WebHostingsku;"name"=$WebHostingPlan;"workersize"=$WebHostingworkerSize;"workersizeid"=$WebHostingworkerSizeId;"numberofworkers"=$WebHostingnumberOfWorkers;"webspace"=$webspaceName} 


             Write-host " *************** *************** ******************* ******************* ******************* ******************* ******************* ******************* "
                    $wc=New-Object net.webclient            
                    $ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()
                    $IPExists=Get-AzureRmSqlServerFirewallRule -ServerName "andsunpod" -FirewallRuleName "WSCEDB-automation" -ErrorAction SilentlyContinue -ResourceGroupName "ResourceGroup_AndSun" -WarningAction SilentlyContinue

                    $wc=New-Object net.webclient 
          
                    $ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()

                    if($IPExists -eq $null)
                      {

                         Write-Host " ***** Creating Firewall Rule to uodate Provisioning Database ***** " -ForegroundColor Green            

                         Write-Host "New-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                                     New-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue
                      }
                    else 
                      {
            
                        Write-host "Set-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                                    Set-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue

                      }

                   Write-Host "Updating Provisioning status for $AccountName::$slot  -Start"

                        #sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 2 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
                        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Started::AppServicePlan' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"

                   Write-Host " Updating Provisioning status for $AccountName::$slot  - updated"

            Write-Host " *************** *************** ******************* ******************* ******************* ******************* ******************* ******************* ******************* "



            write-host " ***** PROPERTIES REQUIRED TO CREATE WEBHOSTING PLAN FOR PRIMARY WEBSITE ***** " -ForegroundColor Green 


            write-host "AzureSiteName : "$AzureSiteName -ForegroundColor Yellow
            write-host "Location : "$Location -ForegroundColor Yellow
           
            write-host "WebHostingPlan : "$WebHostingPlan -ForegroundColor Yellow
            write-host "ProviderApiVersion : "$ProviderApiVersion -ForegroundColor Yellow
            write-host "ProviderNamespace : "$ProviderNamespace -ForegroundColor Yellow
            write-host "WebHostingsku : "$WebHostingsku -ForegroundColor Yellow
            write-host "WebHostingworkerSize : "$WebHostingworkerSize -ForegroundColor Yellow
            write-host "WebHostingworkerSizeId : "$WebHostingworkerSizeId -ForegroundColor Yellow
            write-host "WebHostingnumberOfWorkers : "$WebHostingnumberOfWorkers -ForegroundColor Yellow 
            write-host "webspaceName : "$webspaceName -ForegroundColor Yellow
            write-host "SubscriptionName : "$SubscriptionName -ForegroundColor Yellow
            write-host "ResourceGroupsName : "$ResourceGroupsName -ForegroundColor Yellow
            write-host "IsHA : "$IsHA -ForegroundColor Yellow 

            #write-host "$PropertyObject=@{"sku"=$WebHostingsku;"name"=$WebHostingPlan;"workersize"=$WebHostingworkerSize;"workersizeid"=$WebHostingworkerSizeId;"numberofworkers"=$WebHostingnumberOfWorkers;"webspace"=$webspaceName}" -ForegroundColor Green
            Write-Host "PropertyObject : "$PropertyObject.Keys -ForegroundColor Yellow
            Write-Host "PropertyObject : "$PropertyObject.Values -ForegroundColor Yellow

           $serviceplanexists= Find-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType "Microsoft.Web/serverfarms" -ResourceName $WebHostingPlan -ErrorAction SilentlyContinue 

            if ($serviceplanexists -eq $null)
            {
                Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
                Write-Host " ***** Creating Web Hosting Plan /App Service Plan [Primary] : $ResourceGroupsName $WebHostingPlan $Location ***** " -ForegroundColor Green 
                Write-Host " -------------------------------------------------------------------" -ForegroundColor Green

                #$PropertyObject=@{"sku"=$WebHostingsku;"name"=$AzureSiteName;"workerSize"=$WebHostingworkerSize;"workerSizeId"=$WebHostingworkerSizeId;"numberOfWorkers"=$WebHostingnumberOfWorkers;"computermode"=$WebHostingsku;"webspace"=$webspaceName}

                Write-Host "New-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType "Microsoft.Web/serverfarms" -Name $WebHostingPlan -PropertyObject $PropertyObject -ApiVersion $ProviderApiVersion -Location "$Location" -Confirm -Force" -ForegroundColor Green 
                            New-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType "Microsoft.Web/serverfarms" -Name $WebHostingPlan -PropertyObject $PropertyObject -ApiVersion $ProviderApiVersion -Location "$Location" -Force -ErrorAction Stop
                #New-AzureRmResource -ResourceGroupName  Default-Web-EastAsia -ResourceType Microsoft.Web/serverfarms -Name wsjenkinstestwinshuttleEA -PropertyObject System.Collections.Hashtable -ApiVersion 2014-11-01 -Location "East Asia" -Force

            } 
            else 
             { 
                Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
                Write-Host " ***** App service Plan $WebHostingPlan in Region $ResourceGroupsName already exists ***** " -ForegroundColor Gray
                Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
             }

            if($IsHA -eq "True")
            {


            $webspaceNameSecondary=$Content.Provisioninfo.SecondaryWSN;           
            $ResourceGroupsNameSecondary=$Content.Provisioninfo.ResourceGroupsNameSecondary;            
            $SecondaryLocation=$Content.Provisioninfo.SecondaryLocation;
            $SecondaryWebHostingPlan=$Content.Provisioninfo.SecondaryWHP;
            

            #$PropertyObject=@{"sku"=$WebHostingsku;"name"=$AzureSiteName;"workersize"=$WebHostingworkerSize;"workersizeid"=$WebHostingworkerSizeId;"numberofworkers"=$WebHostingnumberOfWorkers;"computermode"=$WebHostingsku;"webspace"=$webspaceNameSecondary;}
            $PropertyObjectSecondary=@{"sku"=$WebHostingsku;"name"=$SecondaryWebHostingPlan;"workersize"=$WebHostingworkerSize;"workersizeid"=$WebHostingworkerSizeId;"numberofworkers"=$WebHostingnumberOfWorkers;"computermode"=$WebHostingsku;"webspace"=$webspaceNameSecondary}


            write-host " ***** PROPERTIES REQUIRED TO CREATE WEBHOSTING PLAN FOR SECONDARY WEBSITE ***** " -ForegroundColor Green 


            Write-Host "ResourceGroupsNameSecondary : "$ResourceGroupsNameSecondary -ForegroundColor Yellow
            write-host "LocationSecondary : "$SecondaryLocation -ForegroundColor Yellow
            Write-host "webspaceNameSecondary : "$webspaceNameSecondary -ForegroundColor Yellow
            Write-Host "WebHostingsku : "$WebHostingsku -ForegroundColor Yellow
            Write-Host "WebHostingworkerSize : "$WebHostingworkerSize -ForegroundColor Yellow
            Write-Host "WebHostingworkerSizeId : "$WebHostingworkerSizeId -ForegroundColor Yellow
            Write-Host "WebHostingnumberOfWorkers : "$WebHostingnumberOfWorkers -ForegroundColor Yellow
            Write-Host "ComputeMode : "$WebHostingsku -ForegroundColor Yellow
            Write-Host "WebHostingPlan : "$SecondaryWebHostingPlan -ForegroundColor Yellow
            Write-Host "ProviderApiVersion : "$ProviderApiVersion -ForegroundColor Yellow
            #Write-Host "$PropertyObject=@{"sku"=$WebHostingsku;"name"=$WebHostingPlan;"workersize"=$WebHostingworkerSize;"workersizeid"=$WebHostingworkerSizeId;"numberofworkers"=$WebHostingnumberOfWorkers;"webspace"=$webspaceNameSecondary}" -ForegroundColor Yellow
            Write-Host "PropertyObject : "$PropertyObject.Keys -ForegroundColor Yellow
            Write-Host "PropertyObject : "$PropertyObject.Values -ForegroundColor Yellow


           $serviceplanexists= Find-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -ResourceType "Microsoft.Web/serverfarms" -ResourceName $SecondaryWebHostingPlan -ErrorAction SilentlyContinue 

                if ($serviceplanexists -eq $null)
                {

                Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
                Write-Host " ***** Creating Web Hosting Plan /App Service Plan for Secondary Website: $ResourceGroupsNameSecondary $SecondaryWebHostingPlan $SecondaryLocation ***** " -ForegroundColor Green 
                Write-Host " -------------------------------------------------------------------" -ForegroundColor Green

                Write-Host "New-AzureRmResource -ResourceGroupName $ResourceGroupsNameSecondary -ResourceType Microsoft.Web/serverfarms -Name $SecondaryWebHostingPlan -PropertyObject $PropertyObjectSecondary -ApiVersion $ProviderApiVersion -Force -Location $SecondaryLocation" -ForegroundColor Green 
                            New-AzureRmResource -ResourceGroupName $ResourceGroupsNameSecondary -ResourceType Microsoft.Web/serverfarms -Name $SecondaryWebHostingPlan -PropertyObject $PropertyObjectSecondary -ApiVersion $ProviderApiVersion -Force -Location "$SecondaryLocation" -ErrorAction Stop
                }
                else{
                Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
                Write-Host " ***** App service Plan $SecondaryWebHostingPlan in Region $ResourceGroupsNameSecondary already exists ***** " -ForegroundColor Gray
                Write-Host " -------------------------------------------------------------------" -ForegroundColor Green                
                }
            }

        Write-host " *************** *************** ******************* "
                Write-Host "Updating Provisioning status for $AccountName::$slot  -Start"

                    #sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 2 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
                    sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Completed::AppServicePlan' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
                    Remove-AzureSqlDatabaseServerFirewallRule -ServerName "sqlserver-andsun" -RuleName "WSCEDB-automation"
                Write-Host " Updating Provisioning status for $AccountName::$slot  - updated"
        Write-Host " *************** *************** ******************* "
            

 }
 catch [System.Exception]
 { 
        
        
        Write-Host "Error in Provisioning AppServicePlan " -ForegroundColor DarkRed

        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 3 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Error::AppServicePlan' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Log = '$_.exception.message' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        Remove-AzureSqlDatabaseServerFirewallRule -ServerName "sqlserver-andsun" -RuleName "WSCEDB-automation"
        Write-Host "Updated Provisioning Error status for $AccountName::$slot "
        write-host "Exception Block" 
		write-host $_.exception.message
        Exit 1
 }
}

Provision-WebHostingPlan -JsonFilePath $JsonFilePath -ProvisionAcctName -$ProvisionAcctName -SlotName $SlotName





