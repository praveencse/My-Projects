﻿<#
.SYNOPSIS
Creates Azure WebApp with slots and does configuration
.DESCRIPTION
Creates Azure WebApp with slots and does configuration
Throws an exception in failure case.
.EXAMPLE
.\Provision-WebSite -JsonFilePath $JsonFilePath -ProvisionAcctName -$ProvisionAcctName -SlotName $SlotName
	
.NOTES
Author:		Padma P Peddigari
Version:    1.1
#>


param(
    
   
    [string]$JsonFilePath=$(throw "Please pass the input Json ProvisionData file" ),
    [string]$ProvisionAcctName=$(throw "Please pass the account name for provisioning"),
    [string]$SlotName=$(throw "Please pass the SlotName for $ProvisionAcctName")


)


Function Provision-WebSite
{
try
{

            # reading the Json file with given username and Password
            $jsonFile=[string]::Concat("\json\",$ProvisionAcctName,"-",$slotname,"-ProvisionData.json")
            $ProvisionData=Join-Path $JsonFilePath $jsonFile -ErrorAction Stop
            $Content= ConvertFrom-Json -InputObject (gc $ProvisionData -Raw) -ErrorAction Stop


            # Decrypt.exe path
            $executablesPath= Join-Path $JsonFilePath "\Executable"
            $DecryptexePath= Join-Path $executablesPath "Decrypt\Decrypt.exe"

            $subusername=$Content.'Provisioninfo'.SubscriptionUsername
            $subpassword=$Content.'Provisioninfo'.SubscriptionPassword
            $SubID=$Content.'Provisioninfo'.SubscriptionId

            # Decrypting Sunscription Username and password           

            $Serviceusername = & $DecryptexePath 'W1n$hutt13C10ud' $subusername
            $Servicepassword = & $DecryptexePath 'W1n$hutt13C10ud' $subpassword
            
            # User Id and Password to do log-in on Azure Portal.
                       
            #$Serviceusername=$subusername;
            #$Servicepassword=$subpassword;
            $secpasswd = ConvertTo-SecureString $Servicepassword -AsPlainText -Force
            $credential = New-Object -TypeName System.Management.Automation.PSCredential ($Serviceusername, $secpasswd)
            $cred = Get-Credential -cred $credential

            Write-Host "Authenticating to Azure" -ForegroundColor Green
            $account = Add-AzureRMAccount -Credential $cred -ErrorAction Stop -SubscriptionId $SubID

            
            

            $securepwdpath=Join-Path $JsonFilePath ([string]::Concat("json\",$Content.Provisioninfo.Name,"-",$Content.Provisioninfo.Slot_name,".txt"));
            $WebHostingPlan=$Content.'Provisioninfo'.WebHostingPlan

            # Switch to Azure mode by using below mentioned command
            #Switch-AzureMode -Name AzureResourceManager 

            #  Execute the below mentioned query to get the required values needed to create the new azure database.

            $AzureSiteName=$Content.Provisioninfo.AzureSiteName;
            $DatabaseName=$Content.Provisioninfo.DatabaseName;
           
            $ServerName=$Content.Provisioninfo.ServerName;


            #$username=$Content.Provisioninfo.UserName;

             # Decrypting sql server Username and password
             $Usernametemp=$Content.Provisioninfo.UserName
             $Passwordtemp=$Content.Provisioninfo.Password

            $UserName = & $DecryptexePath 'W1n$hutt13C10ud' $Usernametemp
            $password = & $DecryptexePath 'W1n$hutt13C10ud' $Passwordtemp
            $Location=$content.Provisioninfo.Location;
            $WebHostingPlan=$Content.Provisioninfo.WebHostingPlan;
            $ProviderApiVersion=$Content.StaticData.Webhosting.ProviderApiVersion;
            $ProviderNamespace=$Content.StaticData.Webhosting.ProviderNamespace;
            $WebHostingsku=$Content.StaticData.Webhosting.WebHostingsku;
            $WebHostingworkerSize="2";
            $WebHostingworkerSizeId="2";
            $WebHostingnumberOfWorkers="1";
            $webspaceName=$Content.Provisioninfo.PrimaryWSP;
            $SubscriptionName=$Content.Provisioninfo.SubscriptionName;
            $ResourceGroupsName=$Content.Provisioninfo.ResourceGroupsName;
            $domainsuffix=$content.Provisioninfo.Domain;
            $IsHA=$Content.Provisioninfo.IsHA;
            $WebConnectionStrings = "Server=tcp:$ServerName.database.windows.net,1433;Database=$DatabaseName;User ID=$UserName@$ServerName;Password=$Password;Trusted_Connection=False;Encrypt=True;Connection Timeout=30;"

            $CustomDomain=[string]::Concat($DatabaseName,$domainsuffix);
              
           # Adding Firewall rule for updating status in WSCE DB about provisioning Status         

           Write-host " *************** *************** ******************* "
                $wc=New-Object net.webclient            
                $ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()
                $IPExists=Get-AzureRmSqlServerFirewallRule -ServerName "andsunpod" -FirewallRuleName "WSCEDB-automation" -ErrorAction SilentlyContinue -ResourceGroupName "ResourceGroup_AndSun" -WarningAction SilentlyContinue

                $wc=New-Object net.webclient 
          
                $ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()

                if($IPExists -eq $null)
                  {

                    Write-Host " ***** Creating Firewall Rule to update Provisioning Database ***** " -ForegroundColor Green            

                    Write-Host "New-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                                New-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue
                   }
                else 
                  {
            
                    Write-host "Set-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                                Set-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue
                  }

               Write-Host "  Updating Provisioning status for $AccountName::$slot  -Start"

                    #sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 2 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
                     sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Started::AppService' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"

               Write-Host " Updating Provisioning status for $AccountName::$slot  - updated"

        Write-Host " *************** *************** ******************* "



            Write-Host "*************************DISPLAYING REQUIRED PROPERTIES TO CREATE PRIMARY WEBSITE************************" -ForegroundColor Green


            write-host "AzureSiteName : "$AzureSiteName -ForegroundColor Yellow
            Write-Host "DatabaseName : "$DatabaseName -ForegroundColor Yellow
            Write-Host "ServerName : "$ServerName -ForegroundColor Yellow
            Write-Host "username : "$username -ForegroundColor Yellow
            #Write-Host "password : "$password -ForegroundColor Yellow
            Write-Host "Location : "$Location -ForegroundColor Yellow
            write-host "WebHostingPlan : "$WebHostingPlan -ForegroundColor Yellow 
            write-host "ProviderApiVersion : "$ProviderApiVersion -ForegroundColor Yellow 
            write-host "ProviderNamespace : "$ProviderNamespace -ForegroundColor Yellow 
            write-host "WebHostingsku : "$WebHostingsku -ForegroundColor Yellow 
            write-host "WebHostingworkerSize : "$WebHostingworkerSize -ForegroundColor Yellow 
            write-host "WebHostingworkerSizeId : "$WebHostingworkerSizeId -ForegroundColor Yellow 
            write-host "WebHostingnumberOfWorkers : "$WebHostingnumberOfWorkers -ForegroundColor Yellow 
            write-host "webspaceName : "$webspaceName -ForegroundColor Yellow 
            write-host "SubscriptionName : "$SubscriptionName -ForegroundColor Yellow 
            write-host "ResourceGroupsName : "$ResourceGroupsName -ForegroundColor Yellow
            write-host "Custum Comman Domain : "$CustomDomain -ForegroundColor Yellow 
            write-host "IsHA : "$IsHA -ForegroundColor Yellow 
           


           $Emptyobj= @{}

      
            #$PropertyObject=@{"sku" = "Standard"; "webHostingPlan" = "$WebHostingPlan";"serverFarm"="$AzureSiteName";}
            $PropertyObject=@{"serverFarm"="$WebHostingPlan";}
            $VirtualApplicationObject=@{
        "VirtualApplications"=  @(
        @{"virtualPath"="/";
        "physicalPath"="site\wwwroot";
        "preloadEnabled"="False"
        "virtualDirectories"=
            @(
            @{"virtualPath"="/_ControlTemplates";
            "physicalPath"="site\wwwroot\ControlTemplates";
            },
            @{"virtualPath"="/_layouts";
            "physicalPath"="site\wwwroot\layouts";
            },
            @{"virtualPath"="/_vti_bin";
            "physicalPath"="site\wwwroot\ISAPI";
                }
            )
        }
        @{"virtualPath"="/Composer";
        "physicalPath"="site\wwwroot\Composer";
        "preloadEnabled"="False";

        }
        @{"virtualPath"="/WinshuttleServer";
        "physicalPath"="site\wwwroot\WinshuttleServer";
        "preloadEnabled"="False";
        }

        )
            }
            $AppSettingsObject=@{"CentralConnectionString"=$WebConnectionStrings;
            "WinshuttleWorkflowConnectionString"=$WebConnectionStrings;
            "ConnectionString"=$WebConnectionStrings;
            "WinshuttleServerDB"=$WebConnectionStrings;
            "NEWRELIC_LICENSEKEY"=$Content.Provisioninfo.NewRelicKey;

             "COR_ENABLE_PROFILING"=$Content.StaticData.AppSettings.COR_ENABLE_PROFILING_Value;
            "COR_PROFILER"=$Content.StaticData.AppSettings.COR_PROFILER_Value;
            "COR_PROFILER_PATH"=$Content.StaticData.AppSettings.COR_PROFILER_PATH_Value;
            "NEWRELIC_HOME"=$Content.StaticData.AppSettings.NEWRELIC_HOME_Value;
            "AppDeploymentType"="2";

            "NewRelic_AppName"=$Content.Provisioninfo.DatabaseName}


            $script:NewConnectionStringsTables = @{}
            $script:NewConnectionStringsTables.Add("SqlAzureConnectionString", @{ value = "$WebConnectionStrings" ; Type = 2 })
            $script:NewConnectionStringsTables.Add("LocalDBInstanceForDebugging", @{ value = "$WebConnectionStrings" ; Type = 2 })
            $script:NewConnectionStringsTables.Add("WinshuttleServerDB", @{ value = "$WebConnectionStrings" ; Type = 2 })


            $webappExists=Find-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType Microsoft.Web/sites -ResourceName $AzureSiteName 

            if($webappExists -eq $null)
            {
                Write-Host "Creating $AzureSiteName Primary Webapp under $ResourceGroupsName" -ForegroundColor Green
                Write-Host "New-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -Location "$Location" -ResourceType Microsoft.Web/sites -Name $AzureSiteName -PropertyObject $PropertyObject -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop" -ForegroundColor Green
                            New-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -Location "$Location" -ResourceType Microsoft.Web/sites -Name $AzureSiteName -PropertyObject $PropertyObject -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop

            }
            else {Write-Host "$AzureSiteName Primary Webapp under $ResourceGroupsName already exists" -ForegroundColor Gray}

            Set-AzureRmWebApp -ResourceGroupName $ResourceGroupsName -Name $AzureSiteName -Use32BitWorkerProcess $false -DefaultDocuments $Emptyobj -ErrorAction Stop


            Write-Host "******  Configuring $AzureSiteName Primary Website with Virtual applications ******" -ForegroundColor Green

            Write-Host "Set-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType Microsoft.Web/sites/config -ResourceName $WebHostingPlan/web -PropertyObject $VirtualApplicationObject -ApiVersion 2015-08-01 -Force -ErrorAction Stop " -ForegroundColor Green
                        Set-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType Microsoft.Web/sites/config -ResourceName $WebHostingPlan/web -PropertyObject $VirtualApplicationObject -ApiVersion 2015-08-01 -Force -ErrorAction Stop 
            
            
            Write-Host "******  Configuring $AzureSiteName Primary Website with App Setting *******" -ForegroundColor Green
            
            Write-Host "New-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType Microsoft.Web/sites/Config -Name "$AzureSiteName/appsettings" -PropertyObject $AppSettingsObject -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop" -ForegroundColor Green
                        New-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType Microsoft.Web/sites/Config -Name "$AzureSiteName/appsettings" -PropertyObject $AppSettingsObject -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop


            Write-Host "******  Configuring $AzureSiteName Primary Website with ConnectionString Settings ******" -ForegroundColor Green

            Write-Host "New-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType Microsoft.Web/sites/Config -Name "$AzureSiteName/ConnectionStrings" -PropertyObject $script:NewConnectionStringsTables -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop" -ForegroundColor Green
                        New-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType Microsoft.Web/sites/Config -Name "$AzureSiteName/ConnectionStrings" -PropertyObject $script:NewConnectionStringsTables -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop

            # checking webslot exists or not and then creating if does not exist
            $webslot=Get-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsName -Name $AzureSiteName -Slot $SlotName -ErrorAction SilentlyContinue

        
            if($webslot -eq $null)
            {
                Write-Host "****** Creating $SlotName slot for $AzureSiteName in $ResourceGroupsName ******" -ForegroundColor Green

                Write-Host "New-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsName -Name $AzureSiteName -Slot $SlotName -AppServicePlan $WebHostingPlan -ErrorAction Stop" -ForegroundColor Green
                            New-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsName -Name $AzureSiteName -Slot $SlotName -AppServicePlan $WebHostingPlan -ErrorAction Stop
   
            }  
            else {Write-Host "$SlotName for $AzureSiteName in $ResourceGroupsName already exits" -ForegroundColor Gray}

   
            Write-Host "******  Configuring App Setting for $SlotName Slot ******" -ForegroundColor Green

            write-host "Set-AzureRmWebAppSlot -AppServicePlan $WebHostingPlan -AppSettings $AppSettingsObject -Slot $SlotName -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName -ErrorAction Stop " -ForegroundColor Green
                        Set-AzureRmWebAppSlot -AppServicePlan $WebHostingPlan -AppSettings $AppSettingsObject -Slot $SlotName -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName -ErrorAction Stop 

            Write-Host "******  Configuring ConnectionString Settings for $SlotName Slot ******" -ForegroundColor Green

            Write-Host "Set-AzureRmWebAppSlot -AppServicePlan $WebHostingPlan -ConnectionStrings $script:NewConnectionStringsTables -Slot $SlotName -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName -ErrorAction Stop" -ForegroundColor Green
                        Set-AzureRmWebAppSlot -AppServicePlan $WebHostingPlan -ConnectionStrings $script:NewConnectionStringsTables -Slot $SlotName -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName -ErrorAction Stop  


            Write-Host "******** Making App and Connectionstring settings as STICKY $AzureSiteName Website ***********" -ForegroundColor Green


            Write-Host "Set-AzureRmWebAppSlotConfigName -ResourceGroupName $ResourceGroupsName -Name $AzureSiteName -AppSettingNames  "NewRelic_AppName", "NEWRELIC_HOME", "CentralConnectionString", "AppDeploymentType", "WinshuttleWorkflowConnectionString", "ConnectionString","WinshuttleServerDB","NEWRELIC_LICENSEKEY","COR_ENABLE_PROFILING","COR_PROFILER","COR_PROFILER_PATH" -ConnectionStringNames "SqlAzureConnectionString","LocalDBInstanceForDebugging","WinshuttleServerDB" -ErrorAction Stop"
                        Set-AzureRmWebAppSlotConfigName -ResourceGroupName $ResourceGroupsName -Name $AzureSiteName -AppSettingNames  "NewRelic_AppName", "NEWRELIC_HOME", "CentralConnectionString", "AppDeploymentType", "WinshuttleWorkflowConnectionString", "ConnectionString","WinshuttleServerDB","NEWRELIC_LICENSEKEY","COR_ENABLE_PROFILING","COR_PROFILER","COR_PROFILER_PATH" -ConnectionStringNames "SqlAzureConnectionString","LocalDBInstanceForDebugging","WinshuttleServerDB" -ErrorAction Stop

            <#$ConnectionStringsObject=@{

            "SqlAzureConnectionString"=@{"ConnectionString"="$WebConnectionStrings";"Type"=2}
            "LocalDBInstanceForDebugging"=@{"ConnectionString"="$WebConnectionStrings";"Type"=2};
            "WinshuttleServerDB"=@{"ConnectionString"="$WebConnectionStrings";"Type"=2}

            }#>

            <#
            Write-Host "******** Updating the App settings under $SlotName slot for $AzureSiteName Website ***********" -ForegroundColor Green

            if ($SlotName -ne 'Production')
            {
write-host "Set-AzureRmWebAppSlot -AppServicePlan $WebHostingPlan -AppSettings $AppSettingsObject -Slot $SlotName -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName -ErrorAction Stop " -ForegroundColor Green
            Set-AzureRmWebAppSlot -AppServicePlan $WebHostingPlan -AppSettings $AppSettingsObject -Slot $SlotName -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName -ErrorAction Stop 
            }
            else
            {

Write-Host "New-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType Microsoft.Web/sites/Config -Name "$AzureSiteName/appsettings" -PropertyObject $AppSettingsObject -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop" -ForegroundColor Green
            New-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType Microsoft.Web/sites/Config -Name "$AzureSiteName/appsettings" -PropertyObject $AppSettingsObject -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop

            }

            Write-Host "******** Updating the connection strings under $SlotName slot for $AzureSiteName Website  ***********" -ForegroundColor Green

            if ($SlotName -ne 'Production')
            {
Write-Host "Set-AzureRmWebAppSlot -AppServicePlan $WebHostingPlan -ConnectionStrings $script:NewConnectionStringsTables -Slot $SlotName -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName -ErrorAction Stop" -ForegroundColor Green
            Set-AzureRmWebAppSlot -AppServicePlan $WebHostingPlan -ConnectionStrings $script:NewConnectionStringsTables -Slot $SlotName -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName -ErrorAction Stop  
            }
            else
            {
Write-Host "New-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType Microsoft.Web/sites/Config -Name "$AzureSiteName/ConnectionStrings" -PropertyObject $script:NewConnectionStringsTables -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop" -ForegroundColor Green
            New-AzureRmResource -ResourceGroupName "$ResourceGroupsName" -ResourceType Microsoft.Web/sites/Config -Name "$AzureSiteName/ConnectionStrings" -PropertyObject $script:NewConnectionStringsTables -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop
            }
            #>
          
           

          if ($IsHA -eq "True")
            {

                
                $SecondaryWebsite=$Content.Provisioninfo.SecondaryAzureSiteName;
                $ResourceGroupsNameSecondary=$Content.Provisioninfo.ResourceGroupsNameSecondary;
                $SecondaLocation=$Content.Provisioninfo.SecondaryLocation;
                #$PropertyObjectSecondary=@{"sku" = $WebHostingsku; "webHostingPlan" = "$WebHostingPlan";"serverfarm"="$AzureSiteName"}
                $SecondaryWebHostingPlan=$Content.Provisioninfo.SecondaryWHP;
                $PropertyObjectSecondary=@{"serverfarm" = "$SecondaryWebHostingPlan";}

                #$SecondaryWebConnectionStrings = "Server=tcp:$ServerName.database.windows.net,1433;Database=$DatabaseName;User ID=$UserName@$ServerName;Password=$Password;Trusted_Connection=False;Encrypt=True;Connection Timeout=30;"


                

                Write-host " *****  PROPERTIES FOR CREATING SECONDARY WEBSITE  ***** " -ForegroundColor Green

                write-host "ProviderApiVersion : "$ProviderApiVersion 
                write-host "ProviderNamespace : "$ProviderNamespace 
                write-host "WebHostingsku : "$WebHostingsku 
                write-host "WebHostingworkerSize : "$WebHostingworkerSize 
                write-host "WebHostingworkerSizeId : "$WebHostingworkerSizeId 
                write-host "WebHostingnumberOfWorkers : "$WebHostingnumberOfWorkers 
                write-host "SecondaryWebsite : "$SecondaryWebsite
                write-host "ResourceGroupsNameSecondary : "$ResourceGroupsNameSecondary


                
                 $webappExists=Find-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -ResourceType Microsoft.Web/sites -ResourceName $SecondaryWebsite 

                  if($webappExists -eq $null)
                    {
                    Write-Host "****** Creating the Secondary Website ******" -ForegroundColor Green

                    Write-Host "New-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -Location "$SecondaLocation" -ResourceType Microsoft.Web/sites -Name $SecondaryWebsite -PropertyObject $PropertyObjectSecondary -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop" -ForegroundColor Green
                                New-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -Location "$SecondaLocation" -ResourceType Microsoft.Web/sites -Name $SecondaryWebsite -PropertyObject $PropertyObjectSecondary -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop

                    }
                  else {Write-Host "$SecondaryWebsite Secondary Webapp under $ResourceGroupsNameSecondary already exists" -ForegroundColor Gray}

                  Set-AzureRmWebApp -ResourceGroupName $ResourceGroupsNameSecondary -Name $SecondaryWebsite -Use32BitWorkerProcess $false -DefaultDocuments $Emptyobj -ErrorAction Stop



           Write-Host " ******  Configuring $SecondaryWebsite Secondary Website with Virtual applications ****** " -ForegroundColor Green

           Write-Host "Set-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -ResourceType Microsoft.Web/sites/config -ResourceName $SecondaryWebsite/web -PropertyObject $VirtualApplicationObject -ApiVersion 2015-08-01 -Force -ErrorAction Stop" -ForegroundColor Green
                       Set-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -ResourceType Microsoft.Web/sites/config -ResourceName $SecondaryWebsite/web -PropertyObject $VirtualApplicationObject -ApiVersion 2015-08-01 -Force -ErrorAction Stop 


                        
           Write-Host " ******  Configuring $SecondaryWebsite Secondary with App Setting ******* " -ForegroundColor Green
           
           Write-Host "New-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -ResourceType Microsoft.Web/sites/Config -Name "$SecondaryWebsite/appsettings" -PropertyObject $AppSettingsObject -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop" -ForegroundColor Green
                       New-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -ResourceType Microsoft.Web/sites/Config -Name "$SecondaryWebsite/appsettings" -PropertyObject $AppSettingsObject -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop
   

           
           Write-Host " ******  Configuring $SecondaryWebsite Secondary Website with ConnectionString Settings ****** " -ForegroundColor Green

           Write-Host "New-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -ResourceType Microsoft.Web/sites/Config -Name "$SecondaryWebsite/ConnectionStrings" -PropertyObject $script:NewConnectionStringsTables -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop" -ForegroundColor Green
                       New-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -ResourceType Microsoft.Web/sites/Config -Name "$SecondaryWebsite/ConnectionStrings" -PropertyObject $script:NewConnectionStringsTables -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop
 
           
           
           # checking webslot exists or not and then creating if does not exist
           $webslot=Get-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsNameSecondary -Name $SecondaryWebsite -Slot $SlotName -ErrorAction SilentlyContinue

           if($webslot -eq $null)
           {
            
             Write-Host "Creating $SlotName for $SecondaryWebsite in $ResourceGroupsNameSecondary" -ForegroundColor Green
       
             Write-Host "New-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsNameSecondary -Name $SecondaryWebsite -Slot $SlotName -AppServicePlan $SecondaryWebHostingPlan -ErrorAction Stop" -ForegroundColor Green
                         New-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsNameSecondary -Name $SecondaryWebsite -Slot $SlotName -AppServicePlan $SecondaryWebHostingPlan -ErrorAction Stop
           }
           else {Write-Host "$SlotName for $SecondaryWebsite in $ResourceGroupsNameSecondary already exits" -ForegroundColor Gray}



            Write-Host "***  Configuring App Setting for $SlotName Slot***" -ForegroundColor Green

            write-host "Set-AzureRmWebAppSlot -AppServicePlan $SecondaryWebHostingPlan -AppSettings $AppSettingsObject -Slot $SlotName -Name $SecondaryWebsite -ResourceGroupName $ResourceGroupsNameSecondary -ErrorAction Stop " -ForegroundColor Green
                        Set-AzureRmWebAppSlot -AppServicePlan $SecondaryWebHostingPlan -AppSettings $AppSettingsObject -Slot $SlotName -Name $SecondaryWebsite -ResourceGroupName $ResourceGroupsNameSecondary -ErrorAction Stop 

            Write-Host "***  Configuring ConnectionString Settings for $SlotName Slot***" -ForegroundColor Green

            Write-Host "Set-AzureRmWebAppSlot -AppServicePlan $SecondaryWebHostingPlan -ConnectionStrings $script:NewConnectionStringsTables -Slot $SlotName -Name $SecondaryWebsite -ResourceGroupName $ResourceGroupsNameSecondary -ErrorAction Stop" -ForegroundColor Green
                        Set-AzureRmWebAppSlot -AppServicePlan $SecondaryWebHostingPlan -ConnectionStrings $script:NewConnectionStringsTables -Slot $SlotName -Name $SecondaryWebsite -ResourceGroupName $ResourceGroupsNameSecondary -ErrorAction Stop  

            
            Write-Host "******** Making App and Connectionstring settings as STICKY $SecondaryWebsite Website ***********" -ForegroundColor Green

            Write-Host "Set-AzureRmWebAppSlotConfigName -ResourceGroupName $ResourceGroupsNameSecondary -Name $SecondaryWebsite -AppSettingNames  "NewRelic_AppName", "NEWRELIC_HOME", "CentralConnectionString", "WinshuttleWorkflowConnectionString", "ConnectionString","WinshuttleServerDB","NEWRELIC_LICENSEKEY","COR_ENABLE_PROFILING","COR_PROFILER","COR_PROFILER_PATH" -ConnectionStringNames "SqlAzureConnectionString","LocalDBInstanceForDebugging","WinshuttleServerDB" -ErrorAction Stop"
                        Set-AzureRmWebAppSlotConfigName -ResourceGroupName $ResourceGroupsNameSecondary -Name $SecondaryWebsite -AppSettingNames  "NewRelic_AppName", "NEWRELIC_HOME", "CentralConnectionString", "WinshuttleWorkflowConnectionString", "ConnectionString","WinshuttleServerDB","NEWRELIC_LICENSEKEY","COR_ENABLE_PROFILING","COR_PROFILER","COR_PROFILER_PATH" -ConnectionStringNames "SqlAzureConnectionString","LocalDBInstanceForDebugging","WinshuttleServerDB" -ErrorAction Stop

                <#
                $AppSettingsObject=@{"CentralConnectionString"=$WebConnectionStrings;`
                "WinshuttleWorkflowConnectionString"=$WebConnectionStrings;
                "ConnectionString"=$WebConnectionStrings;
                "WinshuttleServerDB"=$WebConnectionStrings;
                "NEWRELIC_LICENSEKEY"=$Content.Provisioninfo.NewRelicKey;
                "COR_ENABLE_PROFILING"=$WebSiteResource.Website.AppSettings.COR_ENABLE_PROFILING_Value;
                "COR_PROFILER"=$WebSiteResource.Website.AppSettings.COR_PROFILER_Value;
                "COR_PROFILER_PATH"=$WebSiteResource.Website.AppSettings.COR_PROFILER_PATH_Value;
                "NEWRELIC_HOME"=$WebSiteResource.Website.AppSettings.NEWRELIC_HOME_Value;
                "NewRelic_AppName"=$Content.Provisioninfo.DatabaseName}


                $script:NewConnectionStringsTables = @{}
                $script:NewConnectionStringsTables.Add("SqlAzureConnectionString", @{ value = "$WebConnectionStrings" ; Type = 2 })
                $script:NewConnectionStringsTables.Add("LocalDBInstanceForDebugging", @{ value = "$WebConnectionStrings" ; Type = 2 })
                $script:NewConnectionStringsTables.Add("WinshuttleServerDB", @{ value = "$WebConnectionStrings" ; Type = 2 })

                
            Write-Host "******** Updating the App settings under $SlotName slot for $SecondaryWebsite Website ***********" -ForegroundColor Green

            if ($SlotName -ne 'Production')
            {
write-host "Set-AzureRmWebAppSlot -AppServicePlan $WebHostingPlan -AppSettings $AppSettingsObject -Slot $SlotName -Name $SecondaryWebsite -ResourceGroupName $ResourceGroupsNameSecondary -ErrorAction Stop " -ForegroundColor Green
            Set-AzureRmWebAppSlot -AppServicePlan $WebHostingPlan -AppSettings $AppSettingsObject -Slot $SlotName -Name $SecondaryWebsite -ResourceGroupName $ResourceGroupsNameSecondary -ErrorAction Stop 
            }
            else
            {
Write-Host "New-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -ResourceType Microsoft.Web/sites/Config -Name "$SecondaryWebsite/appsettings" -PropertyObject $AppSettingsObject -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop" -ForegroundColor Green
            New-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -ResourceType Microsoft.Web/sites/Config -Name "$SecondaryWebsite/appsettings" -PropertyObject $AppSettingsObject -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop
            }
            
            Write-Host "******** Updating the connection strings under $SlotName slot for $AzureSiteName Website  ***********" -ForegroundColor Green

            if ($SlotName -ne 'Production')
            {
Write-Host "Set-AzureRmWebAppSlot -AppServicePlan $WebHostingPlan -ConnectionStrings $script:NewConnectionStringsTables -Slot $SlotName -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName -ErrorAction Stop" -ForegroundColor Green
            Set-AzureRmWebAppSlot -AppServicePlan $WebHostingPlan -ConnectionStrings $script:NewConnectionStringsTables -Slot $SlotName -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName -ErrorAction Stop  
            }
            else
            {

Write-Host "New-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -ResourceType Microsoft.Web/sites/Config -Name "$SecondaryWebsite/ConnectionStrings" -PropertyObject $script:NewConnectionStringsTables -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop" -ForegroundColor Green
            New-AzureRmResource -ResourceGroupName "$ResourceGroupsNameSecondary" -ResourceType Microsoft.Web/sites/Config -Name "$SecondaryWebsite/ConnectionStrings" -PropertyObject $script:NewConnectionStringsTables -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop
            }
            #>
          
            
            

            }



        Write-host " *************** *************** ******************* "

            Write-Host "Updating Provisioning status for $AccountName::$slot  -Start"

            #sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 2 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
            sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Completed::AppService' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"


            Write-Host " Updating Provisioning status for $AccountName::$slot  - updated"

        Write-Host " *************** *************** ******************* "

}
Catch [System.Exception]
{
       
        Write-Host "Error in Provisioning App sErvices " -ForegroundColor DarkRed

        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 3 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Error::AppService' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Log = '$_.exception.message' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        Remove-AzureSqlDatabaseServerFirewallRule -ServerName "sqlserver-andsun" -RuleName "WSCEDB-automation"
        Write-Host "Updated Provisioning Error status for $AccountName::$slot "
        write-host "Exception Block"
		write-host $_.exception.message
        Exit 1

        
	}

}

Provision-WebSite -JsonFilePath $JsonFilePath -ProvisionAcctName -$ProvisionAcctName -SlotName $SlotName
