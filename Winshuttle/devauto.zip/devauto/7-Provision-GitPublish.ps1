﻿<#.SYNOPSIS
Enable Git SourceControl for Webapp and slots and publishes code/binaries respectively.
.DESCRIPTION
Enable Git SourceControl for Webapp and slots and publishes code/binaries respectively.
Throws an exception if the fails.
.EXAMPLE
.\7-Provision-Publish -JsonFilePath $JsonFilePath -ProvisionAcctName $ProvisionAcctName -SlotName $SlotName 
	
.NOTES
Author:		Padma Peddigari
Version:    1.1
#>


param(
    
   
    [string]$JsonFilePath=$(throw "Please pass the input json file" ),
    [string]$ProvisionAcctName=$(throw "Please pass the account name for provisioning"),
    [string]$SlotName=$(throw "Please pass the SlotName")


)


Function Provision-Publish
{

try
{
            # reading the Json file with given username and Password
            $jsonFile=[string]::Concat("\json\",$ProvisionAcctName,"-",$SlotName,"-ProvisionData.json")
            $ProvisionData=Join-Path $JsonFilePath $jsonFile -ErrorAction Stop
            $Content= ConvertFrom-Json -InputObject (gc $ProvisionData -Raw) -ErrorAction Stop
            
            # Decrypting Sunscription Username and password

            $executablesPath= Join-Path $JsonFilePath "\Executable"

            $DecryptexePath= Join-Path $executablesPath "Decrypt\Decrypt.exe"

            $subusername=$Content.'Provisioninfo'.SubscriptionUsername
            $subpassword=$Content.'Provisioninfo'.SubscriptionPassword
            $SubID=$Content.'Provisioninfo'.SubscriptionId

            $Serviceusername = & $DecryptexePath 'W1n$hutt13C10ud' $subusername
            $Servicepassword = & $DecryptexePath 'W1n$hutt13C10ud' $subpassword

            
           
            $secpasswd = ConvertTo-SecureString $Servicepassword -AsPlainText -Force
            $credential = New-Object -TypeName System.Management.Automation.PSCredential ($Serviceusername, $secpasswd)
            $cred = Get-Credential -cred $credential


            Write-Host "Authenticating to azure" -ForegroundColor Green
            $account = Add-AzureRmAccount -Credential $cred -ErrorAction Stop -SubscriptionId $SubID

           
            Write-host " *************** *************** ******************* "
                    $wc=New-Object net.webclient            
                    $ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()
                    $IPExists=Get-AzureRmSqlServerFirewallRule -ServerName "andsunpod" -FirewallRuleName "WSCEDB-automation" -ErrorAction SilentlyContinue -ResourceGroupName "ResourceGroup_AndSun" -WarningAction SilentlyContinue

                    $wc=New-Object net.webclient 
          
                    $ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()

                    if($IPExists -eq $null)
                      {

                 Write-Host " ***** Creating Firewall Rule to uodate Provisioning Database ***** " -ForegroundColor Green            

                 Write-Host "New-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                             New-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue
                       }
                    else 
                      {
            
                Write-host "Set-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                            Set-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue

                        }

                   Write-Host "Updating Provisioning status for $AccountName::$slot  -Start"

                        #sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 2 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
                        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Started::PublishBinaries' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"

                   Write-Host " Updating Provisioning status for $AccountName::$slot  - updated"

           Write-Host " *************** *************** ******************* "
            
            #Reading ProvisionData json file for inputs and assining to variables

            $ProviderApiVersion= $Content.StaticData.Webhosting.ApiVersion;
            $BuildVersion=$content.'Provisioninfo'.BuildVersion;
            $BuildPath=$Content.Provisioninfo.BuildPath;
            $SourePath=[string]::Concat($BuildPath,"\",$BuildVersion,"\Publish","\Site");
            $ResourceGroupNamePrimary=$Content.Provisioninfo.ResourceGroupsName;
            $IsHA=$Content.Provisioninfo.IsHA;
            $AzureSiteName=$Content.Provisioninfo.AzureSiteName;
            $SubscriptionId=$Content.Provisioninfo.SubscriptionId;


            # Setting ResourceId for slot

            if($SlotName -ne "Production")
            {  $ResourceId = "/subscriptions/$SubscriptionId/resourcegroups/$ResourceGroupNamePrimary/providers/Microsoft.Web/sites/$AzureSiteName/slots/$SlotName/Config/web"}
            else
            {  $ResourceId ="/subscriptions/$SubscriptionId/resourcegroups/$ResourceGroupNamePrimary/providers/Microsoft.Web/sites/$AzureSiteName/Config/web"}


            # Setting SourceControl to LocalGIt 

            Write-Host "Configuring SourceControl to LocalGit to $AzureSiteName [$SlotName Slot] Primary Website" -ForegroundColor Green
            $a = Get-AzureRmResource -ResourceId $ResourceId -ApiVersion 2015-08-01
            $a.Properties.scmType = "LocalGit"
            Set-AzureRmResource -PropertyObject $a.Properties -ResourceId $ResourceId -ApiVersion $ProviderApiVersion -Force



            [xml]$xml=(Get-AzureRmWebAppSlotPublishingProfile -Name $AzureSiteName -ResourceGroupName $ResourceGroupNamePrimary -Slot $SlotName -OutputFile null )

            $username = $xml.SelectNodes("//publishProfile[@publishMethod=`"MSDeploy`"]/@userName").value
            $password = $xml.SelectNodes("//publishProfile[@publishMethod=`"MSDeploy`"]/@userPWD").value

            # Add the Azure remote to your local Git respository and push your code

            Write-Host "Initializing Git and publishing code to Primary Website for $SlotName" -ForegroundColor Green

            Write-Host "Publishing GIT URL for $AzureSiteName $SlotName Slot [Primary WebApp] : "$GITURL -ForegroundColor Yellow
            
            Set-Location $SourePath

            if(Test-Path -Path .\.git){Remove-Item -Path .\.git -Recurse -Force} else {Write-Host "No git Repo"}

            if(!(Test-Path -Path .\.git)){git init}
             Write-Host "$SlotName"

             if($SlotName -eq "Production") 
             {
            
                 git remote add $AzureSiteName "https://${username}:$password@$AzureSiteName.scm.azurewebsites.net"
                
             }
             else 
             {
             
              git remote add $AzureSiteName "https://${username}:$password@$AzureSiteName-$SlotName.scm.azurewebsites.net"
             }

            
            git  add *

            git commit -m ' Initial Provisioning '  
            git push $AzureSiteName master
            
            <#

            # CREATING GIT WINDOWS CREDENTAIL FOR PRIMARY WEBSITE
             if($SlotName -ne 'Production') 
             {
                $GitSiteName=[string]::Concat($Content.'Provisioninfo'.AzureSiteName,"-",$Content.'Provisioninfo'.Slot_name); 
                AddCred $GitSiteName
             }
             else 
             {  $GitSiteName = $Content.'Provisioninfo'.AzureSiteName;
                AddCred $GitSiteName
             }

            $GITURL= [STRING]::Concat("https://DevProvisioningUser@",$GitSiteName,".scm.azurewebsites.net:443/",$AzureSiteName,".git");
            

            Write-Host "Initializing Git and publishing code to Primary Website for $SlotName" -ForegroundColor Green

            Write-Host "Publishing GIT URL for $AzureSiteName $SlotName Slot [Primary WebApp] : "$GITURL -ForegroundColor Yellow
            
            Set-Location $SourePath

            if(Test-Path -Path .\.git){Remove-Item -Path .\.git -Recurse -Force} else {Write-Host "No git Repo"}

            if(!(Test-Path -Path .\.git)){git init}

            #git  init
             
            git  remote add $GitSiteName $GITURL
            
            git  add *

            git  commit -m ' Initial Provisioning '           

            git  push $GitSiteName master -f      
            
            Start-Sleep -Seconds 5

            DeleteCred($GitSiteName)#>
          

    if($IsHA -eq "True")
            {
             
             $SecondaryWebsite=$Content.Provisioninfo.SecondaryAzureSiteName

             $ResourceGroupsNameSecondary=$Content.Provisioninfo.ResourceGroupsNameSecondary;

             
                if($SlotName -ne "Production")
                {
            
                $ResourceId = "/subscriptions/$SubscriptionId/resourcegroups/$ResourceGroupsNameSecondary/providers/Microsoft.Web/sites/$SecondaryWebsite/slots/$SlotName/Config/web"
                }
                else
                {
                 $ResourceId ="/subscriptions/$SubscriptionId/resourcegroups/$ResourceGroupsNameSecondary/providers/Microsoft.Web/sites/$SecondaryWebsite/Config/web"
                }



               Write-Host "Configuring SourceControl to LocalGit to $SecondaryWebsite [$SlotName Slot] Secondary Website" -ForegroundColor Green

               $a2 = Get-AzureRmResource -ResourceId $ResourceId -ApiVersion $ProviderApiVersion -ErrorAction Stop

               $a2.Properties.scmType = "LocalGit"
               
               Set-AzureRmResource -PropertyObject $a.Properties -ResourceId $ResourceId -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop

                Write-Host "Initializing Git and publishing code to $SecondaryWebsite $SlotName Slot [Secondary WebApp]" -ForegroundColor Green
                 
                 [xml]$xml1=(Get-AzureRmWebAppSlotPublishingProfile -Name $SecondaryWebsite -ResourceGroupName $ResourceGroupsNameSecondary -Slot $SlotName -OutputFile null )

            $username1 = $xml1.SelectNodes("//publishProfile[@publishMethod=`"MSDeploy`"]/@userName").value
            $password1 = $xml1.SelectNodes("//publishProfile[@publishMethod=`"MSDeploy`"]/@userPWD").value

             Set-Location $SourePath

               if(Test-Path -Path .\.git){Remove-Item -Path .\.git -Recurse -Force} else {Write-Host "No git Repo"}
   
                    if(!(Test-Path -Path .\.git)){git init}

            # Add the Azure remote to your local Git respository and push your code
            if($SlotName -eq 'Production') 
                 {
                    git remote add $SecondaryWebsite "https://${username1}:$password1@$SecondaryWebsite.scm.azurewebsites.net"
                 }
                else 
                 {  git remote add $SecondaryWebsite "https://${username1}:$password1@$SecondaryWebsite-$SlotName.scm.azurewebsites.net"
                 }
            
            git  add *
            git  commit -m 'Initial Provisioning'
            git push $SecondaryWebsite master
               <#

                Write-Host "Adding Git Credential to WCM for secondary Website" -ForegroundColor Green

               if($SlotName -ne 'Production') 
                 {
                    $GitSiteName=[string]::Concat($SecondaryWebsite,"-",$Content.'Provisioninfo'.Slot_name); 
                    AddCred $GitSiteName
                 }
                else 
                 {  $GitSiteName = $SecondaryWebsite;
                    AddCred $GitSiteName
                 }
               
               $GITSecondaryURL= [STRING]::Concat("https://DevProvisioningUser@",$GitSiteName,".scm.azurewebsites.net:443/",$SecondaryWebsite,".git");

                Write-Host "Initializing Git and publishing code to $SecondaryWebsite $SlotName Slot [Secondary WebApp]" -ForegroundColor Green

                Write-Host "Publishing GIT URL for $SecondaryWebsite $SlotName Slot [Secondary WebApp] : "$GITSecondaryURL -ForegroundColor Yellow
          
                                    
               Set-Location $SourePath

               if(Test-Path -Path .\.git){Remove-Item -Path .\.git -Recurse -Force} else {Write-Host "No git Repo"}
   
                    if(!(Test-Path -Path .\.git)){git init}

                    git  remote add $SecondaryWebsite $GITSecondaryURL

                    git  add *

                    git  commit -m 'Initial Provisioning'
                    
            
                    git  push $SecondaryWebsite master -f

                    Start-Sleep -Seconds 5
                    
                    DeleteCred($GitSiteName)#>
                    

    }
     
        Write-host " *************** *************** ******************* "
        Write-Host "Updating Provisioning status for $AccountName::$slot  -Start"

            #sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 2 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
            sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Completed::PublishBinaries' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
            Remove-AzureSqlDatabaseServerFirewallRule -ServerName "sqlserver-andsun" -RuleName "WSCEDB-automation"
        Write-Host " Updating Provisioning status for $AccountName::$slot  - updated"
        Write-Host " *************** *************** ******************* "
    
}
Catch [System.Exception]
{       
        Write-Host "Error in Provisioning PublishBinaries " -ForegroundColor DarkRed

        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 3 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Error::PublishBinaries' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Log = '$_.exception.message' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        Remove-AzureSqlDatabaseServerFirewallRule -ServerName "sqlserver-andsun" -RuleName "WSCEDB-automation"
        Write-Host "Updated Provisioning Error status for $AccountName::$slot "
        
        write-host "Exception Block"
		write-host $_.exception.message
        Exit 1
        
}




}



Provision-Publish -JsonFilePath $JsonFilePath -ProvisionAcctName $ProvisionAcctName -SlotName $SlotName