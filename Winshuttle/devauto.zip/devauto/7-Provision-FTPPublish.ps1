﻿<#.SYNOPSIS
Update the sql scripts on newly created database with updated version.
.DESCRIPTION
This function will update the database with new uodated sql scripts.
Throws an exception if the update fails.
.EXAMPLE
.\CProvision-FTPPublish -JsonFilePath $JsonFilePath -username $subusername -password $subpassword 
	
.NOTES
Author:		
Version:    1.0
#>


param(
    <#
    [string]$connectionstring=$(throw "Please pass connectionstring of the Provisoin Database")
       
    #>
    [string]$subusername=$(throw "Please pass UserName"),
    [string]$subpassword=$(throw "Please pass password"),
    #[string]$IsHA=$(throw "Please pass True are False for IsHA"),
    [string]$JsonFilePath=$(throw "Please pass the input json file" ),
    [string]$ProvisionAcctName=$(throw "Please pass the account name for provisioning")

)


Function Provision-FTPPublish
{

try
{
            # User Id and Password to do log-in on Azure Portal.
            #$username = "ServiceAccountDev@wsonlinemainwinshuttle.onmicrosoft.com"
            #$password = "`$abcd123456789"
            $Serviceusername=$subusername;
            $Servicepassword=$subpassword;
            $secpasswd = ConvertTo-SecureString $Servicepassword -AsPlainText -Force
            $credential = New-Object -TypeName System.Management.Automation.PSCredential ($Serviceusername, $secpasswd)
            $cred = Get-Credential -cred $credential


            Write-Host "Authneticating to azure"
            $account = Add-AzureRmAccount -Credential $cred -ErrorAction Stop

            #Reading ProvisionData json file for inputs

            #$PSSCriptsPath="D:\Padma\WSOnline\AutomationScripts\Post"
            $jsonFile=[string]::Concat("\json\",$ProvisionAcctName,"-ProvisionData.json") 
            $ProvisionData=Join-Path $JsonFilePath $jsonFile -ErrorAction Stop
            $WebSiteResource= ConvertFrom-Json -InputObject (GC  (Join-Path $JsonFilePath "\json\Resource.json") -Raw) -ErrorAction Stop
            $Content= ConvertFrom-Json -InputObject (gc $ProvisionData -Raw) -ErrorAction Stop


            $BuildPath=$Content.Provisioninfo.BuildPath;
            #$BuildPath="D:\Padma\WSOnline\AutomationScripts\Post\11.10.00160.9221";
            $SourePath=[string]::Concat($BuildPath,"\Publish","\Site");
            $ResourceGroupNamePrimary=$Content.Provisioninfo.ResourceGroupsName;
            $WebsitePrimary=$Content.Provisioninfo.AzureSiteName;
            $IsHA=$Content.Provisioninfo.IsHA;

            if (Test-Path ([string]::Concat($BuildPath,"\Profile.xml"))) {Remove-Item -Path [string]::Concat($BuildPath,"\Profile.xml") }

            $PublishProfilePath=[string]::Concat($BuildPath,"\Profile.xml");

            Write-Host "Get-AzureRmWebAppPublishingProfile -ResourceGroupName $ResourceGroupNamePrimary -Name $WebsitePrimary -OutputFile $PublishProfilePath" 

            Get-AzureRmWebAppPublishingProfile -ResourceGroupName $ResourceGroupNamePrimary -Name $WebsitePrimary -OutputFile $PublishProfilePath -ErrorAction Stop

            $xdoc = new-object System.Xml.XmlDocument
            $xdoc=[xml] (Get-Content $PublishProfilePath)

            $FtpPublishContent=$xdoc.publishData.publishProfile | ? {$_.publishmethod -eq "FTP"}

            $publishMethod=$FtpPublishContent.publishMethod;
            $FTPpublishUrlPath=$FtpPublishContent.publishUrl;
            $FTPpublishUsername=$FtpPublishContent.userName;
            $FTPpublishpwd=$FtpPublishContent.userPWD;



            Write-Host "*********DISPLAYING PROPERTIES REQUIRED TO PUBLISH DATA TO PRIMARY WEBSITE **********" -ForegroundColor Green
            Write-Host "Primary Website : "$WebsitePrimary
            Write-Host "FTPPublishMethod : "$publishMethod
            Write-Host "FTPPublishUrlPath : "$FTPPublishUrlPath
            Write-Host "FTPPublishUserName : "$FTPPublishUsername
            Write-Host "FTPPublishPwd : "$FTPPublishpwd
            Write-Host "Build Path : "$SourePath
            Write-Host "IsHA : "$IsHA



            $webclient = New-Object System.Net.WebClient 
            $webclient.Credentials = New-Object System.Net.NetworkCredential($FTPpublishUsername,$FTPpublishpwd)  
  
            $SrcEntries = Get-ChildItem $SourePath -Recurse
            $Srcfolders = $SrcEntries | Where-Object{$_.PSIsContainer}
            $SrcFiles = $SrcEntries | Where-Object{!$_.PSIsContainer}


 
            # Create FTP Directory/SubDirectory If Needed - Start


            foreach($folder in $Srcfolders)
            {    
                #$SrcFolderPath = $UploadFolder  -replace "\\","\\" -replace "\:","\:"  
                $DesFolder = $folder.Fullname -replace [regex]::Escape($SourePath),$FTPpublishUrlPath
                $DesFolder = $DesFolder -replace "\\", "/"
                Write-Host $DesFolder
              Write-Host "Start" -BackgroundColor DarkYellow
                try
                    {
        
                        $makeDirectory = [System.Net.WebRequest]::Create($DesFolder);
                        $makeDirectory.Credentials = New-Object System.Net.NetworkCredential($FTPpublishUsername,$FTPpublishpwd);
                        $makeDirectory.Method = [System.Net.WebRequestMethods+FTP]::MakeDirectory;
                        $makeDirectory.GetResponse();
                        Write-Host "folder created successfully" -ForegroundColor Green
                    }
                catch [Net.WebException]
                    {
                        try {
                            #if there was an error returned, check if folder already existed on server
                            $checkDirectory = [System.Net.WebRequest]::Create($DesFolder);
                            $checkDirectory.Credentials = New-Object System.Net.NetworkCredential($FTPpublishUsername,$FTPpublishpwd);
                            $checkDirectory.Method = [System.Net.WebRequestMethods+FTP]::PrintWorkingDirectory;
                            $response = $checkDirectory.GetResponse();
                            Write-Host "folder already exists!" -ForegroundColor Yellow
                        }
                        catch [Net.WebException] {
                            #if the folder didn't exist
                        }
                    }
            }

            # Create FTP Directory/SubDirectory If Needed - Stop


            # Upload Files - Start

            foreach($entry in $SrcFiles)
            {
                $SrcFullname = $entry.fullname
                $SrcName = $entry.Name
                #$SrcFilePath = $UploadFolder -replace "\\","\\" -replace "\:","\:"
                $DesFile = $SrcFullname -replace [regex]::Escape($SourePath),$FTPpublishUrlPath
                $DesFile = $DesFile -replace "\\", "/"
                Write-Output "$DesFile"

                try
                {
     
  
                $uri = New-Object System.Uri($DesFile) 
    
                $webclient.UploadFile($uri, $SrcFullname)
    
                }

                catch [net.WebException]
                {
                 Write-Host "Error" -ForegroundColor Red
                }
            }

            # Upload Files - Stop

if($IsHA -eq "True")
{

                if($Content.Provisioninfo.SecondaryLocation -eq $WebSiteResource.Website.Geolocations.'East Asia'.value){
                $SecondaryWebsite= [string]::Concat($Content.Provisioninfo.DatabaseName,"winshuttle",$WebSiteResource.Website.Geolocations.'East Asia'.suffix)}
                elseif ($Content.Provisioninfo.SecondaryLocation -eq $WebSiteResource.Website.Geolocations.'East US'.value)
                {$SecondaryWebsite= [string]::Concat($Content.Provisioninfo.DatabaseName,"winshuttle",$WebSiteResource.Website.Geolocations.'East US'.suffix)}
                elseif ($Content.Provisioninfo.SecondaryLocation -eq $WebSiteResource.Website.Geolocations.'SouthEast Asia'.value)
                {$SecondaryWebsite= [string]::Concat($Content.Provisioninfo.DatabaseName,"winshuttle",$WebSiteResource.Website.Geolocations.'SouthEast Asia'.suffix)}
                elseif ($Content.Provisioninfo.SecondaryLocation -eq $WebSiteResource.Website.Geolocations.'West US'.value)
                {$SecondaryWebsite= [string]::Concat($Content.Provisioninfo.DatabaseName,"winshuttle",$WebSiteResource.Website.Geolocations.'West Asia'.suffix)}

        $ResourceGroupsNameSecondary=$Content.Provisioninfo.ResourceGroupsNameSecondary;

        if (Test-Path ([string]::Concat($BuildPath,"\ProfileSecondary.xml"))) {Remove-Item -Path [string]::Concat($BuildPath,"\ProfileSecondary.xml") }

        $PublishProfilePathSecondary=[string]::Concat($BuildPath,"\ProfileSecondary.xml");

        Write-Host "Get-AzureRmWebAppPublishingProfile -ResourceGroupName $ResourceGroupsNameSecondary -Name $SecondaryWebsite -OutputFile $PublishProfilePathSecondary"
        Get-AzureRmWebAppPublishingProfile -ResourceGroupName $ResourceGroupsNameSecondary -Name $SecondaryWebsite -OutputFile $PublishProfilePathSecondary -ErrorAction Stop
 

        $xdocSecondary = new-object System.Xml.XmlDocument
        $xdocSecondary=[xml] (Get-Content $PublishProfilePathSecondary)

        $FtpPublishContentSecondary=$xdocSecondary.publishData.publishProfile | ? {$_.publishmethod -eq "FTP"}

        $PublishMethodSecondary=$FtpPublishContentSecondary.publishMethod;
        $FTPpublishUrlPathSecondary=$FtpPublishContentSecondary.publishUrl;
        $FTPpublishUsernameSecondary=$FtpPublishContentSecondary.userName;
        $FTPpublishpwdSecondary=$FtpPublishContentSecondary.userPWD;


        
        Write-Host "*********DISPLAYING PROPERTIES REQUIRED TO PUBLISH DATA TO SECONDARY WEBSITE **********" -ForegroundColor Green

        Write-Host "FTPPublishMethod : "$PublishMethodSecondary
        Write-Host "FTPPublishUrlPath : "$FTPpublishUrlPathSecondary
        Write-Host "FTPPublishUserName : "$FTPpublishUsernameSecondary
        Write-Host "FTPPublishPwd : "$FTPpublishpwdSecondary
        Write-Host "Build Path : "$SourePath


        $webclientSecondary = New-Object System.Net.WebClient 
        $webclientSecondary.Credentials = New-Object System.Net.NetworkCredential($FTPpublishUsernameSecondary,$FTPpublishpwdSecondary)  
  
#$SrcEntries = Get-ChildItem $SourePath -Recurse
#$Srcfolders = $SrcEntries | Where-Object{$_.PSIsContainer}
#$SrcFiles = $SrcEntries | Where-Object{!$_.PSIsContainer}


        # Create FTP Directory/SubDirectory If Needed - Start
        foreach($folder in $Srcfolders)
         {    
                $SrcFolderPath = $SourePath  -replace "\\","\\" -replace "\:","\:"  
                $DesFolder = $folder.Fullname -replace $SrcFolderPath,$FTPpublishUrlPathSecondary
                $DesFolder = $DesFolder -replace "\\", "/"
                Write-Output $DesFolder
  
                try
                    {
                        $makeDirectory = [System.Net.WebRequest]::Create($DesFolder);
                        $makeDirectory.Credentials = New-Object System.Net.NetworkCredential($FTPpublishUsernameSecondary,$FTPpublishpwdSecondary);
                        $makeDirectory.Method = [System.Net.WebRequestMethods+FTP]::MakeDirectory;
                        $makeDirectory.GetResponse();
                        Write-Host "folder created successfully" -ForegroundColor Green
                    }
                catch [Net.WebException]
                    {
                        try {
                            #if there was an error returned, check if folder already existed on server
                            $checkDirectory = [System.Net.WebRequest]::Create($DesFolder);
                            $checkDirectory.Credentials = New-Object System.Net.NetworkCredential($FTPpublishUsernameSecondary,$FTPpublishpwdSecondary);
                            $checkDirectory.Method = [System.Net.WebRequestMethods+FTP]::PrintWorkingDirectory;
                            $response = $checkDirectory.GetResponse();
                            Write-Host "folder already exists!" -ForegroundColor Yellow
                        }
                        catch [Net.WebException] {
                            #if the folder didn't exist
                        }
                    }
           }
        # Create FTP Directory/SubDirectory If Needed - Stop


# Upload Files - Start

foreach($entry in $SrcFiles)
{
    $SrcFullname = $entry.fullname
    $SrcName = $entry.Name
    #$SrcFilePath = $UploadFolder -replace "\\","\\" -replace "\:","\:"
    $DesFile = $SrcFullname -replace [regex]::Escape($SourePath),$FTPpublishUrlPathSecondary
    $DesFile = $DesFile -replace "\\", "/"
    Write-Host "Copying : $DesFile" -ForegroundColor Yellow

    try
    {
  
    $uri = New-Object System.Uri($DesFile) 
    $webclientSecondary.UploadFile($uri, $SrcFullname)
    Write-Host "File copied" -ForegroundColor Green
    }

    catch [net.WebException]
    {
     Write-Host "Error" -ForegroundColor Red
    }
}
# Upload Files - Stop
  

}
}
Catch [System.Exception]
{
       
        write-host "Exception Block"
		write-host $_.exception.message
 exit 1

        
	}

}

#Provision-FTPPublish -IsHA $IsHA -JsonFilePath $JsonFilePath -username $subusername -password $subpassword
Provision-FTPPublish -JsonFilePath $JsonFilePath -username $subusername -password $subpassword