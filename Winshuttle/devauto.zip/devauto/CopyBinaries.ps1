﻿<#.SYNOPSIS
Checks and copies binaries from Shared path to Jenkins server
.DESCRIPTION
Checks and copies binaries from Shared path to Jenkins server
Throws an exception if the creation/execution fails.
.EXAMPLE
.\CopyBinaries
	
.NOTES
Author:		Padma Peddigari
Version:    1.0
#>


param(
   
     [string]$JsonFilePath=$(throw "Please pass the input json file" ),
    [string]$ProvisionAcctName=$(throw "Please pass the account name for provisioning"),
    [string]$SlotName=$(throw "Please pass the account name for provisioning")
   
)

Function CopyBinaries
{
try
{
        $jsonFile=[string]::Concat("\json\",$ProvisionAcctName,"-",$SlotName,"-ProvisionData.json")
        $ProvisionData= Join-Path $JsonFilePath $jsonFile -ErrorAction Stop
        $Content= ConvertFrom-Json -InputObject (gc $ProvisionData -Raw) -ErrorAction Stop

        [string]$centralPath="\\10.26.1.19\Builds\TeamCity\winshuttle\products\WinshuttleCloud";
        
        $BuildVersion=$Content.'Provisioninfo'.BuildVersion;
        $BuildPath=$Content.'Provisioninfo'.BuildPath;

        $SourcePath= Join-Path $centralPath $BuildVersion -ErrorAction Stop
#        [string]$DestinationPath = join-path "C:\Program Files\Winshuttle\Builds" $BuildVersion -ErrorAction Stop
        [string]$DestinationPath = join-path $BuildPath $BuildVersion -ErrorAction Stop


        if(Test-Path -Path $SourcePath)
        {
                    if(Test-Path -Path $DestinationPath)
                    {
                    Write-Host "Binaries Already Exists " -ForegroundColor Green

                    }
                    else
                    {
                        Write-Host "Copying binaries from " -ForegroundColor Green
                        Write-Host "SourcePath :" $SourcePath -ForegroundColor Green
                        Write-Host "Destination Path :" $DestinationPath -ForegroundColor Green

                        Copy-Item -Path $SourcePath -Destination "C:\Program Files\Winshuttle\Builds\$env:BuildVersion" -Recurse -Force

                        Write-Host "Successfully Copied" -ForegroundColor Green
                    }

        }
else {Write-host "Please check the whether given Build Version exists" -ForegroundColor Red}
       

       
        
}
Catch [System.Exception]
{
       
        write-host "Exception Block"
		write-host $_.exception.message
        throw $LASTEXITCODE

}


	

}


CopyBinaries