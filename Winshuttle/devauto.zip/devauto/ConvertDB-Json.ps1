﻿<#.SYNOPSIS
Will Query Database to fetch the account which needs to be provisioned.
.DESCRIPTION
This function will update the database with new uodated sql scripts.
Throws an exception if the update fails.
.EXAMPLE
.\Provision-Database -JsonFilePath $JsonFilePath 
.NOTES
Author:		 Padma Peddigari
Version:    1.1
#>

PARAM(

[STRING]$Jsonpath=$(throw "Please pass the path for storing the Input Json for Porvisioning")

)

Function ConvertDB
{

try
{

        $Path=$Jsonpath;
#        $connectionstring="Server=hyd-en-plp5\SQLEXPRESS;Database=Provisioning;Integrated Security=true;"
#        $connectionstring="Server=hyd-en-plp5\SQLEXPRESS;Database=Provisioning;User Id=demo1;Password=$abcd1234"
        $connectionstring="Server=tcp:sqlserver-andsun.database.windows.net,1433;Initial Catalog=ProvisioningDB;Persist Security Info=False;User ID=andsunpod;Password=`$abcd1234;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30"
          Write-host " *************** *************** ******************* "
                    $wc=New-Object net.webclient            
                    $ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()
                    $IPExists=Get-AzureRmSqlServerFirewallRule -ServerName "andsunpod" -FirewallRuleName "WSCEDB-automation" -ErrorAction SilentlyContinue -ResourceGroupName "ResourceGroup_AndSun" -WarningAction SilentlyContinue

                    $wc=New-Object net.webclient 
          
                    $ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()

                    if($IPExists -eq $null)
                      {

                 Write-Host " ***** Creating Firewall Rule to update Provisioning Database ***** " -ForegroundColor Green            

                 Write-Host "New-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                             New-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue
                       }
                    else 
                      {
            
                Write-host "Set-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                            Set-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue

                        }

                   Write-Host "Updating Provisioning status for $AccountName::$slot  -Start"

                        #sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 2 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
                        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Started::Json' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"

                   Write-Host " Updating Provisioning status for $AccountName::$slot  - updated"

            Write-Host " *************** *************** ******************* "


        $Jsonpath = Join-Path $Jsonpath "Json"
        $SqlConnection1 = New-Object System.Data.SqlClient.SqlConnection
        $SqlConnection1.ConnectionString = $connectionstring
        $SqlCmd1 = New-Object System.Data.SqlClient.SqlCommand
        $SqlCmd2 = New-Object System.Data.SqlClient.SqlCommand
        $SqlCmd3 = New-Object System.Data.SqlClient.SqlCommand
        
        
        $sqlcmd2.CommandText="select ACT.Name, ACT.Id, FF.Opportunity, SI.Slotid, FF.HA, ST.Slot_Name, SUB.Password, sub.UserName
from
	Accounts ACT,
	Fulfillment FF,
	SetupInfo SI,
	ProvisioningStatus PS,
	Slots ST,
	Subscriptions SUB
where
		ACT.Id = FF.Account
and		FF.Account = SI.AccountId
and     st.ID=SI.Slotid 
and		SI.IsPrimary = 1
and     SUB.Id=SI.SubscriptionId
and		SI.ProvisioningStatusId = PS.ProvisioningStatusId
and		PS.Status = 'Pending'"
        $SqlCmd2.Connection=$SqlConnection1
        $SqlAdapter2= New-Object System.Data.SqlClient.SqlDataAdapter
        $SqlAdapter2.SelectCommand=$SqlCmd2
        $AccountSlotData = New-Object System.Data.DataSet
        $SqlAdapter2.Fill($AccountSlotData)

        $SqlCmd3.CommandText="select *
from 
( 
select [Key], Value from Configuration)d
PIVOT(min(Value)
for [Key] in (ConnectURL,ConnectACSURL,SpnDisplayName,ConnectServiceIdUser,ConnectServiceIdPassword,ProviderApiVersion,ProviderNamespace,WebHostingskey,workerSize,workerSizeId,numberOfWorkers,ApiVersion,NEWRELIC_HOME_Value,COR_PROFILER_PATH_Value,COR_PROFILER_Value,COR_ENABLE_PROFILING_Value)
) as result;";
        $SqlCmd3.Connection=$SqlConnection1;
        $SqlAdapter3= New-Object System.Data.SqlClient.SqlDataAdapter;
        $SqlAdapter3.SelectCommand=$SqlCmd3;
        $ConfigurationtblData = New-Object System.Data.DataSet
        $SqlAdapter3.Fill($ConfigurationtblData)

        for($a=0;$a -lt $AccountSlotData.Tables[0].Rows.Count;$a++)
        {
        $slotId=$AccountSlotData.Tables[0].Rows[$a].Slotid;
        $slotName=$AccountSlotData.Tables[0].Rows[$a].Slot_Name;
        $accountID=$AccountSlotData.Tables[0].Rows[$a].Id;
        $accountName=$AccountSlotData.Tables[0].Rows[$a].Name;
        $AcctIsHA=$AccountSlotData.Tables[0].Rows[$a].HA;
        $subscriptionUsername=$AccountSlotData.Tables[0].Rows[$a].UserName;
        $subscriptionPassword=$AccountSlotData.Tables[0].Rows[$a].Password;

        $SqlCmd1.CommandText="Select st.ID,acc.Name,f.HA,SetupInfo.AccountId,st.Slot_name,ResourceGroupId,AzureSiteName, SiteName 'DatabaseName',
        IsPrimary,TrafficeManagerName,secret,SetupInfo.Clientid,Setupinfo.WinshuttleAdmin,Setupinfo.WinshuttleAppAdmin,
         StartUrl, ResourceGroups.Name 'ResourceGroupsName', ResourceGroups.WebHostingPlan, ST.Tier 'TierLevel', ST.MaxSizeBytes,ST.Edition, GA.Name 'Location',
         GA.CloudServiceName 'PrimaryCloudServiceName',GA.Jobcollectionname 'primaryJobcollectionname', 
         GA.WebSpace 'PrimaryWSP',SQ.Id, SQ.Name 'ServerName',SQ.UserName, SQ.Password, 
        SQ.DBResourceGroupName, SB.Certificate 'SubcriptionCertificate', SB.SubscriptionId, SB.NewRelicKey,
        SB.Name 'SubscriptionName', SQ1.Name 'PairedServer', 
        SCB.ConnectionString 'QueueConfiguration', SCB.Credential 'EncryptedASBQueueCredentials',
        BV.Version 'BuildVersion', BV.Path 'BuildPath', GA1.Name 'SecondaryLocation',GA1.WebSpace 'SecondaryWSN',
        GA1.DefaultResourceGroupName 'ResourceGroupsNameSecondary',
        GA1.CloudServiceName 'SecondaryCloudServiceName' , GA1.Jobcollectionname 'SecondaryJobcollectionname',
        d.suffixe 'Domain' ,d.CertThumbPrint, SetupInfo.TenancyId 'TenancyId' from SetupInfo
        Inner join ResourceGroups ON SetupInfo.ResourceGroupId=ResourceGroups.ID 
        Inner Join GeoLocations GA ON GA.Id= ResourceGroups.GeoLocationId 
        Inner Join Subscriptions SB ON SB.Id= SB.Id 
        Inner Join SqlServers SQ ON SQ.GeoLocationId= GA.Id
        Inner Join SqlServers sq1 on sq1.Id=SQ.PairedSQLServerID
        Inner Join ServiceBuses SCB ON SCB.GeoLocationId= GA.Id  
        inner Join BuildVersions  BV on BV.ID=SetupInfo.BuildversionID
        Inner Join GeoLocations GA1 on GA1.Id=sq1.Id
        inner join domains d on setupinfo.domainid=d.id
        inner join Accounts acc on acc.id=setupinfo.accountid
        inner join slots st on st.id=SetupInfo.Slotid
        inner join Fulfillment f on f .Account  = SetupInfo.AccountId
        where sq.Enabled='true' and SetupInfo.Slotid = $slotId and AccountId = $accountID"
        $SqlCmd1.Connection = $SqlConnection1
        $SqlAdapter1 = New-Object System.Data.SqlClient.SqlDataAdapter
        $SqlAdapter1.SelectCommand = $SqlCmd1
        $DataSet1 = New-Object System.Data.DataSet
        $SqlAdapter1.Fill($DataSet1)
        
                
        $DataSet1.Tables[0].Rows | select $DataSet1.Tables[0].Columns.ColumnName | Where-Object {$_.IsPrimary -eq $true} | ConvertTo-Json | out-file $Jsonpath\Intermediate.json -Force
                         
        $DBJson = New-Object PSObject

        $x= ConvertFrom-Json -InputObject (Gc $Jsonpath\Intermediate.json -Raw)
        Add-Member -InputObject $DBJson -MemberType NoteProperty -Name Provisioninfo -Value $x

        $ConfigurationtblData.Tables[0].Rows | select  $ConfigurationtblData.Tables[0].Columns.ColumnName | ConvertTo-Json | Out-File $Jsonpath\Intermediate.json
        $y=ConvertFrom-Json -InputObject (Gc $Jsonpath\Intermediate.json -Raw)
        Add-Member -InputObject $DBJson -MemberType NoteProperty -Name Configuration -Value $y

                if($DataSet1.Tables[0].Rows[$a].HA -eq $true)
                {
                    $SecondaryDataSet= New-Object System.Data.DataSet
                    $SecondaryDataSet=$DataSet1.Tables[0].Rows | select $DataSet1.Tables[0].Columns.ColumnName | Where-Object {$_.IsPrimary -eq $false} 
                    
                    $DBJson.Provisioninfo | Add-Member -Name SecondaryAzureSiteName -Value $SecondaryDataSet.AzureSiteName -MemberType NoteProperty
                    $DBJson.Provisioninfo | Add-Member -Name SecondaryDBResourceGroup -Value $SecondaryDataSet.DBResourceGroupName -MemberType NoteProperty
                }

        $DBJson.Provisioninfo | Add-Member -Name SubscriptionUsername -Value $subscriptionUsername -MemberType NoteProperty
        $DBJson.Provisioninfo | Add-Member -Name SubscriptionPassword -Value $subscriptionPassword -MemberType NoteProperty

        $StatisContent= ConvertFrom-Json -InputObject (Gc (Join-Path $Jsonpath "StaticProvisioiningData.json") -Raw) -ErrorAction Stop

        Add-Member -InputObject $DBJson -MemberType NoteProperty -Name StaticData -Value $StatisContent -Force

        $JsonFile=[string]::Concat($accountName,"-",$slotName,"-ProvisionData.json")

        Write-host "Provisioning Account :"$accountName
        Write-Host "For Slot :: "$slotName
        Write-Host "Provisioning JsonFile path :" (Join-Path $Jsonpath $JsonFile)

        # trigger jenkins job for above account and slot with data from Json file
        # call jenkins job

        Set-Location (Join-Path $Path "Executable")
        & java -jar jenkins-cli.jar -s http://10.26.224.64:8080/ build test -p PrintV="$slotName-$accountName" --username centraluser --password "`$abcd1234"


        

            # ConvertFrom-Json -InputObject (Gc $x -Raw) | Out-File $Jsonpath\ProvisionData.json
            if ( Test-Path -Path (Join-Path $Jsonpath $JsonFile))
            {
             Remove-Item -Path ( Join-Path $Jsonpath $JsonFile)

            }
        ConvertTo-Json -InputObject $DBJson -Depth 50 | out-file (Join-Path $Jsonpath $JsonFile)

        Write-Host "Updating Provisioning status for $AccountName::$slot to In-Progress -Start"

            sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 2 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
            sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Completed::Json' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
            Remove-AzureSqlDatabaseServerFirewallRule -ServerName "sqlserver-andsun" -RuleName "WSCEDB-automation"
        Write-Host "Updating Provisioning status for $AccountName::$slot to In-Progress - updated"

        Remove-Item -Path (Join-Path $Jsonpath "Intermediate.json")
}


$SqlConnection1.Close()

}

Catch [System.Exception]
{
        
        Write-Host "Error in preparing Json" -ForegroundColor DarkRed

        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 3 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Error::Json' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Log = '$_.exception.message' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        Remove-AzureSqlDatabaseServerFirewallRule -ServerName "sqlserver-andsun" -RuleName "WSCEDB-automation"
        Write-Host "Updated Provisioning Error status for $AccountName::$slot "
        
        write-host "Exception Block"
		write-host $_.exception.message
        exit 1

        
	}

}

ConvertDB -Jsonpath $Jsonpath 



