﻿<#
.SYNOPSIS
Adds custom Domain to the Webapps along SSL Binding.
.DESCRIPTION
Adds custom Domain to the Webapps along SSL Binding.
Throws an exception if fails.
.EXAMPLE
.\Provision-UpdateCustomDomain -JsonFilePath $JsonFilePath -ProvisionAcctName $ProvisionAcctName -SlotName $SlotName
	
.NOTES
Author:		Padma P Peddigari
Version:    1.1
#>


param(
   
   
    [string]$JsonFilePath=$(throw "Please pass the input Json ProvisionData file" ),
    [string]$ProvisionAcctName=$(throw "Please pass the account name for provisioning"),
    [string]$SlotName=$(throw "Please pass the SlotName")

)


Function Provision-UpdateCustomDomain
{
    try
    {
            $certPassword='W!n$huttl3'
            # reading the Json file with given username and Password
            $jsonFile=[string]::Concat("\json\",$ProvisionAcctName,"-",$SlotName,"-ProvisionData.json")
            $ProvisionData=Join-Path $JsonFilePath $jsonFile -ErrorAction Stop
            $Content= ConvertFrom-Json -InputObject (gc $ProvisionData -Raw)

            # Decrypting Sunscription Username and password
            $executablesPath= Join-Path $JsonFilePath "\Executable"
            $DecryptexePath= Join-Path $executablesPath "Decrypt\Decrypt.exe"

            $subusername=$Content.'Provisioninfo'.SubscriptionUsername
            $subpassword=$Content.'Provisioninfo'.SubscriptionPassword
            $SubID=$Content.'Provisioninfo'.SubscriptionId

            $Serviceusername = & $DecryptexePath 'W1n$hutt13C10ud' $subusername
            $Servicepassword = & $DecryptexePath 'W1n$hutt13C10ud' $subpassword            
            
            # User Id and Password to do log-in on Azure Portal.
            $secpasswd = ConvertTo-SecureString $Servicepassword -AsPlainText -Force
            $credential = New-Object -TypeName System.Management.Automation.PSCredential ($Serviceusername, $secpasswd)
            $cred = Get-Credential -cred $credential

            Write-Host "Authenticating to Azure" -ForegroundColor Green
            $account = Add-AzurermAccount -Credential $cred -ErrorAction Stop -SubscriptionId $SubID

       Write-host " *************** *************** ******************* "
                    $wc=New-Object net.webclient            
                    $ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()
                    $IPExists=Get-AzureRmSqlServerFirewallRule -ServerName "andsunpod" -FirewallRuleName "WSCEDB-automation" -ErrorAction SilentlyContinue -ResourceGroupName "ResourceGroup_AndSun" -WarningAction SilentlyContinue

                    $wc=New-Object net.webclient 
          
                    $ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()

                    if($IPExists -eq $null)
                      {
                             Write-Host " ***** Creating Firewall Rule to uodate Provisioning Database ***** " -ForegroundColor Green            

                             Write-Host "New-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                                         New-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue
                       }
                    else 
                      {
            
                            Write-host "Set-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                                        Set-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue
                      }

                Write-Host "Updating Provisioning status for $AccountName::$slot  -Start"

                    #sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 2 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
                    sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Started::AddCustomDomain' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"

                Write-Host " Updating Provisioning status for $AccountName::$slot  - updated"

        Write-Host " *************** *************** ******************* "
          
         
            $IsHA=$Content.Provisioninfo.IsHA;
            
            $sitename=$Content.Provisioninfo.sitename;
            $AzureSiteName=$Content.Provisioninfo.AzureSiteName;
            $DatabaseName=$Content.Provisioninfo.DatabaseName;
            $ResourceGroupsName=$Content.Provisioninfo.ResourceGroupsName;
            $domainsuffix=$content.Provisioninfo.Domain;
            $CustomDomain=[string]::Concat($sitename,$domainsuffix);
            $CertThumbPrint=$Content.Provisioninfo.CertThumbPrint;


            Write-Host " -------------------------------------------------------------------------------------------------- " -ForegroundColor Green
            Write-Host " ***** PROPERTIES REQUIRED TO ADD CUSTOM DOMAIN TO $AzureSiteName [$SlotName] PRIMARY WEBSITE ***** " -ForegroundColor Green
            Write-Host " -------------------------------------------------------------------------------------------------- " -ForegroundColor Green

            Write-Host "AzureSiteName : "$AzureSiteName
            Write-Host "ResourceGroupsName : "$ResourceGroupsName
            Write-Host "DatabaseName : "$DatabaseName
            Write-Host "CustomDomain : "$CustomDomain

                                 
            $WebsiteHostnames=Get-AzureRmWebAppSlot -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName -Slot $SlotName -ErrorAction Stop
             #$WebsiteHostnames=Get-AzureWebsite -Name $AzureSiteName -Slot $SlotName -ErrorAction Stop

                
            $hostnames= $WebsiteHostnames.HostNames;

            $CustondomainExists=$WebsiteHostnames.HostNames | Where-Object {$_.Contains(".winshuttleonline.net") }

            if($CustondomainExists -eq $null)
            {

            $HostNames.Add("$CustomDomain");

            Write-Host "Adding $CustomDomain Custom domain to $AzureSiteName [$SlotName] Primary website"  -ForegroundColor Green
           
            #ARM cmdlets. Currently ARM does not suppport adding custom domains using ARM.
            #Write-Host "Set-AzureRmWebAppSlot -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName -HostNames $HostNames -Slot $SlotName -ErrorAction Stop" -ForegroundColor Green
            
                        #Set-AzureRmWebAppSlot -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName - -HostNames $HostNames -Slot $SlotName -ErrorAction Stop
                         
            Write-Host "Set-AzureWebsite -Name $AzureSiteName -Slot $SlotName -HostNames $HostNames -ErrorAction Stop" -ForegroundColor Green
                        Set-AzureWebsite -Name $AzureSiteName -Slot $SlotName -HostNames $HostNames -ErrorAction Stop
            } else { Write-Host "$CustomDomain already exists for $AzureSiteName [$SlotName] Primary website" -ForegroundColor Gray}

            $webapp=Get-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsName -Slot $SlotName -Name $AzureSiteName -ErrorAction Stop

            $SSLBindingExists= $webapp.HostNameSslStates | Where-Object {$_.SslState -eq "SniEnabled" } | select Name
            $certPath=[string]::Concat($JsonFilePath,"\Executable\wildcard_winshuttleonline_net.pfx");
            if($SSLBindingExists -eq $null)
            {
                        Write-Host "Adding SSL Bindings to $AzureSiteName [$SlotName] Primary website"  -ForegroundColor Green
                        <#Write-Host "New-AzureRmWebAppSSLBinding -ResourceGroupName $ResourceGroupsName -WebAppName $AzureSiteName -Thumbprint $CertThumbPrint -Name $CustomDomain -Slot $SlotName -ErrorAction Stop"
                        New-AzureRmWebAppSSLBinding -ResourceGroupName $ResourceGroupsName -WebAppName $AzureSiteName -Thumbprint $CertThumbPrint -Name $CustomDomain -Slot $SlotName -ErrorAction Stop#>

                        Write-Host "New-AzureRmWebAppSSLBinding -ResourceGroupName $ResourceGroupsName -WebAppName $AzureSiteName -Name $CustomDomain -Slot $SlotName -CertificateFilePath $certPath -ErrorAction Stop -CertificatePassword $certPassword"
                                    New-AzureRmWebAppSSLBinding -ResourceGroupName $ResourceGroupsName -WebAppName $AzureSiteName -Name $CustomDomain -Slot $SlotName -CertificateFilePath $certPath -ErrorAction Stop -CertificatePassword $certPassword
            } else { Write-Host "SSL Bindings for $AzureSiteName [$SlotName] Primary website already exists" -ForegroundColor Gray}



   


            if ($IsHA -eq "True")
            {
          
                $SecondaryWebsite=$Content.Provisioninfo.SecondaryAzureSiteName

                $ResourceGroupsNameSecondary=$Content.Provisioninfo.ResourceGroupsNameSecondary;
                                
                Write-Host "SecondaryWebsite : "$SecondaryWebsite
                Write-Host "ResourceGroupsNameSecondary : "$ResourceGroupsNameSecondary
                Write-Host "CustomDomain : "$CustomDomain

                $WebsiteHostnamesSecondary=Get-AzureRmWebAppSlot -Name $SecondaryWebsite -ResourceGroupName $ResourceGroupsNameSecondary -Slot $SlotName  -ErrorAction Stop
                
                $hostnamesSecondary= $WebsiteHostnamesSecondary.HostNames;

                $CustondomainExists=$WebsiteHostnamesSecondary.HostNames | Where-Object {$_.Contains(".winshuttleonline.net") }

                if($CustondomainExists -eq $null)
                {

                    $HostnamesSecondary.Add("$CustomDomain");

                    Write-Host " -------------------------------------------------------------------------------------------------- " -ForegroundColor Green
                    Write-Host "Adding Custom domain to $SecondaryWebsite [$SlotName] Secondary website"  -ForegroundColor Green
                    Write-Host " -------------------------------------------------------------------------------------------------- " -ForegroundColor Green
                    #Write-Host "Set-AzureRmWebApp -Name $SecondaryWebsite -ResourceGroupName $ResourceGroupsNameSecondary -HostNames $HostnamesSecondary -ErrorAction Stop" -ForegroundColor Green            
                                #Set-AzureRmWebApp -Name $SecondaryWebsite -ResourceGroupName $ResourceGroupsNameSecondary -HostNames $HostnamesSecondary -ErrorAction Stop  

                    Write-Host "Set-AzureWebsite -Name $SecondaryWebsite -Slot $SlotName -HostNames $HostnamesSecondary -ErrorAction Stop" -ForegroundColor Green
                                Set-AzureWebsite -Name $SecondaryWebsite -Slot $SlotName -HostNames $HostnamesSecondary -ErrorAction Stop

                } else { Write-Host "$CustomDomain already exists for $SecondaryWebsite [$SlotName] Primary website" -ForegroundColor Gray}


            $webapp=Get-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsNameSecondary -Slot $SlotName -Name $SecondaryWebsite -ErrorAction Stop

            $SSLBindingExists= $webapp.HostNameSslStates | Where-Object {$_.SslState -eq "SniEnabled" } | select Name
            $certPath=[string]::Concat($JsonFilePath,"\Executable\wildcard_winshuttleonline_net.pfx");

            if($SSLBindingExists -eq $null)
            {

                Write-Host "Adding SSL Bindings to $SecondaryWebsite [$SlotName] Secondary website"  -ForegroundColor Green
                <#Write-Host "New-AzureRmWebAppSSLBinding -ResourceGroupName $ResourceGroupsNameSecondary -WebAppName $SecondaryWebsite -Thumbprint $CertThumbPrint -Name $CustomDomain -Slot $SlotName -ErrorAction Stop"
                            New-AzureRmWebAppSSLBinding -ResourceGroupName $ResourceGroupsNameSecondary -WebAppName $SecondaryWebsite -Thumbprint $CertThumbPrint -Name $CustomDomain -Slot $SlotName -ErrorAction Stop#>

                            Write-Host "New-AzureRmWebAppSSLBinding -ResourceGroupName $ResourceGroupsNameSecondary -WebAppName $SecondaryWebsite -Name $CustomDomain -Slot $SlotName -CertificateFilePath $certPath -ErrorAction Stop -CertificatePassword $certPassword"
                                        New-AzureRmWebAppSSLBinding -ResourceGroupName $ResourceGroupsNameSecondary -WebAppName $SecondaryWebsite -Name $CustomDomain -Slot $SlotName -CertificateFilePath $certPath -ErrorAction Stop -CertificatePassword $certPassword
            } else { Write-Host "SSL Bindings for $SecondaryWebsite [$SlotName] Primary website already exists" -ForegroundColor Gray}

              
            }



        Write-host " *************** *************** ******************* "
        Write-Host "Updating Provisioning status for $AccountName::$slot  -Start"

            #sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 2 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
            sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Completed::AddCustomDomain' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
            Remove-AzureSqlDatabaseServerFirewallRule -ServerName "sqlserver-andsun" -RuleName "WSCEDB-automation"
        Write-Host " Updating Provisioning status for $AccountName::$slot  - updated"
        Write-Host " *************** *************** ******************* "
}
Catch [System.Exception]
{
        Write-Host "Error in Provisioning AddCustomDomain " -ForegroundColor DarkRed

        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 3 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Error::AddCustomDomain' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Log = '$_.exception.message' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        Remove-AzureSqlDatabaseServerFirewallRule -ServerName "sqlserver-andsun" -RuleName "WSCEDB-automation"
        Write-Host "Updated Provisioning Error status for $AccountName::$slot "
        write-host "Exception Block"
		write-host $_.exception.message
        Exit 1

        
	}



}

#Provision-UpdateCustomDomain -IsHA $IsHA -JsonFilePath $JsonFilePath -subusername $subusername -subpassword $subpassword

Provision-UpdateCustomDomain -JsonFilePath $JsonFilePath -ProvisionAcctName $ProvisionAcctName -SlotName $SlotName

