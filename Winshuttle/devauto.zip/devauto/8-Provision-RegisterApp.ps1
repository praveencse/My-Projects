﻿<#
.SYNOPSIS
Registers AzureWebapp with Connect with O365 account.
.DESCRIPTION
TRegisters AzureWebapp with Connect with O365 account.
Throws an exception if fails.
.EXAMPLE
.\Provision-RegisterApp -ToolsFolder $ToolsFolder -subusername $subusername -subpassword $subpassword -ProvisionAcctName -$ProvisionAcctName -SlotName $SlotName
	
.NOTES
Author:	Padma P Peddigari	
Version:    1.1
#>


param(
   
    
    [string]$ToolsFolder=$(throw "Please pass Folder path to RegisterApp.exe" ),
    [string]$ProvisionAcctName=$(throw "Please pass the account name for provisioning"),
    [string]$SlotName=$(throw "Please pass SlotName")

)


Function Provision-RegisterApp
{
try
{
          

            # reading the Json file with given username and Password
            $RegisterAppExePath=[string]::Concat($ToolsFolder,"\Executable\Registerapp.exe");
           
            $jsonFile=[string]::Concat("\json\",$ProvisionAcctName,"-",$SlotName,"-ProvisionData.json")
            
            $ProvisionData= Join-Path $ToolsFolder $jsonFile
            $Content= ConvertFrom-Json -InputObject (gc $ProvisionData -Raw)



             # Decrypt.exe path
            $executablesPath= Join-Path $ToolsFolder "\Executable"
            $DecryptexePath= Join-Path $executablesPath "Decrypt\Decrypt.exe"

            $subusername=$Content.'Provisioninfo'.SubscriptionUsername
            $subpassword=$Content.'Provisioninfo'.SubscriptionPassword
            $SubID=$Content.'Provisioninfo'.SubscriptionId

            # Decrypting Sunscription Username and password           

            $Serviceusername = & $DecryptexePath 'W1n$hutt13C10ud' $subusername
            $Servicepassword = & $DecryptexePath 'W1n$hutt13C10ud' $subpassword
            
            
            #$Serviceusername=$subusername;
            #$Servicepassword=$subpassword;
            $secpasswd = ConvertTo-SecureString $Servicepassword -AsPlainText -Force
            $credential = New-Object -TypeName System.Management.Automation.PSCredential ($Serviceusername, $secpasswd)
            $cred = Get-Credential -cred $credential

            Write-Host "Authenticating to Azure" -ForegroundColor Green
            $account = Add-AzureRmAccount -Credential $cred 

           
           Write-host " *************** *************** ******************* "
                $wc=New-Object net.webclient            
                $ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()
                $IPExists=Get-AzureRmSqlServerFirewallRule -ServerName "andsunpod" -FirewallRuleName "WSCEDB-automation" -ErrorAction SilentlyContinue -ResourceGroupName "ResourceGroup_AndSun" -WarningAction SilentlyContinue

                $wc=New-Object net.webclient 
          
                $ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()

                if($IPExists -eq $null)
                  {
                         Write-Host " ***** Creating Firewall Rule to uodate Provisioning Database ***** " -ForegroundColor Green            

                         Write-Host "New-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                                     New-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue
                  }
                else 
                {
                    Write-host "Set-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                                Set-AzureRmSqlServerFirewallRule -FirewallRuleName "WSCEDB-automation" -ResourceGroupName "ResourceGroup_AndSun" -ServerName "sqlserver-andsun" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue
                }

                   Write-Host "Updating Provisioning status for $AccountName::$slot  -Start"

                        #sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 2 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
                        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Started::RegisterApp' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"

                   Write-Host " Updating Provisioning status for $AccountName::$slot  - updated"

            Write-Host " *************** *************** ******************* "

            $ResourceGroupsName=$Content.Provisioninfo.ResourceGroupsName;
            $AzureSiteName=$Content.Provisioninfo.AzureSiteName;
            $IsHA=$Content.Provisioninfo.IsHA;
            

            Write-Host " RegisterAppExePath: "$RegisterAppExePath
            Write-Host " ResourceGroupsName "$ResourceGroupsName
            Write-Host " AzureSiteName: "$AzureSiteName
            Write-Host " IsHA: "$IsHA
            


            Write-Host "****** Registring Primary website *********" -ForegroundColor Green
            #Invoke-Expression -Command $RegisterExePath $Jsonfolderpath 
            Write-Host "here"
            & $RegisterAppExePath $ToolsFolder $ProvisionAcctName $SlotName
#            Start-Process -FilePath $RegisterAppExePath -ArgumentList $ToolsFolder -Wait -ErrorVariable $result -ErrorAction Stop -NoNewWindow
            

            if($LASTEXITCODE -ne 0)
            {throw 1}
            
            Write-Host "****** Restarting Primary website *********" -ForegroundColor Green
            Write-Host "Restart-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsName -Name $AzureSiteName -Slot $SlotName"
                        #Restart-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsName -Name $AzureSiteName -Slot $SlotName -ErrorAction Stop
        $ServerName = $Content.'Provisioninfo'.ServerName;
        $DatabaseName = $Content.'Provisioninfo'.DatabaseName;
        $DBResourceGroupName = $Content.'Provisioninfo'.DBResourceGroupName;
        $UserNameEn = $Content.'Provisioninfo'.UserName;
        $PasswordEn = $Content.'Provisioninfo'.Password;

          # Decrypt.exe path
        $executablesPath= Join-Path $ToolsFolder "\Executable"
        $DecryptexePath= Join-Path $executablesPath "Decrypt\Decrypt.exe"

        $UserName = & $DecryptexePath 'W1n$hutt13C10ud' $UserNameEn
        $Password = & $DecryptexePath 'W1n$hutt13C10ud' $PasswordEn

        $AzureAppIDURIValue=$Content.'Provisioninfo'.AzureAppIDURI;
        $azureappclientidValue=$Content.'Provisioninfo'.AzureAppClientID;

        Write-Host "updating appconfigurations - Start"

        $AzureFirewallRuleName="ClientIP-CloudAutomation";

             Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
             Write-host " ***** Checking for firewall rule ***** "
             Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
            #$IPExists=Get-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -RuleName "ClientIP-CloudAutomation" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue -Verbose 
            $IPExists=Get-AzureRmSqlServerFirewallRule -ServerName "$ServerName" -FirewallRuleName "$AzureFirewallRuleName" -ErrorAction SilentlyContinue -ResourceGroupName $DBResourceGroupName -WarningAction SilentlyContinue


            #Write-host "At Client IP"
           #$ClienIPAddress = (Invoke-WebRequest -Uri http://myexternalip.com/raw -UseBasicParsing -ErrorAction SilentlyContinue -Method Get).Content

           $wc=New-Object net.webclient 
           #Write-host "here"
           $ClienIPAddress = $wc.downloadstring("http://checkip.dyndns.com") -replace "[^\d\.]".Trim()

           #[string]$ClienIPAddress=$ClientI
            

        if($IPExists -eq $null)
        {

             Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
             Write-Host " ***** Creating Firewall Rule ***** " -ForegroundColor Green
             Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
            #Write-Host "New-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -RuleName "$AzureFirewallRuleName" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue -Force" -ForegroundColor Green
                        #New-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -RuleName "$AzureFirewallRuleName" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue -Force

              write-host "New-AzureRmSqlServerFirewallRule -FirewallRuleName $AzureFirewallRuleName -ResourceGroupName $DBResourceGroupName -ServerName $ServerName -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                          New-AzureRmSqlServerFirewallRule -FirewallRuleName $AzureFirewallRuleName -ResourceGroupName $DBResourceGroupName -ServerName $ServerName -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue
        }
        else 
        {
            Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
            Write-Host " ***** Firewall Rule  exists, Hence updating with latest IP if any ***** " -ForegroundColor Green 
            Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
            #Write-host "Set-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -Rule "$AzureFirewallRuleName" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue -Force"
                        #Set-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -Rule "$AzureFirewallRuleName" -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue -Force
            Write-host "Set-AzureRmSqlServerFirewallRule -FirewallRuleName $AzureFirewallRuleName -ResourceGroupName $DBResourceGroupName -ServerName $ServerName -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue"
                       Set-AzureRmSqlServerFirewallRule -FirewallRuleName $AzureFirewallRuleName -ResourceGroupName $DBResourceGroupName -ServerName $ServerName -StartIpAddress $ClienIPAddress -EndIpAddress $ClienIPAddress -ErrorAction Stop -WarningAction SilentlyContinue

        }

            sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -Q "Update appconfigurations Set azureappclientid ='$azureappclientidValue' ;"
            sqlcmd -S "tcp:$ServerName.database.windows.net,1433" -d "$DatabaseName" -U "$UserName" -P $Password -Q "Update appconfigurations Set azureappIDURi ='$AzureAppIDURIValue' ;"
                        
         Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
         Write-Host " ***** Deleting the Firewall Rule ***** " -ForegroundColor Green
         Write-Host " -------------------------------------------------------------------" -ForegroundColor Green
         
         Clear-AzureProfile -Force 
         $account = Add-AzureAccount -Credential $cred -ErrorAction Stop

         Write-host "Remove-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -RuleName "$AzureFirewallRuleName""
                     Remove-AzureSqlDatabaseServerFirewallRule -ServerName "$ServerName" -RuleName "$AzureFirewallRuleName"  
            
            <#
            if($IsHA -eq "True")
            {
                if($Content.Provisioninfo.SecondaryLocation -eq $WebSiteResource.Website.Geolocations.'East Asia'.value){
                $SecondaryWebsite= [string]::Concat($Content.Provisioninfo.DatabaseName,"winshuttle",$WebSiteResource.Website.Geolocations.'East Asia'.suffix)}
                elseif ($Content.Provisioninfo.SecondaryLocation -eq $WebSiteResource.Website.Geolocations.'East US'.value)
                {$SecondaryWebsite= [string]::Concat($Content.Provisioninfo.DatabaseName,"winshuttle",$WebSiteResource.Website.Geolocations.'East US'.suffix)}
                elseif ($Content.Provisioninfo.SecondaryLocation -eq $WebSiteResource.Website.Geolocations.'SouthEast Asia'.value)
                {$SecondaryWebsite= [string]::Concat($Content.Provisioninfo.DatabaseName,"winshuttle",$WebSiteResource.Website.Geolocations.'SouthEast Asia'.suffix)}
                elseif ($Content.Provisioninfo.SecondaryLocation -eq $WebSiteResource.Website.Geolocations.'West US'.value)
                {$SecondaryWebsite= [string]::Concat($Content.Provisioninfo.DatabaseName,"winshuttle",$WebSiteResource.Website.Geolocations.'West Asia'.suffix)}


                $ResourceGroupsNameSecondary=$Content.Provisioninfo.ResourceGroupsNameSecondary;

                Write-Host " ResourceGroupsNameSecondary: "$ResourceGroupsNameSecondary
                Write-Host " SecondaryWebsite: "$SecondaryWebsite
                
                
                Write-Host "****** Registring Secondary website *********" -ForegroundColor Green
                Invoke-Expression -Command $RegisterExePath $Jsonfolderpath 

                Write-Host "****** Restarting Secondary website *********" -ForegroundColor Green
                Write-Host "Restart-AzureRmWebApp -ResourceGroupName $ResourceGroupsNameSecondary -Name $SecondaryWebsite"
                            Restart-AzureRmWebApp -ResourceGroupName $ResourceGroupsNameSecondary -Name $SecondaryWebsite
            
          
            }
            #>

         Write-host " *************** *************** ******************* "
        Write-Host "Updating Provisioning status for $AccountName::$slot  -Start"

            #sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 2 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
            sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Completed::RegisterApp' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
            Remove-AzureSqlDatabaseServerFirewallRule -ServerName "sqlserver-andsun" -RuleName "WSCEDB-automation"
        Write-Host " Updating Provisioning status for $AccountName::$slot  - updated"
        Write-Host " *************** *************** ******************* "
}

Catch [System.Exception]
{
        
        Write-Host "Error in Provisioning RegisterApp " -ForegroundColor DarkRed

        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET ProvisioningStatusId = 3 where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Status = 'Error::RegisterApp' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        sqlcmd -S "tcp:sqlserver-andsun.database.windows.net,1433" -d "ProvisioningDB" -U "andsunpod" -P "`$abcd1234" -Q "Update SetupInfo SET Log = '$_.exception.message' where AccountId =(select id from accounts where Name='$AccountName') and Slotid =(Select ID from Slots where Slot_Name='$slot'  );"
        Remove-AzureSqlDatabaseServerFirewallRule -ServerName "sqlserver-andsun" -RuleName "WSCEDB-automation"

        Write-Host "Updated Provisioning Error status for $AccountName::$slot "


        Write-Host "Exception Block"
		Write-Host $_.exception.message
        Exit 1

        
}
}

Provision-RegisterApp -ToolsFolder $ToolsFolder -subusername $subusername -subpassword $subpassword -ProvisionAcctName -$ProvisionAcctName -SlotName $SlotName

