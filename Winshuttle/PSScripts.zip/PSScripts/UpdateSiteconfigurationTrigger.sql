SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER TRIGGER [dbo].[SiteConfiguration_Trigger]
   ON  [dbo].[SiteConfiguration] 
   AFTER  INSERT,UPDATE
AS 
BEGIN
                SET NOCOUNT ON;
                declare @_oldvalue varchar(max); 
                declare @_newvalue varchar(max); 

                declare @_oldvalueXml xml; 
                declare @_newvalueXml xml; 
                
                declare @preferenceXmlOld XML;
                declare @preferenceXmlNew XML;

                declare @_date datetime;
                declare @_username nvarchar(MAX);
                declare @_isupdate bit;
                declare @_action varchar(50);
                declare @_siteidentifier uniqueidentifier;
                declare @_configurationtype nvarchar(MAX);
                declare @_ischanged bit;
                DECLARE @intpointer int
                DECLARE @intpointerold int
                
    set @_oldvalue = '';
                set @_newvalue = '';
                set @_isupdate = 0;
                set @_ischanged = 1;
                
                if exists (select 1 from deleted)
                begin
                                select 
                                                @_oldvalue = [Value]                     
                                from 
                                                deleted; 

                                select 
                                                @_username = modifiedby,
                                                @_date = modifiedon,
                                                @_configurationtype = [ConfigurationKey]
                                from 
                                                inserted;                              

                                set @_isupdate = 1;
                                set @_action = '_AD_IDS_Update__';
                end
                
                select 
                                @_newvalue = [Value] ,
                                @_siteidentifier = SiteIdentifier
                from 
                                inserted;    

                if @_isupdate = 0--case of first time insert
                begin                       
                                select @_username = createdby, @_date = createdon , @_configurationtype = [ConfigurationKey] from inserted;
                                set @_action = '_AD_IDS_Create__';
                end
                
                
                
                if @_configurationtype = 'clientfeature' 
                begin
                   
                   DECLARE @ClientFeatureId nvarchar(10)
                   DECLARE @ControlledByServer nvarchar(500)
                   DECLARE @DefaultValue nvarchar(500)
                   DECLARE @ClientFeatureName nvarchar(500)
                   DECLARE @ClientFeature TABLE (ClientFeatureId nvarchar(10), ControlledByServer nvarchar(500), DefaultValue nvarchar(500))
                  
                     SET @_newvalueXml = CONVERT(XML, @_newvalue);

                   INSERT into @ClientFeature SELECT
                   doc.col.value('ClientFeatureId[1]', 'nvarchar(10)') ClientFeatureId,
                   doc.col.value('ControlledByServer[1]', 'nvarchar(500)') ControlledByServer,
                   doc.col.value('DefaultValue[1]', 'nvarchar(500)') DefaultValue
                   FROM @_newvalueXml.nodes('/Root/ClientFeature') doc(col)
                   
                   
                   DECLARE myCursor CURSOR STATIC FOR
                                                                                SELECT ClientFeatureId, ControlledByServer, DefaultValue
                                                                                FROM @ClientFeature
                   OPEN myCursor
                   FETCH NEXT FROM myCursor INTO @ClientFeatureId, @ControlledByServer, @DefaultValue
                   
                   
                   if(@_isupdate = 1)
                   BEGIN
                   DECLARE @ClientFeatureIdOld nvarchar(10)
                   DECLARE @ControlledByServerOld nvarchar(500)
                   DECLARE @DefaultValueOld nvarchar(500)
                   DECLARE @ClientFeatureNameOld nvarchar(500)
                   DECLARE @ClientFeatureOld TABLE (ClientFeatureId nvarchar(10), ControlledByServer nvarchar(500), DefaultValue nvarchar(500) )

                     SET @_oldvalueXml = CONVERT(XML, @_oldvalue);

                      INSERT into @ClientFeatureOld SELECT
                   doc.col.value('ClientFeatureId[1]', 'nvarchar(10)') ClientFeatureId,
                   doc.col.value('ControlledByServer[1]', 'nvarchar(500)') ControlledByServer,
                   doc.col.value('DefaultValue[1]', 'nvarchar(500)') DefaultValue
                   FROM @_oldvalueXml.nodes('/Root/ClientFeature') doc(col)
                   
 
                   DECLARE myCursorOld CURSOR STATIC FOR
                                                                                SELECT ClientFeatureId, ControlledByServer, DefaultValue
                                                                                FROM @ClientFeatureOld
       OPEN myCursorOld
       FETCH NEXT FROM myCursorOld INTO @ClientFeatureIdOld, @ControlledByServerOld, @DefaultValueOld
                                
                   END    
                                                                
                                WHILE @@FETCH_STATUS = 0 BEGIN
                                                                                
                                select 
                                                @ClientFeatureName = ClientFeaturesMaster.Feature 
                                from 
                                                ClientFeaturesMaster 
                                where 
                                                ClientFeatureId =             @ClientFeatureId
                                                                                
                                                                SET         @_newvalue = '_AD_IDS_ClientFeature__=' + @ClientFeatureName + '; ' 
                                                + '_AD_IDS_ControlledByServer__=' + @ControlledByServer + '; '
                                                + '_AD_IDS_DefaultVal__=' + @DefaultValue + '; '              
                                                
                                                if(@_oldvalue != '')                          
                                                                                SET         @_oldvalue = '_AD_IDS_ClientFeature__=' + @ClientFeatureName + '; ' 
                                                + '_AD_IDS_ControlledByServer__=' + @ControlledByServerOld + '; '
                                                + '_AD_IDS_DefaultVal__=' + @DefaultValueOld + '; '       
                                if @_oldvalue != @_newvalue                                   
                                insert into 
                                auditlog
                                (
                                                createdon, 
                                                username, 
                                                activity, 
                                                configurationtype, 
                                                newvalues, 
                                                oldvalues,
                                                siteidentifier
                                ) 
                                values
                                (
                                                @_date, 
                                                @_username, 
                                                @_action, 
                                                '_AD_IDS_ClientControlledFeatures__', 
                                                @_newvalue, 
                                                @_oldvalue,
                                                @_siteidentifier
                                );
                                                                                

                                                                                FETCH NEXT FROM myCursor INTO @ClientFeatureId, @ControlledByServer, @DefaultValue
                                                                                if(@_isupdate = 1)
                    FETCH NEXT FROM myCursorOld INTO @ClientFeatureIdOld, @ControlledByServerOld, @DefaultValueOld
                                                                END

                                                                CLOSE myCursor
                                                                DEALLOCATE myCursor
                                                                if(@_isupdate = 1)
                                                                BEGIN
                                                                CLOSE myCursorOld
                                                                DEALLOCATE myCursorOld
                                                                END
                   END
                   
                   ELSE IF @_configurationtype = 'systemusage'
                   BEGIN
                   
                   declare @_newtimeout varchar(100);
                   declare @_oldtimeout varchar(100);
                   declare @_newmaxresultrows varchar(100);
                   declare @_oldmaxresultrows varchar(100);
                   declare @_newNoLimit varchar(100);
                   declare @_oldNoLimit varchar(100);
                   declare @_systemusagelevel varchar(50);
                   declare @_systemusagelevelId varchar(50);
                   
                   DECLARE @SystemUsageNew TABLE (SystemUsageMasterId nvarchar(10), NoLimit nvarchar(500), MaxResultRows nvarchar(500), MaxResultRowsLimit  nvarchar(500), [TimeOut] nvarchar(500))
                   
                   
                     SET @_newvalueXml = CONVERT(XML, @_newvalue);
                      INSERT into @SystemUsageNew SELECT
                   doc.col.value('SystemUsageMasterId[1]', 'nvarchar(10)') SystemUsageMasterId,
                   doc.col.value('NoLimit[1]', 'nvarchar(500)') NoLimit,
                   doc.col.value('MaxResultRows[1]', 'nvarchar(500)') MaxResultRows,
                   doc.col.value('MaxResultRowsLimit[1]', 'nvarchar(500)') MaxResultRowsLimit,
                   doc.col.value('TimeOut[1]', 'nvarchar(500)') [TimeOut]
                   FROM @_newvalueXml.nodes('/Root/SystemUsageLevel') doc(col)
                   
                   DECLARE myCursor CURSOR STATIC FOR
                                                                                SELECT SystemUsageMasterId, MaxResultRows, [TimeOut], NoLimit
                                                                                FROM @SystemUsageNew
                   OPEN myCursor
                   FETCH NEXT FROM myCursor INTO @_systemusagelevelId, @_newmaxresultrows, @_newtimeout, @_newNoLimit
                   
                   if(@_oldvalue != '')
                   BEGIN
                   
                   DECLARE @SystemUsageOld TABLE (SystemUsageMasterId nvarchar(10), NoLimit nvarchar(500), MaxResultRows nvarchar(500), MaxResultRowsLimit  nvarchar(500), [TimeOut] nvarchar(500))
                  
                  SET @_oldvalueXml = CONVERT(XML, @_oldvalue);
                       INSERT into @SystemUsageOld SELECT
                   doc.col.value('SystemUsageMasterId[1]', 'nvarchar(10)') SystemUsageMasterId,
                   doc.col.value('NoLimit[1]', 'nvarchar(500)') NoLimit,
                   doc.col.value('MaxResultRows[1]', 'nvarchar(500)') MaxResultRows,
                   doc.col.value('MaxResultRowsLimit[1]', 'nvarchar(500)') MaxResultRowsLimit,
                   doc.col.value('TimeOut[1]', 'nvarchar(500)') [TimeOut]    
                   FROM @_oldvalueXml.nodes('/Root/SystemUsageLevel') doc(col)

                   DECLARE myCursorOld CURSOR STATIC FOR
                                                                                SELECT SystemUsageMasterId, MaxResultRows, [TimeOut], NoLimit
                                                                                FROM @SystemUsageOld
       OPEN myCursorOld
       FETCH NEXT FROM myCursorOld INTO @_systemusagelevelId, @_oldmaxresultrows, @_oldtimeout, @_oldNoLimit
                                
                   END    
                                
                                WHILE @@FETCH_STATUS = 0 BEGIN
                                set @_ischanged = 1;
                                select 
                                                @_systemusagelevel = SystemUsageMaster.Name 
                                from 
                                                SystemUsageMaster 
                                where 
                                                SystemUsageMasterId =               @_systemusagelevelId
                                                
                                                
                                
                                if(@_isupdate = 1)
                                BEGIN
                                  set @_oldvalue = '';
                                  set @_newvalue = '';
                                
                                  if @_newtimeout != @_oldtimeout
                                begin
                                                set @_oldvalue = @_oldvalue + '_AD_IDS_TimeOut__= ' + convert(varchar(20), @_oldtimeout) + '; ';
                                                set @_newvalue = @_newvalue + '_AD_IDS_TimeOut__= ' + convert(varchar(20), @_newtimeout) + '; ';
                                end                          

                                if @_newNoLimit != @_oldNoLimit
                                begin
                                                if @_oldNoLimit = 'True'
                                                                set @_oldvalue = @_oldvalue +  ' _AD_IDS_NoLimitIsTrue__ '
                                                else
                                                                set @_oldvalue = @_oldvalue +  ' _AD_IDS_MaxNoResultRows__ ' + convert(varchar(50), @_oldmaxresultrows)

                                                if @_newNoLimit = 'True'
                                                                set @_newvalue = @_newvalue +  ' _AD_IDS_NoLimitIsTrue__ '
                                                else
                                                                set @_newvalue = @_newvalue +  ' _AD_IDS_MaxNoResultRows__ ' + convert(varchar(50), @_newmaxresultrows)
                                end
                                
                                else if @_newmaxresultrows != @_oldmaxresultrows
                                begin
                                                set @_oldvalue = @_oldvalue + '_AD_IDS_MaxNoResultRows__= ' + convert(varchar(20), @_oldmaxresultrows) + '; ';
                                                set @_newvalue = @_newvalue + '_AD_IDS_MaxNoResultRows__= ' + convert(varchar(20), @_newmaxresultrows) + '; ';
                                end                        
         
         if @_oldvalue != ''
         begin           
                                                set @_oldvalue = '_AD_IDS_SystemUsageLevel__=' + @_systemusagelevel + '- ' + @_oldvalue;
                                                set @_newvalue = '_AD_IDS_SystemUsageLevel__=' + @_systemusagelevel + '- ' + @_newvalue;
                                end
         else
                                                set @_ischanged = 0;
                                
                                END
                                
                                ELSE
                                
                                BEGIN
                                
                                set 
                                                @_newvalue = '_AD_IDS_SystemUsageLevel__= ' + @_systemusagelevel + '-  ' 
                                                + '_AD_IDS_TimeOut__= ' + convert(varchar(50), @_newtimeout)                                             
                                
                                if @_newNoLimit = 'True'                                             
                                                                set @_newvalue =  @_newvalue + '; _AD_IDS_NoLimitIsTrue__ '                                
                                else                                        
                                                                set @_newvalue =  @_newvalue + '; _AD_IDS_MaxNoResultRows__= ' + convert(varchar(20), @_newmaxresultrows)                                       
                
                                
                                END
                                
                                
                                if @_ischanged = 1
                                insert into 
                                auditlog
                                (
                                                createdon, 
                                                username, 
                                                activity, 
                                                configurationtype, 
                                                newvalues, 
                                                oldvalues,
                                                siteidentifier
                                ) 
                                values
                                (
                                                @_date, 
                                                @_username, 
                                                @_action, 
                                                '_AD_IDS_SystemUsageLevels__', 
                                                @_newvalue, 
                                                @_oldvalue,
                                                @_siteidentifier
                                );
                                                
                    FETCH NEXT FROM myCursor INTO @_systemusagelevelId, @_newmaxresultrows, @_newtimeout, @_newNoLimit
                    if(@_isupdate = 1)
        FETCH NEXT FROM myCursorOld INTO @_systemusagelevelId, @_oldmaxresultrows, @_oldtimeout, @_oldNoLimit
                                                                END

                                                                CLOSE myCursor
                                                                DEALLOCATE myCursor
                                                                if(@_isupdate = 1)
                                                                BEGIN
                                                                CLOSE myCursorOld
                                                                DEALLOCATE myCursorOld
                                                                END
                   
                   END
                ELSE IF @_configurationtype = 'devproflevel'
                BEGIN
                
                declare @_newallowjoinscreationdeletion varchar(100);
                declare @_oldallowjoinscreationdeletion varchar(100);
                declare @_newallowclusterpooljoins varchar(100);
                declare @_oldallowclusterpooljoins varchar(100);
                declare @_newenablequerycreationoninfoset varchar(100);
                declare @_oldenablequerycreationoninfoset varchar(100);
                declare @_newmaxtablesinqb varchar(100);
                declare @_oldmaxtablesinqb varchar(100);
                declare @_newManualJoinMismatchFields varchar(100);
                declare @_oldManualJoinMismatchFields varchar(100);
                declare @_devproflevel varchar(50);       
                declare @_devproflevelId varchar(50);   
                
                DECLARE @DevProfLevelNew TABLE (DevProfLevelMasterID nvarchar(10), Name nvarchar(500), [Description] nvarchar(500), EnableJoinsCreationDeletion nvarchar(500), EnableClusterPoolJoins nvarchar(500), MaxTablesInQB nvarchar(500), EnableQueryCreationOnInfoset nvarchar(500), EnableLeftOuterJoin nvarchar(500))
                
                SET @_newvalueXml = CONVERT(XML, @_newvalue);
                     INSERT into @DevProfLevelNew SELECT
                   doc.col.value('DevProfLevelMasterID[1]', 'nvarchar(10)') DevProfLevelMasterID,
                   doc.col.value('Name[1]', 'nvarchar(500)') Name,
                   doc.col.value('Description[1]', 'nvarchar(500)') [Description],
                   doc.col.value('EnableJoinsCreationDeletion[1]', 'nvarchar(500)') EnableJoinsCreationDeletion,
                   doc.col.value('EnableClusterPoolJoins[1]', 'nvarchar(500)') EnableClusterPoolJoins,           
                   doc.col.value('MaxTablesInQB[1]', 'nvarchar(500)') MaxTablesInQB,         
                   doc.col.value('EnableQueryCreationOnInfoset[1]', 'nvarchar(500)') EnableQueryCreationOnInfoset,          
                   doc.col.value('EnableLeftOuterJoin[1]', 'nvarchar(500)') EnableLeftOuterJoin
                   FROM @_newvalueXml.nodes('/Root/DevProfLevel') doc(col)

                
                   DECLARE myCursor CURSOR STATIC FOR
                                                                                SELECT DevProfLevelMasterID, EnableJoinsCreationDeletion, EnableClusterPoolJoins, MaxTablesInQB,  EnableQueryCreationOnInfoset, MaxTablesInQB
                                                                                FROM @DevProfLevelNew
                   OPEN myCursor
                   FETCH NEXT FROM myCursor INTO @_devproflevelId, @_newallowjoinscreationdeletion, @_newallowclusterpooljoins, @_newmaxtablesinqb, @_newenablequerycreationoninfoset, @_newmaxtablesinqb

                   if(@_oldvalue != '')
                   BEGIN
                  

                   DECLARE @DevProfLevelOld TABLE (DevProfLevelMasterID nvarchar(10), Name nvarchar(500), [Description] nvarchar(500), EnableJoinsCreationDeletion nvarchar(500), EnableClusterPoolJoins nvarchar(500), MaxTablesInQB nvarchar(500), EnableQueryCreationOnInfoset nvarchar(500), EnableLeftOuterJoin nvarchar(500))
                  
                  SET @_oldvalueXml = CONVERT(XML, @_oldvalue);
                   INSERT into @DevProfLevelOld SELECT
                   doc.col.value('DevProfLevelMasterID[1]', 'nvarchar(10)') DevProfLevelMasterID,
                   doc.col.value('Name[1]', 'nvarchar(500)') Name,
                   doc.col.value('Description[1]', 'nvarchar(500)') [Description],
                   doc.col.value('EnableJoinsCreationDeletion[1]', 'nvarchar(500)') EnableJoinsCreationDeletion,
                   doc.col.value('EnableClusterPoolJoins[1]', 'nvarchar(500)') EnableClusterPoolJoins,           
                   doc.col.value('MaxTablesInQB[1]', 'nvarchar(500)') MaxTablesInQB,         
                   doc.col.value('EnableQueryCreationOnInfoset[1]', 'nvarchar(500)') EnableQueryCreationOnInfoset,          
                   doc.col.value('EnableLeftOuterJoin[1]', 'nvarchar(500)') EnableLeftOuterJoin
                   FROM @_oldvalueXml.nodes('/Root/DevProfLevel') doc(col)

                   DECLARE myCursorOld CURSOR STATIC FOR
                                                                                SELECT DevProfLevelMasterID, EnableJoinsCreationDeletion, EnableClusterPoolJoins, MaxTablesInQB,  EnableQueryCreationOnInfoset, MaxTablesInQB
                                                                                FROM @DevProfLevelOld
       OPEN myCursorOld
       FETCH NEXT FROM myCursorOld INTO @_devproflevelId, @_oldallowjoinscreationdeletion, @_oldallowclusterpooljoins, @_oldmaxtablesinqb, @_oldenablequerycreationoninfoset, @_oldmaxtablesinqb
                                
                   END    
                   
                   WHILE @@FETCH_STATUS = 0 BEGIN
                   
                   select 
                                @_devproflevel = DevProfLevelMaster.name
                from 
                                DevProfLevelMaster 
                where 
                                DevProfLevelMaster.DevProfLevelMasterId = @_devproflevelId
                   
                   if(@_isupdate = 1)
                   BEGIN
                   
                   SET @_oldvalue = '';
                   SET @_newvalue = '';
                   if @_newallowjoinscreationdeletion != @_oldallowjoinscreationdeletion
                                begin
                                                set @_oldvalue = @_oldvalue + '_AD_IDS_AllowJoinCreation__=' + dbo.convertbittostring(@_oldallowjoinscreationdeletion) + '; ';
                                                set @_newvalue = @_newvalue + '_AD_IDS_AllowJoinCreation__=' + dbo.convertbittostring(@_newallowjoinscreationdeletion) + '; ';
                                end

                                if @_newallowclusterpooljoins != @_oldallowclusterpooljoins
                                begin
                                                set @_oldvalue = @_oldvalue + '_AD_IDS_AllowClusterPoolJoins__=' + dbo.convertbittostring(@_oldallowclusterpooljoins) + '; ';
                                                set @_newvalue = @_newvalue + '_AD_IDS_AllowClusterPoolJoins__=' + dbo.convertbittostring(@_newallowclusterpooljoins) + '; ';
                                end

                                if @_newenablequerycreationoninfoset != @_oldenablequerycreationoninfoset
                                begin
                                                set @_oldvalue = @_oldvalue + '_AD_IDS_EnableQueryInfoset__=' + dbo.convertbittostring(@_oldenablequerycreationoninfoset) + '; ';
                                                set @_newvalue = @_newvalue + '_AD_IDS_EnableQueryInfoset__=' + dbo.convertbittostring(@_newenablequerycreationoninfoset) + '; ';
                                end

                                if @_newmaxtablesinqb != @_oldmaxtablesinqb
                                begin
                                                set @_oldvalue = @_oldvalue + '_AD_IDS_MaxTables__=' + convert(varchar(10), @_oldmaxtablesinqb) + '; ';
                                                set @_newvalue = @_newvalue + '_AD_IDS_MaxTables__=' + convert(varchar(10), @_newmaxtablesinqb) + '; ';
                                end
                                
                                if @_newManualJoinMismatchFields != @_oldManualJoinMismatchFields
                                begin
                                                set @_oldvalue = @_oldvalue + '_AD_IDS_ManualJoinMismatchFields__=' + dbo.convertbittostring(@_oldManualJoinMismatchFields); 
                                                set @_newvalue = @_newvalue + '_AD_IDS_ManualJoinMismatchFields__=' + dbo.convertbittostring(@_newManualJoinMismatchFields) ;
                                end
                                
                                if @_oldvalue != ''            
                                begin     
                                                set @_oldvalue = '_AD_IDS_DevProficiencyLevel__=' + @_devproflevel + '- ' + @_oldvalue;
                                                set @_newvalue = '_AD_IDS_DevProficiencyLevel__=' + @_devproflevel + '- ' + @_newvalue;
                                end
                                else
                                                set @_ischanged = 0;
                                
                   END
                   
                   ELSE
                   BEGIN
                   
                   select 
                                                @_newvalue = '_AD_IDS_DevProficiencyLevel__=' + @_devproflevel + '- ' 
                                                                + '_AD_IDS_AllowJoinCreation__=' + dbo.convertbittostring(@_newallowjoinscreationdeletion) + '; '
                                                                + '_AD_IDS_AllowClusterPoolJoins__=' + dbo.convertbittostring(@_newallowclusterpooljoins) + ';'
                                                                + '_AD_IDS_EnableQueryInfoset__=' + dbo.convertbittostring(@_newenablequerycreationoninfoset) + '; '
                                                                + '_AD_IDS_ManualJoinMismatchFields__=' + dbo.convertbittostring(@_newManualJoinMismatchFields) + '; '
                                                                + '_AD_IDS_MaxTables__=' + convert(varchar(10), @_newmaxtablesinqb)
                   
                   END
                   if @_oldvalue != @_newvalue
                   insert into 
                                auditlog
                                (
                                                createdon, 
                                                username, 
                                                activity, 
                                                configurationtype, 
                                                newvalues, 
                                                oldvalues,
                                                siteidentifier
                                ) 
                                values
                                (
                                                @_date, 
                                                @_username, 
                                                @_action, 
                                                '_AD_IDS_DevProficiencyLevelConfig__', 
                                                @_newvalue, 
                                                @_oldvalue,
                                                @_siteidentifier
                                );
                   
                   
                   FETCH NEXT FROM myCursor INTO @_devproflevelId, @_newallowjoinscreationdeletion, @_newallowclusterpooljoins, @_newmaxtablesinqb, @_newenablequerycreationoninfoset, @_newmaxtablesinqb
                   if(@_isupdate = 1)
       FETCH NEXT FROM myCursorOld INTO @_devproflevelId, @_oldallowjoinscreationdeletion, @_oldallowclusterpooljoins, @_oldmaxtablesinqb, @_oldenablequerycreationoninfoset, @_oldmaxtablesinqb
                                                                END

                                                                CLOSE myCursor
                                                                DEALLOCATE myCursor
                                                                if(@_isupdate = 1)
                                                                BEGIN
                                                                CLOSE myCursorOld
                                                                DEALLOCATE myCursorOld
                                                                END
                   
                END

                ELSE IF @_configurationtype = 'applicationconfigurationsetting'
                BEGIN
                declare @_setings varchar(50);
                END
                ELSE IF @_configurationtype = 'txpreference'
                   BEGIN
                   
                   declare @_oldreviewprocess varchar(50);
                   declare @_newreviewprocess varchar(50);
                   declare @_oldreviewprocessid varchar(50);
                   declare @_newreviewprocessid varchar(50);      
                   
                   if(@_isupdate = 1)
                   BEGIN
                   
                    Set @preferenceXmlOld = @_oldvalue;
                    select @_oldreviewprocessid =  @preferenceXmlOld.value('(/Root/ReviewProcess)[1]','varchar(50)')
                    
                    select 
                                                @_oldreviewprocess = DataReviewWorkflowMaster.name 
                                from 
                                                DataReviewWorkflowMaster 
                                where 
                                                DataReviewWorkflowMaster.DataReviewWorkflowMasterId = @_oldreviewprocessid
                   
                   
                   select 
                                                @_oldvalue = '_AD_IDS_ReviewProcess__=' + @_oldreviewprocess + '; ' 
                                                
                                                + '_AD_IDS_ErrorFromSAP__=' + @preferenceXmlOld.value('(/Root/MoveOnErrorWhilePosting)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_ErrorOccurred__=' + @preferenceXmlOld.value('(/Root/MoveOnErrorOccured)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_JobCancelled__=' + @preferenceXmlOld.value('(/Root/MoveOnJobCancelled)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_WinshuttleServerError__=' + @preferenceXmlOld.value('(/Root/MoveOnServerError)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_Completed__=' + @preferenceXmlOld.value('(/Root/MoveOnCompleted)[1]','varchar(50)') + ';'
                                                + 'Move To Run Completed DocLib=' + @preferenceXmlOld.value('(/Root/MoveToRunCompletedDocLib)[1]','varchar(50)') + ';'
                                                + 'Reviewer/Creator=' + @preferenceXmlOld.value('(/Root/ReviewerCreator)[1]','varchar(50)') + ';'
                                                + 'System Account=' + @preferenceXmlOld.value('(/Root/SystemAccountAutorun)[1]','varchar(50)') + ';'
                                                + 'SystemAccountName=' + @preferenceXmlOld.value('(/Root/SystemAccountName)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_AllowDesktopScheduling__=' + @preferenceXmlOld.value('(/Root/AllowDesktopScheduling)[1]','varchar(50)') + ';'
                   
                   select 
                                                @_username = modifiedby,
                                                @_date = modifiedon 
                                from 
                                                inserted;                              

                                set @_isupdate = 1;
                                set @_action = '_AD_IDS_Update__';
                   END
                   
                   Set @preferenceXmlNew = @_newvalue;
                    select @_newreviewprocessid =  @preferenceXmlNew.value('(/Root/ReviewProcess)[1]','varchar(50)')
                    
                    select 
                                                @_newreviewprocess = DataReviewWorkflowMaster.name 
                                from 
                                                DataReviewWorkflowMaster 
                                where 
                                                DataReviewWorkflowMaster.DataReviewWorkflowMasterId = @_newreviewprocessid
                   
                   select 
                                                @_newvalue = '_AD_IDS_ReviewProcess__=' + @_newreviewprocess + '; ' 
                                                
                                                + '_AD_IDS_ErrorFromSAP__=' + @preferenceXmlNew.value('(/Root/MoveOnErrorWhilePosting)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_ErrorOccurred__=' + @preferenceXmlNew.value('(/Root/MoveOnErrorOccured)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_JobCancelled__=' + @preferenceXmlNew.value('(/Root/MoveOnJobCancelled)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_WinshuttleServerError__=' + @preferenceXmlNew.value('(/Root/MoveOnServerError)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_Completed__=' + @preferenceXmlNew.value('(/Root/MoveOnCompleted)[1]','varchar(50)') + ';'
                                                + 'Move To Run Completed DocLib=' + @preferenceXmlNew.value('(/Root/MoveToRunCompletedDocLib)[1]','varchar(50)') + ';'
                                                + 'Reviewer/Creator=' + @preferenceXmlNew.value('(/Root/ReviewerCreator)[1]','varchar(50)') + ';'
                                                + 'System Account=' + @preferenceXmlNew.value('(/Root/SystemAccountAutorun)[1]','varchar(50)') + ';'
                                                + 'SystemAccountName=' + @preferenceXmlNew.value('(/Root/SystemAccountName)[1]','varchar(50)') + ';'
                                                   + '_AD_IDS_AllowDesktopScheduling__=' + @preferenceXmlNew.value('(/Root/AllowDesktopScheduling)[1]','varchar(50)') + ';'
                   
                   if @_isupdate = 0
                begin     
                                select @_username = createdby, @_date = createdon from inserted;
                                set @_action = '_AD_IDS_Create__';
                end
                if @_oldvalue != @_newvalue
                   insert into 
                                auditlog
                                (
                                                createdon, 
                                                username, 
                                                activity, 
                                                configurationtype, 
                                                newvalues, 
                                                oldvalues,
                                                siteidentifier
                                ) 
                                values
                                (
                                                @_date, 
                                                @_username, 
                                                @_action, 
                                                '_AD_IDS_TxSitePreferences__', 
                                                @_newvalue, 
                                                @_oldvalue,
                                                @_siteidentifier
                                );
                   
                   END
                   
                   ELSE IF @_configurationtype = 'qspreference'
                   BEGIN
                   
                   
                   if(@_isupdate = 1)
                   BEGIN
                   
                    Set @preferenceXmlOld = @_oldvalue;
                   
                   select 
                                                @_oldvalue = '_AD_IDS_AllowDesktopSchedulingExcel__= ' + @preferenceXmlOld.value('(/Root/AllowDesktopScheduling_Excel)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_AllowDesktopSchedulingXml__= ' + @preferenceXmlOld.value('(/Root/AllowDesktopScheduling_Xml)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_AllowDesktopSchedulingAccess__= ' + @preferenceXmlOld.value('(/Root/AllowDesktopScheduling_Access)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_AllowDesktopSchedulingText__= ' + @preferenceXmlOld.value('(/Root/AllowDesktopScheduling_Text)[1]','varchar(50)') + ';'
                                                + 'Move To Run Completed DocLib=' + @preferenceXmlOld.value('(/Root/MoveToRunCompletedDocLib)[1]','varchar(50)') + ';'
                                                + 'User Account =' + @preferenceXmlOld.value('(/Root/AppPool)[1]','varchar(50)') + ';'
                                                + 'Use system Account =' + @preferenceXmlOld.value('(/Root/SystemAccount)[1]','varchar(50)') + ';'
                                                + 'UserName =' + @preferenceXmlOld.value('(/Root/UserName)[1]','varchar(50)') + ';'
                                                + 'Password =' + @preferenceXmlOld.value('(/Root/Password)[1]','varchar(50)') + ';'
                                                + 'SqlUser Name=' + @preferenceXmlOld.value('(/Root/SQLUserName)[1]','varchar(50)') + ';'
                                                + 'Sql Password=' + @preferenceXmlOld.value('(/Root/SQLPassword)[1]','varchar(50)') + ';'
                   select 
                                                @_username = modifiedby,
                                                @_date = modifiedon 
                                from 
                                                inserted;                              

                                set @_isupdate = 1;
                                set @_action = '_AD_IDS_Update__';
                   END
                   
                   Set @preferenceXmlNew = @_newvalue;
                      
                   select 
                                                @_newvalue = '_AD_IDS_AllowDesktopSchedulingExcel__= ' + @preferenceXmlNew.value('(/Root/AllowDesktopScheduling_Excel)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_AllowDesktopSchedulingXml__= ' + @preferenceXmlNew.value('(/Root/AllowDesktopScheduling_Xml)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_AllowDesktopSchedulingAccess__= ' + @preferenceXmlNew.value('(/Root/AllowDesktopScheduling_Access)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_AllowDesktopSchedulingText__= ' + @preferenceXmlNew.value('(/Root/AllowDesktopScheduling_Text)[1]','varchar(50)') + ';'
                                                + 'Move To Run Completed DocLib=' + @preferenceXmlNew.value('(/Root/MoveToRunCompletedDocLib)[1]','varchar(50)') + ';'
                                                + 'User Account =' + @preferenceXmlNew.value('(/Root/AppPool)[1]','varchar(50)') + ';'
                                                + 'Use system Account =' + @preferenceXmlNew.value('(/Root/SystemAccount)[1]','varchar(50)') + ';'
                                                + 'UserName =' + @preferenceXmlNew.value('(/Root/UserName)[1]','varchar(50)') + ';'
                                                + 'Password =' + @preferenceXmlNew.value('(/Root/Password)[1]','varchar(50)') + ';'
                                                + 'SqlUser Name=' + @preferenceXmlNew.value('(/Root/SQLUserName)[1]','varchar(50)') + ';'
                                                + 'Sql Password=' + @preferenceXmlNew.value('(/Root/SQLPassword)[1]','varchar(50)') + ';'
                   
                   if @_isupdate = 0
                begin     
                                select @_username = createdby, @_date = createdon from inserted;
                                set @_action = '_AD_IDS_Create__';
                end
                  if @_oldvalue != @_newvalue
                   insert into 
                                auditlog
                                (
                                                createdon, 
                                                username, 
                                                activity, 
                                                configurationtype, 
                                                newvalues, 
                                                oldvalues,
                                                siteidentifier
                                ) 
                                values
                                (
                                                @_date, 
                                                @_username, 
                                                @_action, 
                                                '_AD_IDS_QuerySitePrefs__', 
                                                @_newvalue, 
                                                @_oldvalue,
                                                @_siteidentifier
                                );
                   
                   END

                ELSE IF @_configurationtype = 'authorizationfields'
                   BEGIN
                   
                 
                                SET @_oldvalueXml = CONVERT(XML, @_oldvalue);
                    SET @_newvalueXml = CONVERT(XML, @_newvalue);
                    
                                DECLARE @AuthorizationFieldID as int
                                DECLARE @XML1 TABLE(AuthorizationFieldId int Identity(1,1) , TableName varchar(50), ObjectName varchar(50), FieldName varchar(50), FieldText varchar(100), AuthoText varchar(256), value nvarchar(max))
                                DECLARE @XML2 TABLE(AuthorizationFieldId int Identity(1,1) , TableName varchar(50), ObjectName varchar(50), FieldName varchar(50), FieldText varchar(100), AuthoText varchar(256), value nvarchar(max))

                                                                                                                                                
                                                                insert into @XML1 select
                                                                T.N.value('TableName[1]', 'nvarchar(100)') as TableName,
                                                                T.N.value('ObjectName[1]', 'nvarchar(100)') as ObjectName,
                                                                T.N.value('FieldName[1]', 'nvarchar(100)') as FieldName,
                                                                T.N.value('FieldText[1]', 'nvarchar(100)') as FieldText,
                                                                T.N.value('AuthoText[1]', 'nvarchar(256)') as AuthoText,
                                                                                                T.N.value('.', 'nvarchar(max)') as Value
                                                                  from @_oldvalueXml.nodes('/Root/AuthorizationField') as T(N) 
                                                                                                                                                                                  
                                                                                                                 insert into @XML2 select
                                                                  T.N.value('TableName[1]', 'nvarchar(100)') as TableName,
                                                                T.N.value('ObjectName[1]', 'nvarchar(100)') as ObjectName,
                                                                T.N.value('FieldName[1]', 'nvarchar(100)') as FieldName,
                                                                T.N.value('FieldText[1]', 'nvarchar(100)') as FieldText,
                                                                T.N.value('AuthoText[1]', 'nvarchar(256)') as AuthoText,
                                                                                                T.N.value('.', 'nvarchar(max)') as Value
                                                                  from @_newvalueXml.nodes('/Root/AuthorizationField') as T(N) 

                                                DECLARE @CountOld as int
                                                DECLARE @CountNew as int
                                                select @CountOld = COUNT(*) from @XML1
                                                select @CountNew = COUNT(*) from @XML2
                                                
                                                 IF @CountOld > @CountNew
                                                BEGIN
                                                set @_action = '_AD_IDS_Delete__'; 
                                                  SELECT @AuthorizationFieldID = x.AuthorizationFieldId from @XML1 x where x.value not in (select value from @XML2) 
                                                  SET @_oldvalue = '_AD_IDS_TableName__=' +  (select TableName from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) + 
                                                                                                                                '; _AD_IDS_ObjectName__='+  ( select ObjectName from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                                                                                                '; _AD_IDS_FieldName__=' +  (select FieldName from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                                                                                                '; _AD_IDS_FieldText__=' +  (select FieldText from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                                                                                                '; _AD_IDS_AuthorizationText__=' +  (select AuthoText from @XML1 where AuthorizationFieldId = @AuthorizationFieldID)
                                                  Set @_newvalue = '' 
                                                 END
                                                ELSE If @CountOld < @CountNew
                                                BEGIN
                                                set @_action = '_AD_IDS_Create__';
                                                SELECT @AuthorizationFieldID = x.AuthorizationFieldId from @XML2 x where x.value not in (select value from @XML1) 
                                                  SET @_newvalue = '_AD_IDS_TableName__='+  (  select TableName from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) + 
                                                                                                                                '; _AD_IDS_ObjectName__=' +  (select ObjectName from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                                                                                                '; _AD_IDS_FieldName__=' +  (select FieldName from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                                                                                                '; _AD_IDS_FieldText__=' +  (select FieldText from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                                                                                                '; _AD_IDS_AuthorizationText__=' +  (select AuthoText from @XML2 where AuthorizationFieldId = @AuthorizationFieldID)
                                                  Set @_oldvalue = '' 
                                                END
                                                ELSE
                                                BEGIN
                                                set @_action = '_AD_IDS_Update__';
                                                
                                                SELECT  @AuthorizationFieldID = x2.AuthorizationFieldId FROM @XML2 x2,@XML1 x1 WHERE x2.AuthorizationFieldId = x1.AuthorizationFieldId AND x1.value != x2.value
                                                
                                                SET @_oldvalue = '_AD_IDS_TableName__=' +  (select TableName from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) + 
                                                                                                                                '; _AD_IDS_ObjectName__='+  ( select ObjectName from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                                                                                                '; _AD_IDS_FieldName__=' +  (select FieldName from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                                                                                                '; _AD_IDS_FieldText__=' +  (select FieldText from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                                                                                                '; _AD_IDS_AuthorizationText__=' +  (select AuthoText from @XML1 where AuthorizationFieldId = @AuthorizationFieldID)
                                                                                                                                
                                                   SET @_newvalue = '_AD_IDS_TableName__='+  (  select TableName from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) + 
                                                                                                                                '; _AD_IDS_ObjectName__=' +  (select ObjectName from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                                                                                                '; _AD_IDS_FieldName__=' +  (select FieldName from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                                                                                                '; _AD_IDS_FieldText__=' +  (select FieldText from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                                                                                                '; _AD_IDS_AuthorizationText__=' +  (select AuthoText from @XML2 where AuthorizationFieldId = @AuthorizationFieldID)
                                                  
                                                END


                   insert into 
                                auditlog
                                (
                                                createdon, 
                                                username, 
                                                activity, 
                                                configurationtype, 
                                                newvalues, 
                                                oldvalues,
                                                siteidentifier
                                ) 
                                values
                                (
                                                @_date, 
                                                @_username, 
                                                @_action, 
                                                '_AD_IDS_AuthFields__', 
                                                @_newvalue, 
                                                @_oldvalue,
                                                @_siteidentifier
                                );
                    
                   END
                   
                 ELSE IF @_configurationtype = 'foundationpreference'
                    BEGIN                  
                   
                   if(@_isupdate = 1)
                   BEGIN    
                    Set @preferenceXmlOld = @_oldvalue;
                                                                   
                   select  
                                                @_oldvalue = '_AD_IDS_CentralizedDDA__= ' + @preferenceXmlOld.value('(/Root/GenCentralizedDataDictionaryUsage)[1]','varchar(10)') + ';'
                                                + '_AD_IDS_AllowSelfApproval__= ' + @preferenceXmlOld.value('(/Root/GenAllowSelfApprovalonTRANSACTIONScripts)[1]','varchar(10)') + ';'
                                                + '_AD_IDS_QsScriptApproval__= ' + @preferenceXmlOld.value('(/Root/GenQueryScriptApproval)[1]','varchar(10)') + '; '
                                                + '_AD_IDS_QueryThrottling__= ' + @preferenceXmlOld.value('(/Root/GenEnableAdaptiveQueryThrottling)[1]','varchar(10)') + ';'
                                                + '_AD_IDS_QueryRejectReasonRequired__= ' + @preferenceXmlOld.value('(/Root/RequireRejectionReasonForQueryScript)[1]','varchar(10)') + ';'
                                                + '_AD_IDS_AllowSelfApproval__=' + @preferenceXmlOld.value('(/Root/GenAllowSelfApprovalonQUERYScripts)[1]','varchar(10)') + '; '
                                                + '_AD_IDS_TxScriptApproval__=' + @preferenceXmlOld.value('(/Root/GenTransactionWorkflowrequired)[1]','varchar(10)') + ';'
                                                + '_AD_IDS_SaveToCENTRAL__=' + @preferenceXmlOld.value('(/Root/GenSavetoCENTRAL)[1]','varchar(10)') + '; '
                                                + '_AD_IDS_RunOnErrors__=' + @preferenceXmlOld.value('(/Root/GenRunTransactionScriptswitherrors)[1]','varchar(10)') + ';'
                                                + '_AD_IDS_RunReasonReqd__=' + @preferenceXmlOld.value('(/Root/GenRunTransactionScriptreasonrequired)[1]','varchar(10)') + ';'                                             
                                                + '_AD_IDS_TxrRejectReasonRequired__=' + @preferenceXmlOld.value('(/Root/RequireRejectionReasonForTransactionScript)[1]','varchar(10)') + ';'
                                                + '_AD_IDS_AllowRevisionOfFiles__=' + @preferenceXmlOld.value('(/Root/GenAllowRevisionofDataTemplates)[1]','varchar(10)') + ';'
                                                + 'Allow User to Manage string Padding of Criteria =' + @preferenceXmlOld.value('(/Root/GenAllowUsertoManagestringPaddingofCriteria)[1]','varchar(10)') + ';'
                                                + 'Remove Central Workflows =' + @preferenceXmlOld.value('(/Root/RemoveCentralWorkflows)[1]','varchar(10)') + ';'
                                                + '_AD_IDS_DataRejectReasonRequired__=' + @preferenceXmlOld.value('(/Root/RequireRejectionReasonForTransactionDataFile)[1]','varchar(10)')
                                                + 'Enable Property Promotion =' + @preferenceXmlOld.value('(/Root/GenPropertyPromotion)[1]','varchar(10)') + ';'
                                                + 'Enable Auto-Run Success Email = ' + @preferenceXmlOld.value('(/Root/GenAutorunSuccessEmail)[1]','varchar(10)') + ';'
                                                + 'Enable Auto-Run Error Email = ' + @preferenceXmlOld.value('(/Root/GenAutorunFailureEmail)[1]','varchar(10)') + ';'                                             
                                                + 'Control version of Data Templates = ' + @preferenceXmlOld.value('(/Root/GenControlVersionofDataTemplates)[1]','varchar(10)') + ';'                      
                                                + '_AD_IDS_schedulewithchangedsettings__ =' + @preferenceXmlOld.value('(/Root/GenAllowScheduleWithChangedSettings)[1]','varchar(10)') + ';'
                                                + '_AD_IDS_RestrictGUIfilesonServer__ =' + @preferenceXmlOld.value('(/Root/GenRestrictGuiFileOnServer)[1]','varchar(10)') + ';'
                                                
                                                

                                                
                   IF  @preferenceXmlOld.value('(/Root/GenEnableItemLevelPermissions)[1]','varchar(50)') IS NOT NULL 
        Begin
                    SET @_oldvalue = @_oldvalue + '_AD_IDS_EnableItemLevelPermissions__=' + @preferenceXmlOld.value('(/Root/GenEnableItemLevelPermissions)[1]','varchar(10)') + ';'
                                END


                   select 
                                                @_username = modifiedby,
                                                @_date = modifiedon 
                                from 
                                                inserted;                              

                                set @_isupdate = 1;
                                set @_action = '_AD_IDS_Update__';
                   END
                   
                   Set @preferenceXmlNew = @_newvalue;
                   
                 

                     
                   
                   select 
                                                @_newvalue = '_AD_IDS_CentralizedDDA__= ' + @preferenceXmlNew.value('(/Root/GenCentralizedDataDictionaryUsage)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_AllowSelfApproval__= ' + @preferenceXmlNew.value('(/Root/GenAllowSelfApprovalonTRANSACTIONScripts)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_QsScriptApproval__= ' + @preferenceXmlNew.value('(/Root/GenQueryScriptApproval)[1]','varchar(50)') + '; '
                                                + '_AD_IDS_QueryThrottling__= ' + @preferenceXmlNew.value('(/Root/GenEnableAdaptiveQueryThrottling)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_QueryRejectReasonRequired__= ' + @preferenceXmlNew.value('(/Root/RequireRejectionReasonForQueryScript)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_AllowSelfApproval__=' + @preferenceXmlNew.value('(/Root/GenAllowSelfApprovalonQUERYScripts)[1]','varchar(50)') + '; '
                                                + '_AD_IDS_TxScriptApproval__=' + @preferenceXmlNew.value('(/Root/GenTransactionWorkflowrequired)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_SaveToCENTRAL__=' + @preferenceXmlNew.value('(/Root/GenSavetoCENTRAL)[1]','varchar(50)') + '; '
                                                + '_AD_IDS_RunOnErrors__=' + @preferenceXmlNew.value('(/Root/GenRunTransactionScriptswitherrors)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_RunReasonReqd__=' + @preferenceXmlNew.value('(/Root/GenRunTransactionScriptreasonrequired)[1]','varchar(50)') + ';'                                          
                                                + '_AD_IDS_TxrRejectReasonRequired__=' + @preferenceXmlNew.value('(/Root/RequireRejectionReasonForTransactionScript)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_AllowRevisionOfFiles__=' + @preferenceXmlNew.value('(/Root/GenAllowRevisionofDataTemplates)[1]','varchar(50)') + ';'
                                                + 'Allow User to Manage string Padding of Criteria =' + @preferenceXmlNew.value('(/Root/GenAllowUsertoManagestringPaddingofCriteria)[1]','varchar(50)') + ';'
                                                + 'Remove Central Workflows =' + @preferenceXmlNew.value('(/Root/RemoveCentralWorkflows)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_DataRejectReasonRequired__=' + @preferenceXmlNew.value('(/Root/RequireRejectionReasonForTransactionDataFile)[1]','varchar(50)')
                                                + 'Enable Property Promotion =' + @preferenceXmlNew.value('(/Root/GenPropertyPromotion)[1]','varchar(50)') + ';'
                                                + 'Enable Auto-Run Success Email = ' + @preferenceXmlNew.value('(/Root/GenAutorunSuccessEmail)[1]','varchar(50)') + ';'
                                                + 'Enable Auto-Run Error Email = ' + @preferenceXmlNew.value('(/Root/GenAutorunFailureEmail)[1]','varchar(50)') + ';'                                           
                                                + 'Control version of Data Templates = ' + @preferenceXmlNew.value('(/Root/GenControlVersionofDataTemplates)[1]','varchar(50)') + ';'
                                                + '_AD_IDS_schedulewithchangedsettings__ =' + @preferenceXmlNew.value('(/Root/GenAllowScheduleWithChangedSettings)[1]','varchar(10)') + ';'
                                                + '_AD_IDS_RestrictGUIfilesonServer__ =' + @preferenceXmlNew.value('(/Root/GenRestrictGuiFileOnServer)[1]','varchar(10)') + ';'
                                                
                   
                    IF  @preferenceXmlNew.value('(/Root/GenEnableItemLevelPermissions)[1]','varchar(50)') IS NOT NULL 
        Begin
                    SET @_newvalue = @_newvalue + '_AD_IDS_EnableItemLevelPermissions__=' + @preferenceXmlNew.value('(/Root/GenEnableItemLevelPermissions)[1]','varchar(10)') + ';'
                                END

                   if @_isupdate = 0
                begin     
                    set @_oldvalue = ''
                                select @_username = createdby, @_date = createdon from inserted;
                                set @_action = '_AD_IDS_Create__';
                end        
                  if @_oldvalue != @_newvalue
                   insert into 
                                auditlog
                                (
                                                createdon, 
                                                username, 
                                                activity, 
                                                configurationtype, 
                                                newvalues, 
                                                oldvalues,
                                                siteidentifier
                                ) 
                                values
                                (
                                                @_date, 
                                                @_username, 
                                                @_action, 
                                                '_AD_IDS_FoundationSitePrefs__', 
                                                @_newvalue, 
                                                @_oldvalue,
                                                @_siteidentifier
                                );
                   
                   END
                   
                                   ELSE IF @_configurationtype = 'CustomerLogo'
                    BEGIN                  
                   if @_oldvalue != @_newvalue
                insert into 
                                auditlog
                                (
                                                createdon, 
                                                username, 
                                                activity, 
                                                configurationtype, 
                                                newvalues, 
                                                oldvalues,
                                                siteidentifier
                                ) 
                                values
                                (
                                                @_date, 
                                                @_username, 
                                                @_action, 
                                                'Company Logo', 
                                                @_newvalue, 
                                                @_oldvalue,
                                                @_siteidentifier
                                );
                
                  End

                ELSE
                
                BEGIN
                if @_oldvalue != @_newvalue
                insert into 
                                auditlog
                                (
                                                createdon, 
                                                username, 
                                                activity, 
                                                configurationtype, 
                                                newvalues, 
                                                oldvalues,
                                                siteidentifier
                                ) 
                                values
                                (
                                                @_date, 
                                                @_username, 
                                                @_action, 
                                                '_AD_IDS_AuthorizationFieldsSettings__', 
                                                @_newvalue, 
                                                @_oldvalue,
                                                @_siteidentifier
                                );
                
                END
END

GO

From: Gowri Sankar Varada 
Sent: 22 May 2017 16:43
To: Naresh Kumar Gunji <Naresh.Gunji@winshuttle.com>
Subject: Trigger run

FYI…


IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[SiteConfiguration_Trigger]'))
DROP TRIGGER [dbo].[SiteConfiguration_Trigger]
GO
/****** Object:  Trigger [dbo].[SiteConfiguration_Trigger]    Script Date: 12/28/2015 04:22:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE TRIGGER [dbo].[SiteConfiguration_Trigger]
   ON  [dbo].[SiteConfiguration] 
   AFTER  INSERT,UPDATE
AS 
BEGIN
       SET NOCOUNT ON;
       declare @_oldvalue varchar(max); 
       declare @_newvalue varchar(max); 

       declare @_oldvalueXml xml; 
       declare @_newvalueXml xml; 
       
       declare @preferenceXmlOld XML;
       declare @preferenceXmlNew XML;

       declare @_date datetime;
       declare @_username nvarchar(MAX);
       declare @_isupdate bit;
       declare @_action varchar(50);
       declare @_siteidentifier uniqueidentifier;
       declare @_configurationtype nvarchar(MAX);
       declare @_ischanged bit;
       DECLARE @intpointer int
       DECLARE @intpointerold int
       
    set @_oldvalue = '';
       set @_newvalue = '';
       set @_isupdate = 0;
       set @_ischanged = 1;
       
       if exists (select 1 from deleted)
       begin
              select 
                     @_oldvalue = [Value]       
              from 
                     deleted; 

              select 
                     @_username = modifiedby,
                     @_date = modifiedon,
                     @_configurationtype = [ConfigurationKey]
              from 
                     inserted;            

              set @_isupdate = 1;
              set @_action = '_AD_IDS_Update__';
       end
       
       select 
              @_newvalue = [Value] ,
              @_siteidentifier = SiteIdentifier
       from 
              inserted;    

       if @_isupdate = 0--case of first time insert
       begin           
              select @_username = createdby, @_date = createdon , @_configurationtype = [ConfigurationKey] from inserted;
              set @_action = '_AD_IDS_Create__';
       end
       
       
       
       if @_configurationtype = 'clientfeature' 
       begin
          
          DECLARE @ClientFeatureId nvarchar(10)
          DECLARE @ControlledByServer nvarchar(500)
          DECLARE @DefaultValue nvarchar(500)
          DECLARE @ClientFeatureName nvarchar(500)
          DECLARE @ClientFeature TABLE (ClientFeatureId nvarchar(10), ControlledByServer nvarchar(500), DefaultValue nvarchar(500))
          
            SET @_newvalueXml = CONVERT(XML, @_newvalue);

          INSERT into @ClientFeature SELECT
          doc.col.value('ClientFeatureId[1]', 'nvarchar(10)') ClientFeatureId,
          doc.col.value('ControlledByServer[1]', 'nvarchar(500)') ControlledByServer,
          doc.col.value('DefaultValue[1]', 'nvarchar(500)') DefaultValue
          FROM @_newvalueXml.nodes('/Root/ClientFeature') doc(col)
          
          
          DECLARE myCursor CURSOR STATIC FOR
                                  SELECT ClientFeatureId, ControlledByServer, DefaultValue
                                  FROM @ClientFeature
          OPEN myCursor
          FETCH NEXT FROM myCursor INTO @ClientFeatureId, @ControlledByServer, @DefaultValue
          
          
          if(@_isupdate = 1)
          BEGIN
          DECLARE @ClientFeatureIdOld nvarchar(10)
          DECLARE @ControlledByServerOld nvarchar(500)
          DECLARE @DefaultValueOld nvarchar(500)
          DECLARE @ClientFeatureNameOld nvarchar(500)
          DECLARE @ClientFeatureOld TABLE (ClientFeatureId nvarchar(10), ControlledByServer nvarchar(500), DefaultValue nvarchar(500) )

            SET @_oldvalueXml = CONVERT(XML, @_oldvalue);

             INSERT into @ClientFeatureOld SELECT
          doc.col.value('ClientFeatureId[1]', 'nvarchar(10)') ClientFeatureId,
          doc.col.value('ControlledByServer[1]', 'nvarchar(500)') ControlledByServer,
          doc.col.value('DefaultValue[1]', 'nvarchar(500)') DefaultValue
          FROM @_oldvalueXml.nodes('/Root/ClientFeature') doc(col)
          
 
          DECLARE myCursorOld CURSOR STATIC FOR
                                  SELECT ClientFeatureId, ControlledByServer, DefaultValue
                                  FROM @ClientFeatureOld
       OPEN myCursorOld
       FETCH NEXT FROM myCursorOld INTO @ClientFeatureIdOld, @ControlledByServerOld, @DefaultValueOld
              
          END 
                           
              WHILE @@FETCH_STATUS = 0 BEGIN
                                  
              select 
                     @ClientFeatureName = ClientFeaturesMaster.Feature 
              from 
                     ClientFeaturesMaster 
              where 
                     ClientFeatureId =    @ClientFeatureId
                                  
                           SET    @_newvalue = '_AD_IDS_ClientFeature__=' + @ClientFeatureName + '; ' 
                     + '_AD_IDS_ControlledByServer__=' + @ControlledByServer + '; '
                     + '_AD_IDS_DefaultVal__=' + @DefaultValue + '; '       
                     
                     if(@_oldvalue != '')       
                                  SET    @_oldvalue = '_AD_IDS_ClientFeature__=' + @ClientFeatureName + '; ' 
                     + '_AD_IDS_ControlledByServer__=' + @ControlledByServerOld + '; '
                     + '_AD_IDS_DefaultVal__=' + @DefaultValueOld + '; '    
              if @_oldvalue != @_newvalue              
              insert into 
              auditlog
              (
                     createdon, 
                     username, 
                     activity, 
                     configurationtype, 
                     newvalues, 
                     oldvalues,
                     siteidentifier
              ) 
              values
              (
                     @_date, 
                     @_username, 
                     @_action, 
                     '_AD_IDS_ClientControlledFeatures__', 
                     @_newvalue, 
                     @_oldvalue,
                     @_siteidentifier
              );
                                  

                                  FETCH NEXT FROM myCursor INTO @ClientFeatureId, @ControlledByServer, @DefaultValue
                                  if(@_isupdate = 1)
                    FETCH NEXT FROM myCursorOld INTO @ClientFeatureIdOld, @ControlledByServerOld, @DefaultValueOld
                           END

                           CLOSE myCursor
                           DEALLOCATE myCursor
                           if(@_isupdate = 1)
                           BEGIN
                           CLOSE myCursorOld
                           DEALLOCATE myCursorOld
                           END
          END
          
          ELSE IF @_configurationtype = 'systemusage'
          BEGIN
          
          declare @_newtimeout varchar(100);
          declare @_oldtimeout varchar(100);
          declare @_newmaxresultrows varchar(100);
          declare @_oldmaxresultrows varchar(100);
          declare @_newNoLimit varchar(100);
          declare @_oldNoLimit varchar(100);
          declare @_systemusagelevel varchar(50);
          declare @_systemusagelevelId varchar(50);
          
          DECLARE @SystemUsageNew TABLE (SystemUsageMasterId nvarchar(10), NoLimit nvarchar(500), MaxResultRows nvarchar(500), MaxResultRowsLimit  nvarchar(500), [TimeOut] nvarchar(500))
          
          
            SET @_newvalueXml = CONVERT(XML, @_newvalue);
             INSERT into @SystemUsageNew SELECT
          doc.col.value('SystemUsageMasterId[1]', 'nvarchar(10)') SystemUsageMasterId,
          doc.col.value('NoLimit[1]', 'nvarchar(500)') NoLimit,
          doc.col.value('MaxResultRows[1]', 'nvarchar(500)') MaxResultRows,
          doc.col.value('MaxResultRowsLimit[1]', 'nvarchar(500)') MaxResultRowsLimit,
          doc.col.value('TimeOut[1]', 'nvarchar(500)') [TimeOut]
          FROM @_newvalueXml.nodes('/Root/SystemUsageLevel') doc(col)
          
          DECLARE myCursor CURSOR STATIC FOR
                                  SELECT SystemUsageMasterId, MaxResultRows, [TimeOut], NoLimit
                                  FROM @SystemUsageNew
          OPEN myCursor
          FETCH NEXT FROM myCursor INTO @_systemusagelevelId, @_newmaxresultrows, @_newtimeout, @_newNoLimit
          
          if(@_oldvalue != '')
          BEGIN
          
          DECLARE @SystemUsageOld TABLE (SystemUsageMasterId nvarchar(10), NoLimit nvarchar(500), MaxResultRows nvarchar(500), MaxResultRowsLimit  nvarchar(500), [TimeOut] nvarchar(500))
         
         SET @_oldvalueXml = CONVERT(XML, @_oldvalue);
              INSERT into @SystemUsageOld SELECT
          doc.col.value('SystemUsageMasterId[1]', 'nvarchar(10)') SystemUsageMasterId,
          doc.col.value('NoLimit[1]', 'nvarchar(500)') NoLimit,
          doc.col.value('MaxResultRows[1]', 'nvarchar(500)') MaxResultRows,
          doc.col.value('MaxResultRowsLimit[1]', 'nvarchar(500)') MaxResultRowsLimit,
          doc.col.value('TimeOut[1]', 'nvarchar(500)') [TimeOut]        
          FROM @_oldvalueXml.nodes('/Root/SystemUsageLevel') doc(col)

          DECLARE myCursorOld CURSOR STATIC FOR
                                  SELECT SystemUsageMasterId, MaxResultRows, [TimeOut], NoLimit
                                  FROM @SystemUsageOld
       OPEN myCursorOld
       FETCH NEXT FROM myCursorOld INTO @_systemusagelevelId, @_oldmaxresultrows, @_oldtimeout, @_oldNoLimit
              
          END 
              
              WHILE @@FETCH_STATUS = 0 BEGIN
              set @_ischanged = 1;
              select 
                     @_systemusagelevel = SystemUsageMaster.Name 
              from 
                     SystemUsageMaster 
              where 
                     SystemUsageMasterId =      @_systemusagelevelId
                     
                     
              
              if(@_isupdate = 1)
              BEGIN
                set @_oldvalue = '';
                set @_newvalue = '';
              
                if @_newtimeout != @_oldtimeout
              begin
                     set @_oldvalue = @_oldvalue + '_AD_IDS_TimeOut__= ' + convert(varchar(20), @_oldtimeout) + '; ';
                     set @_newvalue = @_newvalue + '_AD_IDS_TimeOut__= ' + convert(varchar(20), @_newtimeout) + '; ';
              end             

              if @_newNoLimit != @_oldNoLimit
              begin
                     if @_oldNoLimit = 'True'
                           set @_oldvalue = @_oldvalue +  ' _AD_IDS_NoLimitIsTrue__ '
                     else
                           set @_oldvalue = @_oldvalue +  ' _AD_IDS_MaxNoResultRows__ ' + convert(varchar(50), @_oldmaxresultrows)

                     if @_newNoLimit = 'True'
                           set @_newvalue = @_newvalue +  ' _AD_IDS_NoLimitIsTrue__ '
                     else
                           set @_newvalue = @_newvalue +  ' _AD_IDS_MaxNoResultRows__ ' + convert(varchar(50), @_newmaxresultrows)
              end
              
              else if @_newmaxresultrows != @_oldmaxresultrows
              begin
                     set @_oldvalue = @_oldvalue + '_AD_IDS_MaxNoResultRows__= ' + convert(varchar(20), @_oldmaxresultrows) + '; ';
                     set @_newvalue = @_newvalue + '_AD_IDS_MaxNoResultRows__= ' + convert(varchar(20), @_newmaxresultrows) + '; ';
              end           
         
         if @_oldvalue != ''
         begin       
                     set @_oldvalue = '_AD_IDS_SystemUsageLevel__=' + @_systemusagelevel + '- ' + @_oldvalue;
                     set @_newvalue = '_AD_IDS_SystemUsageLevel__=' + @_systemusagelevel + '- ' + @_newvalue;
              end
         else
                     set @_ischanged = 0;
              
              END
              
              ELSE
              
              BEGIN
              
              set 
                     @_newvalue = '_AD_IDS_SystemUsageLevel__= ' + @_systemusagelevel + '-  ' 
                     + '_AD_IDS_TimeOut__= ' + convert(varchar(50), @_newtimeout)               
              
              if @_newNoLimit = 'True'                 
                           set @_newvalue =  @_newvalue + '; _AD_IDS_NoLimitIsTrue__ '                 
              else                 
                           set @_newvalue =  @_newvalue + '; _AD_IDS_MaxNoResultRows__= ' + convert(varchar(20), @_newmaxresultrows)               
       
              
              END
              
              
              if @_ischanged = 1
              insert into 
              auditlog
              (
                     createdon, 
                     username, 
                     activity, 
                     configurationtype, 
                     newvalues, 
                     oldvalues,
                     siteidentifier
              ) 
              values
              (
                     @_date, 
                     @_username, 
                     @_action, 
                     '_AD_IDS_SystemUsageLevels__', 
                     @_newvalue, 
                     @_oldvalue,
                     @_siteidentifier
              );
                     
           FETCH NEXT FROM myCursor INTO @_systemusagelevelId, @_newmaxresultrows, @_newtimeout, @_newNoLimit
           if(@_isupdate = 1)
        FETCH NEXT FROM myCursorOld INTO @_systemusagelevelId, @_oldmaxresultrows, @_oldtimeout, @_oldNoLimit
                           END

                           CLOSE myCursor
                           DEALLOCATE myCursor
                           if(@_isupdate = 1)
                           BEGIN
                           CLOSE myCursorOld
                           DEALLOCATE myCursorOld
                           END
          
          END
       ELSE IF @_configurationtype = 'devproflevel'
       BEGIN
       
       declare @_newallowjoinscreationdeletion varchar(100);
       declare @_oldallowjoinscreationdeletion varchar(100);
       declare @_newallowclusterpooljoins varchar(100);
       declare @_oldallowclusterpooljoins varchar(100);
       declare @_newenablequerycreationoninfoset varchar(100);
       declare @_oldenablequerycreationoninfoset varchar(100);
       declare @_newEnableLeftOuterJoins varchar(100);
       declare @_oldEnableLeftOuterJoins varchar(100);
       declare @_newmaxtablesinqb varchar(100);
       declare @_oldmaxtablesinqb varchar(100);
       declare @_newManualJoinMismatchFields varchar(100);
       declare @_oldManualJoinMismatchFields varchar(100);
       declare @_devproflevel varchar(50);      
       declare @_devproflevelId varchar(50);    
       
       DECLARE @DevProfLevelNew TABLE (DevProfLevelMasterID nvarchar(10), Name nvarchar(500), [Description] nvarchar(500), EnableJoinsCreationDeletion nvarchar(500), EnableClusterPoolJoins nvarchar(500), MaxTablesInQB nvarchar(500), EnableQueryCreationOnInfoset nvarchar(500), EnableLeftOuterJoin nvarchar(500))
       
       SET @_newvalueXml = CONVERT(XML, @_newvalue);
             INSERT into @DevProfLevelNew SELECT
          doc.col.value('DevProfLevelMasterID[1]', 'nvarchar(10)') DevProfLevelMasterID,
          doc.col.value('Name[1]', 'nvarchar(500)') Name,
          doc.col.value('Description[1]', 'nvarchar(500)') [Description],
          doc.col.value('EnableJoinsCreationDeletion[1]', 'nvarchar(500)') EnableJoinsCreationDeletion,
          doc.col.value('EnableClusterPoolJoins[1]', 'nvarchar(500)') EnableClusterPoolJoins,      
          doc.col.value('MaxTablesInQB[1]', 'nvarchar(500)') MaxTablesInQB,    
          doc.col.value('EnableQueryCreationOnInfoset[1]', 'nvarchar(500)') EnableQueryCreationOnInfoset,        
          doc.col.value('EnableLeftOuterJoin[1]', 'nvarchar(500)') EnableLeftOuterJoin
          FROM @_newvalueXml.nodes('/Root/DevProfLevel') doc(col)

       
          DECLARE myCursor CURSOR STATIC FOR
                                  SELECT DevProfLevelMasterID, EnableJoinsCreationDeletion, EnableClusterPoolJoins, MaxTablesInQB,  EnableQueryCreationOnInfoset, EnableLeftOuterJoin
                                  FROM @DevProfLevelNew
          OPEN myCursor
          FETCH NEXT FROM myCursor INTO @_devproflevelId, @_newallowjoinscreationdeletion, @_newallowclusterpooljoins, @_newmaxtablesinqb, @_newenablequerycreationoninfoset, @_newEnableLeftOuterJoins

          if(@_oldvalue != '')
          BEGIN
         

          DECLARE @DevProfLevelOld TABLE (DevProfLevelMasterID nvarchar(10), Name nvarchar(500), [Description] nvarchar(500), EnableJoinsCreationDeletion nvarchar(500), EnableClusterPoolJoins nvarchar(500), MaxTablesInQB nvarchar(500), EnableQueryCreationOnInfoset nvarchar(500), EnableLeftOuterJoin nvarchar(500))
         
         SET @_oldvalueXml = CONVERT(XML, @_oldvalue);
          INSERT into @DevProfLevelOld SELECT
          doc.col.value('DevProfLevelMasterID[1]', 'nvarchar(10)') DevProfLevelMasterID,
          doc.col.value('Name[1]', 'nvarchar(500)') Name,
          doc.col.value('Description[1]', 'nvarchar(500)') [Description],
          doc.col.value('EnableJoinsCreationDeletion[1]', 'nvarchar(500)') EnableJoinsCreationDeletion,
          doc.col.value('EnableClusterPoolJoins[1]', 'nvarchar(500)') EnableClusterPoolJoins,      
          doc.col.value('MaxTablesInQB[1]', 'nvarchar(500)') MaxTablesInQB,    
          doc.col.value('EnableQueryCreationOnInfoset[1]', 'nvarchar(500)') EnableQueryCreationOnInfoset,        
          doc.col.value('EnableLeftOuterJoin[1]', 'nvarchar(500)') EnableLeftOuterJoin
          FROM @_oldvalueXml.nodes('/Root/DevProfLevel') doc(col)

       
          END 
          
          WHILE @@FETCH_STATUS = 0 BEGIN
          
          select 
              @_devproflevel = DevProfLevelMaster.name
       from 
              DevProfLevelMaster 
       where 
              DevProfLevelMaster.DevProfLevelMasterId = @_devproflevelId
          
          if(@_isupdate = 1)
          
          BEGIN
  
                     SELECT @_oldallowjoinscreationdeletion = EnableJoinsCreationDeletion,@_oldallowclusterpooljoins = EnableClusterPoolJoins,@_oldmaxtablesinqb = MaxTablesInQB,@_oldenablequerycreationoninfoset =  EnableQueryCreationOnInfoset, @_oldEnableLeftOuterJoins = EnableLeftOuterJoin
                     FROM @DevProfLevelOld where DevProfLevelMasterID = @_devproflevelId
      
          SET @_oldvalue = '';
          SET @_newvalue = '';
          if @_newallowjoinscreationdeletion != @_oldallowjoinscreationdeletion
              begin
                     set @_oldvalue = @_oldvalue + '_AD_IDS_AllowJoinCreation__=' + dbo.convertbittostring(@_oldallowjoinscreationdeletion) + '; ';
                     set @_newvalue = @_newvalue + '_AD_IDS_AllowJoinCreation__=' + dbo.convertbittostring(@_newallowjoinscreationdeletion) + '; ';
              end

              if @_newallowclusterpooljoins != @_oldallowclusterpooljoins
              begin
                     set @_oldvalue = @_oldvalue + '_AD_IDS_AllowClusterPoolJoins__=' + dbo.convertbittostring(@_oldallowclusterpooljoins) + '; ';
                     set @_newvalue = @_newvalue + '_AD_IDS_AllowClusterPoolJoins__=' + dbo.convertbittostring(@_newallowclusterpooljoins) + '; ';
              end

              if @_newenablequerycreationoninfoset != @_oldenablequerycreationoninfoset
              begin
                     set @_oldvalue = @_oldvalue + '_AD_IDS_EnableQueryInfoset__=' + dbo.convertbittostring(@_oldenablequerycreationoninfoset) + '; ';
                     set @_newvalue = @_newvalue + '_AD_IDS_EnableQueryInfoset__=' + dbo.convertbittostring(@_newenablequerycreationoninfoset) + '; ';
              end

              if @_newmaxtablesinqb != @_oldmaxtablesinqb
              begin
                     set @_oldvalue = @_oldvalue + '_AD_IDS_MaxTables__=' + convert(varchar(10), @_oldmaxtablesinqb) + '; ';
                     set @_newvalue = @_newvalue + '_AD_IDS_MaxTables__=' + convert(varchar(10), @_newmaxtablesinqb) + '; ';
              end
              
              if @_newManualJoinMismatchFields != @_oldManualJoinMismatchFields
              begin
                     set @_oldvalue = @_oldvalue + '_AD_IDS_ManualJoinMismatchFields__=' + dbo.convertbittostring(@_oldManualJoinMismatchFields); 
                     set @_newvalue = @_newvalue + '_AD_IDS_ManualJoinMismatchFields__=' + dbo.convertbittostring(@_newManualJoinMismatchFields) ;
              end
              
              if @_newEnableLeftOuterJoins != @_oldEnableLeftOuterJoins
              begin
                     set @_oldvalue = @_oldvalue + '_AD_IDS_EnableLeftOuterJoins__=' + dbo.convertbittostring(@_oldEnableLeftOuterJoins); 
                     set @_newvalue = @_newvalue + '_AD_IDS_EnableLeftOuterJoins__=' + dbo.convertbittostring(@_newEnableLeftOuterJoins) ;
              end
              
              if @_oldvalue != ''  
              begin  
                     set @_oldvalue = '_AD_IDS_DevProficiencyLevel__=' + @_devproflevel + '- ' + @_oldvalue;
                     set @_newvalue = '_AD_IDS_DevProficiencyLevel__=' + @_devproflevel + '- ' + @_newvalue;
              end
              else
                     set @_ischanged = 0;
              
          END
          
          ELSE
          BEGIN
          
          select 
                     @_newvalue = '_AD_IDS_DevProficiencyLevel__=' + @_devproflevel + '- ' 
                           + '_AD_IDS_AllowJoinCreation__=' + dbo.convertbittostring(@_newallowjoinscreationdeletion) + '; '
                           + '_AD_IDS_AllowClusterPoolJoins__=' + dbo.convertbittostring(@_newallowclusterpooljoins) + ';'
                           + '_AD_IDS_EnableQueryInfoset__=' + dbo.convertbittostring(@_newenablequerycreationoninfoset) + '; '
                           + '_AD_IDS_ManualJoinMismatchFields__=' + dbo.convertbittostring(@_newManualJoinMismatchFields) + '; '
                           + '_AD_IDS_EnableLeftOuterJoins__=' + dbo.convertbittostring(@_newManualJoinMismatchFields) + '; '
                           + '_AD_IDS_MaxTables__=' + convert(varchar(10), @_newmaxtablesinqb)
          
          END
          if @_oldvalue != @_newvalue
          insert into 
              auditlog
              (
                     createdon, 
                     username, 
                     activity, 
                     configurationtype, 
                     newvalues, 
                     oldvalues,
                     siteidentifier
              ) 
              values
              (
                     @_date, 
                     @_username, 
                     @_action, 
                     '_AD_IDS_DevProficiencyLevelConfig__', 
                     @_newvalue, 
                     @_oldvalue,
                     @_siteidentifier
              );
          
          
          FETCH NEXT FROM myCursor INTO @_devproflevelId, @_newallowjoinscreationdeletion, @_newallowclusterpooljoins, @_newmaxtablesinqb, @_newenablequerycreationoninfoset, @_newEnableLeftOuterJoins         
           END
           
              CLOSE myCursor
                           DEALLOCATE myCursor
       END

       ELSE IF @_configurationtype = 'applicationconfigurationsetting'
       BEGIN
       declare @_setings varchar(50);
       declare @_oldxmlsetings xml;
       declare @_newxmlsetings xml;
          
          
        --<WinshuttleServerUrl /><WorkflowAdminURL>http://10.26.2.169:8071/WinshuttleServer</WorkflowAdminURL><ComposerURL /><WorkflowServerURL /><WinshuttleServerUrlEncryptionKey /></Root>
          
          if(@_isupdate = 1)
          BEGIN
          
           Set @_oldxmlsetings = @_oldvalue;
          
          select 
                     @_oldvalue = 'IDDD_AutoPostQueueMaxLength=' + ISNULL(@_oldxmlsetings.value('(/Root/ApplicationConfiguration/Value)[1]','varchar(50)'),'') + ';'
                     + 'IDDD_AutoPostDurationBetweenRetriesMints=' + ISNULL(@_oldxmlsetings.value('(/Root/ApplicationConfiguration/Value)[2]','varchar(50)'),'') + ';'
                     + 'IDDD_AutoPostTimerMaxRetries=' + ISNULL(@_oldxmlsetings.value('(/Root/ApplicationConfiguration/Value)[3]','varchar(50)'),'') + ';'
                     + 'IDDD_WinshuttleServerUrl=' + ISNULL(@_oldxmlsetings.value('(/Root/WinshuttleServerUrl)[1]','varchar(256)'),'') + ';'
                     + 'IDDD_WorkflowAdminUrl=' + ISNULL(@_oldxmlsetings.value('(/Root/WorkflowAdminURL)[1]','varchar(256)'),'') + ';'
                     + 'IDDD_WorkflowComposerUrl=' + ISNULL(@_oldxmlsetings.value('(/Root/ComposerURL)[1]','varchar(256)'),'') + ';'
                     
          
          select 
                     @_username = modifiedby,
                     @_date = modifiedon 
              from 
                     inserted;            

              set @_isupdate = 1;
              set @_action = '_AD_IDS_Update__';
          END
          
          Set @_newxmlsetings = @_newvalue;
           
          select 
                           @_newvalue = 'IDDD_AutoPostQueueMaxLength=' +  ISNULL(@_newxmlsetings.value('(/Root/ApplicationConfiguration/Value)[1]','varchar(50)'),'') + ';'
                     + 'IDDD_AutoPostDurationBetweenRetriesMints=' +  ISNULL(@_newxmlsetings.value('(/Root/ApplicationConfiguration/Value)[2]','varchar(50)'),'') + ';'
                     + 'IDDD_AutoPostTimerMaxRetries=' +  ISNULL(@_newxmlsetings.value('(/Root/ApplicationConfiguration/Value)[3]','varchar(50)'),'') + ';'
                     + 'IDDD_WinshuttleServerUrl=' +  ISNULL(@_newxmlsetings.value('(/Root/WinshuttleServerUrl)[1]','varchar(256)'),'') + ';'
                     + 'IDDD_WorkflowAdminUrl=' +  ISNULL(@_newxmlsetings.value('(/Root/WorkflowAdminURL)[1]','varchar(256)'),'') + ';'
                     + 'IDDD_WorkflowComposerUrl=' +  ISNULL(@_newxmlsetings.value('(/Root/ComposerURL)[1]','varchar(256)'),'') + ';'
                     
          if @_isupdate = 0
       begin  
              select @_username = createdby, @_date = createdon from inserted;
              set @_action = '_AD_IDS_Create__';
       end
       if @_oldvalue != @_newvalue
          insert into 
              auditlog
              (
                     createdon, 
                     username, 
                     activity, 
                     configurationtype, 
                     newvalues, 
                     oldvalues,
                     siteidentifier
              ) 
              values
              (
                     @_date, 
                     @_username, 
                     @_action, 
                     '_AD_IDS_CentralSettings__', 
                     @_newvalue, 
                     @_oldvalue,
                     @_siteidentifier
              );
       END
       ELSE IF @_configurationtype = 'txpreference'
         BEGIN
          
          declare @_oldreviewprocess varchar(50);
          declare @_newreviewprocess varchar(50);
          declare @_oldreviewprocessid varchar(50);
          declare @_newreviewprocessid varchar(50);       
          
          if(@_isupdate = 1)
          BEGIN
          
           Set @preferenceXmlOld = @_oldvalue;
           select @_oldreviewprocessid =  @preferenceXmlOld.value('(/Root/ReviewProcess)[1]','varchar(50)')
           
           select 
                     @_oldreviewprocess = DataReviewWorkflowMaster.name 
              from 
                     DataReviewWorkflowMaster 
              where 
                     DataReviewWorkflowMaster.DataReviewWorkflowMasterId = @_oldreviewprocessid
          
          
          select 
                     @_oldvalue = '_AD_IDS_ReviewProcess__=' + @_oldreviewprocess + '; ' 
                     + '_AD_IDS_ErrorFromSAP__=' + @preferenceXmlOld.value('(/Root/MoveOnErrorWhilePosting)[1]','varchar(50)') + ';'
                     + '_AD_IDS_ErrorOccurred__=' + @preferenceXmlOld.value('(/Root/MoveOnErrorOccured)[1]','varchar(50)') + ';'
                     + '_AD_IDS_JobCancelled__=' + @preferenceXmlOld.value('(/Root/MoveOnJobCancelled)[1]','varchar(50)') + ';'
                     + '_AD_IDS_WinshuttleServerError__=' + @preferenceXmlOld.value('(/Root/MoveOnServerError)[1]','varchar(50)') + ';'
                     + '_AD_IDS_Completed__=' + @preferenceXmlOld.value('(/Root/MoveOnCompleted)[1]','varchar(50)') + ';'
                     + '_AD_IDS_MoveToRunCompletedDocLib__=' + @preferenceXmlOld.value('(/Root/MoveToRunCompletedDocLib)[1]','varchar(50)') + ';'
                     + '_AD_IDS_ReviewerCreator__=' + @preferenceXmlOld.value('(/Root/ReviewerCreator)[1]','varchar(50)') + ';'
                     + '_AD_IDS_SystemAccount__=' + @preferenceXmlOld.value('(/Root/SystemAccountAutorun)[1]','varchar(50)') + ';'
                     + '_AD_IDS_SystemAccountName__=' + @preferenceXmlOld.value('(/Root/SystemAccountName)[1]','varchar(50)') + ';'
               + '_AD_IDS_AllowDesktopScheduling__=' + @preferenceXmlOld.value('(/Root/AllowDesktopScheduling)[1]','varchar(50)') + ';'
               
               
          select 
                     @_username = modifiedby,
                     @_date = modifiedon 
              from 
                     inserted;            

              set @_isupdate = 1;
              set @_action = '_AD_IDS_Update__';
          END
          
          Set @preferenceXmlNew = @_newvalue;
           select @_newreviewprocessid =  @preferenceXmlNew.value('(/Root/ReviewProcess)[1]','varchar(50)')
           
           select 
                     @_newreviewprocess = DataReviewWorkflowMaster.name 
              from 
                     DataReviewWorkflowMaster 
              where 
                     DataReviewWorkflowMaster.DataReviewWorkflowMasterId = @_newreviewprocessid
          
          select 
                     @_newvalue = '_AD_IDS_ReviewProcess__=' + @_newreviewprocess + '; ' 
                     + '_AD_IDS_ErrorFromSAP__=' + @preferenceXmlNew.value('(/Root/MoveOnErrorWhilePosting)[1]','varchar(50)') + ';'
                     + '_AD_IDS_ErrorOccurred__=' + @preferenceXmlNew.value('(/Root/MoveOnErrorOccured)[1]','varchar(50)') + ';'
                     + '_AD_IDS_JobCancelled__=' + @preferenceXmlNew.value('(/Root/MoveOnJobCancelled)[1]','varchar(50)') + ';'
                     + '_AD_IDS_WinshuttleServerError__=' + @preferenceXmlNew.value('(/Root/MoveOnServerError)[1]','varchar(50)') + ';'
                     + '_AD_IDS_Completed__=' + @preferenceXmlNew.value('(/Root/MoveOnCompleted)[1]','varchar(50)') + ';'
                     + '_AD_IDS_MoveToRunCompletedDocLib__=' + @preferenceXmlNew.value('(/Root/MoveToRunCompletedDocLib)[1]','varchar(50)') + ';'
                     + '_AD_IDS_ReviewerCreator__=' + @preferenceXmlNew.value('(/Root/ReviewerCreator)[1]','varchar(50)') + ';'
                     + '_AD_IDS_SystemAccount__=' + @preferenceXmlNew.value('(/Root/SystemAccountAutorun)[1]','varchar(50)') + ';'
                     + '_AD_IDS_SystemAccountName__=' + @preferenceXmlNew.value('(/Root/SystemAccountName)[1]','varchar(50)') + ';'
                        + '_AD_IDS_AllowDesktopScheduling__=' + @preferenceXmlNew.value('(/Root/AllowDesktopScheduling)[1]','varchar(50)') + ';'
          
          if @_isupdate = 0
       begin  
              select @_username = createdby, @_date = createdon from inserted;
              set @_action = '_AD_IDS_Create__';
       end
       if @_oldvalue != @_newvalue
          insert into 
              auditlog
              (
                     createdon, 
                     username, 
                     activity, 
                     configurationtype, 
                     newvalues, 
                     oldvalues,
                     siteidentifier
              ) 
              values
              (
                     @_date, 
                     @_username, 
                     @_action, 
                     '_AD_IDS_TxSitePreferences__', 
                     @_newvalue, 
                     @_oldvalue,
                     @_siteidentifier
              );
          
          END
          
          ELSE IF @_configurationtype = 'qspreference'
           BEGIN
          
          
          if(@_isupdate = 1)
          BEGIN
          
           Set @preferenceXmlOld = @_oldvalue;
           
          select 
                     @_oldvalue = '_AD_IDS_AllowDesktopSchedulingExcel__= ' + @preferenceXmlOld.value('(/Root/AllowDesktopScheduling_Excel)[1]','varchar(50)') + ';'
                     + '_AD_IDS_AllowDesktopSchedulingXml__= ' + @preferenceXmlOld.value('(/Root/AllowDesktopScheduling_Xml)[1]','varchar(50)') + ';'
                     + '_AD_IDS_AllowDesktopSchedulingAccess__= ' + @preferenceXmlOld.value('(/Root/AllowDesktopScheduling_Access)[1]','varchar(50)') + ';'
                     + '_AD_IDS_AllowDesktopSchedulingText__= ' + @preferenceXmlOld.value('(/Root/AllowDesktopScheduling_Text)[1]','varchar(50)') + ';'
                     + '_AD_IDS_MoveToRunCompletedDocLib__=' + @preferenceXmlOld.value('(/Root/MoveToRunCompletedDocLib)[1]','varchar(50)') + ';'
                     + '_AD_IDS_ServiceAccountforWorker__=' + @preferenceXmlOld.value('(/Root/AppPool)[1]','varchar(50)') + ';'
                     + '_AD_IDS_SystemAccount__=' + @preferenceXmlOld.value('(/Root/SystemAccount)[1]','varchar(50)') + ';'
                     + '_AD_IDS_QsSPUserName__=' + @preferenceXmlOld.value('(/Root/UserName)[1]','varchar(50)') + ';'
                     + '_AD_IDS_QsSPPassword__=' + @preferenceXmlOld.value('(/Root/Password)[1]','varchar(50)') + ';'
                     + '_AD_IDS_QsSQLUserName__=' + @preferenceXmlOld.value('(/Root/SQLUserName)[1]','varchar(50)') + ';'
                     + '_AD_IDS_QsSQLPassword__=' + @preferenceXmlOld.value('(/Root/SQLPassword)[1]','varchar(50)') + ';'
                     
                     
          select 
                     @_username = modifiedby,
                     @_date = modifiedon 
              from 
                     inserted;            

              set @_isupdate = 1;
              set @_action = '_AD_IDS_Update__';
          END
          
          Set @preferenceXmlNew = @_newvalue;
             
          select 
                     @_newvalue = '_AD_IDS_AllowDesktopSchedulingExcel__= ' + @preferenceXmlNew.value('(/Root/AllowDesktopScheduling_Excel)[1]','varchar(50)') + ';'
                     + '_AD_IDS_AllowDesktopSchedulingXml__= ' + @preferenceXmlNew.value('(/Root/AllowDesktopScheduling_Xml)[1]','varchar(50)') + ';'
                     + '_AD_IDS_AllowDesktopSchedulingAccess__= ' + @preferenceXmlNew.value('(/Root/AllowDesktopScheduling_Access)[1]','varchar(50)') + ';'
                     + '_AD_IDS_AllowDesktopSchedulingText__= ' + @preferenceXmlNew.value('(/Root/AllowDesktopScheduling_Text)[1]','varchar(50)') + ';'
                     + '_AD_IDS_MoveToRunCompletedDocLib__=' + @preferenceXmlNew.value('(/Root/MoveToRunCompletedDocLib)[1]','varchar(50)') + ';'
                     + '_AD_IDS_ServiceAccountforWorker__=' + @preferenceXmlNew.value('(/Root/AppPool)[1]','varchar(50)') + ';'
                     + '_AD_IDS_SystemAccount__=' + @preferenceXmlNew.value('(/Root/SystemAccount)[1]','varchar(50)') + ';'
                     + '_AD_IDS_QsSPUserName__=' + @preferenceXmlNew.value('(/Root/UserName)[1]','varchar(50)') + ';'
                     + '_AD_IDS_QsSPPassword__=' + @preferenceXmlNew.value('(/Root/Password)[1]','varchar(50)') + ';'
                     + '_AD_IDS_QsSQLUserName__=' + @preferenceXmlNew.value('(/Root/SQLUserName)[1]','varchar(50)') + ';'
                     + '_AD_IDS_QsSQLPassword__=' + @preferenceXmlNew.value('(/Root/SQLPassword)[1]','varchar(50)') + ';'
          
          if @_isupdate = 0
       begin  
              select @_username = createdby, @_date = createdon from inserted;
              set @_action = '_AD_IDS_Create__';
       end
         if @_oldvalue != @_newvalue
          insert into 
              auditlog
              (
                     createdon, 
                     username, 
                     activity, 
                     configurationtype, 
                     newvalues, 
                     oldvalues,
                     siteidentifier
              ) 
              values
              (
                     @_date, 
                     @_username, 
                     @_action, 
                     '_AD_IDS_QuerySitePrefs__', 
                     @_newvalue, 
                     @_oldvalue,
                     @_siteidentifier
              );
          
          END


           
          ELSE IF @_configurationtype = 'authorizationfields'
          BEGIN
          
        
              SET @_oldvalueXml = CONVERT(XML, @_oldvalue);
           SET @_newvalueXml = CONVERT(XML, @_newvalue);
           
         DECLARE @AuthorizationFieldID as int
              DECLARE @XML1 TABLE(AuthorizationFieldId int Identity(1,1) , TableName varchar(50), ObjectName varchar(50), FieldName varchar(50), FieldText varchar(100), AuthoText varchar(256), value nvarchar(max))
DECLARE @XML2 TABLE(AuthorizationFieldId int Identity(1,1) , TableName varchar(50), ObjectName varchar(50), FieldName varchar(50), FieldText varchar(100), AuthoText varchar(256), value nvarchar(max))

                                                              
                           insert into @XML1 select
                           T.N.value('TableName[1]', 'nvarchar(100)') as TableName,
                           T.N.value('ObjectName[1]', 'nvarchar(100)') as ObjectName,
                           T.N.value('FieldName[1]', 'nvarchar(100)') as FieldName,
                           T.N.value('FieldText[1]', 'nvarchar(100)') as FieldText,
                           T.N.value('AuthoText[1]', 'nvarchar(256)') as AuthoText,
                                         T.N.value('.', 'nvarchar(max)') as Value
                             from @_oldvalueXml.nodes('/Root/AuthorizationField') as T(N) 
                                                                             
                                                 insert into @XML2 select
                             T.N.value('TableName[1]', 'nvarchar(100)') as TableName,
                           T.N.value('ObjectName[1]', 'nvarchar(100)') as ObjectName,
                           T.N.value('FieldName[1]', 'nvarchar(100)') as FieldName,
                           T.N.value('FieldText[1]', 'nvarchar(100)') as FieldText,
                           T.N.value('AuthoText[1]', 'nvarchar(256)') as AuthoText,
                                         T.N.value('.', 'nvarchar(max)') as Value
                             from @_newvalueXml.nodes('/Root/AuthorizationField') as T(N) 

                     DECLARE @CountOld as int
                     DECLARE @CountNew as int
                     select @CountOld = COUNT(*) from @XML1
                     select @CountNew = COUNT(*) from @XML2
                     
                      IF @CountOld > @CountNew
                     BEGIN
                     set @_action = '_AD_IDS_Delete__'; 
                       SELECT @AuthorizationFieldID = x.AuthorizationFieldId from @XML1 x where x.value not in (select value from @XML2) 
                       SET @_oldvalue = '_AD_IDS_TableName__=' +  (select TableName from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) + 
                                                       '; _AD_IDS_ObjectName__='+  ( select ObjectName from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                       '; _AD_IDS_FieldName__=' +  (select FieldName from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                       '; _AD_IDS_FieldText__=' +  (select FieldText from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                       '; _AD_IDS_AuthorizationText__=' +  (select AuthoText from @XML1 where AuthorizationFieldId = @AuthorizationFieldID)
                       Set @_newvalue = '' 
                      END
                     ELSE If @CountOld < @CountNew
                     BEGIN
                     set @_action = '_AD_IDS_Create__';
                     SELECT @AuthorizationFieldID = x.AuthorizationFieldId from @XML2 x where x.value not in (select value from @XML1) 
                       SET @_newvalue = '_AD_IDS_TableName__='+  (  select TableName from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) + 
                                                       '; _AD_IDS_ObjectName__=' +  (select ObjectName from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                       '; _AD_IDS_FieldName__=' +  (select FieldName from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                       '; _AD_IDS_FieldText__=' +  (select FieldText from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                       '; _AD_IDS_AuthorizationText__=' +  (select AuthoText from @XML2 where AuthorizationFieldId = @AuthorizationFieldID)
                       Set @_oldvalue = '' 
                     END
                     ELSE
                     BEGIN
                     set @_action = '_AD_IDS_Update__';
                     
                     SELECT  @AuthorizationFieldID = x2.AuthorizationFieldId FROM @XML2 x2,@XML1 x1 WHERE x2.AuthorizationFieldId = x1.AuthorizationFieldId AND x1.value != x2.value
                     
                     SET @_oldvalue = '_AD_IDS_TableName__=' +  (select TableName from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) + 
                                                       '; _AD_IDS_ObjectName__='+  ( select ObjectName from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                       '; _AD_IDS_FieldName__=' +  (select FieldName from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                       '; _AD_IDS_FieldText__=' +  (select FieldText from @XML1 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                       '; _AD_IDS_AuthorizationText__=' +  (select AuthoText from @XML1 where AuthorizationFieldId = @AuthorizationFieldID)
                                                       
                        SET @_newvalue = '_AD_IDS_TableName__='+  (  select TableName from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) + 
                                                       '; _AD_IDS_ObjectName__=' +  (select ObjectName from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                       '; _AD_IDS_FieldName__=' +  (select FieldName from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                       '; _AD_IDS_FieldText__=' +  (select FieldText from @XML2 where AuthorizationFieldId = @AuthorizationFieldID) +
                                                       '; _AD_IDS_AuthorizationText__=' +  (select AuthoText from @XML2 where AuthorizationFieldId = @AuthorizationFieldID)
                       
                     END


          insert into 
              auditlog
              (
                     createdon, 
                     username, 
                     activity, 
                     configurationtype, 
                     newvalues, 
                     oldvalues,
                     siteidentifier
              ) 
              values
              (
                     @_date, 
                     @_username, 
                     @_action, 
                     '_AD_IDS_AuthFields__', 
                     @_newvalue, 
                     @_oldvalue,
                     @_siteidentifier
              );
           
          END
          
          
          ELSE IF @_configurationtype = 'foundationpreference'
           BEGIN        
          
          if(@_isupdate = 1)
          BEGIN         
           Set @preferenceXmlOld = @_oldvalue;
                               
          select  
                     @_oldvalue = '_AD_IDS_CentralizedDDA__= ' + @preferenceXmlOld.value('(/Root/GenCentralizedDataDictionaryUsage)[1]','varchar(10)') + ';'
                     + '_AD_IDS_AllowSelfApproval__= ' + @preferenceXmlOld.value('(/Root/GenAllowSelfApprovalonTRANSACTIONScripts)[1]','varchar(10)') + ';'
                     + '_AD_IDS_QsScriptApproval__= ' + @preferenceXmlOld.value('(/Root/GenQueryScriptApproval)[1]','varchar(10)') + '; '
                     + '_AD_IDS_QueryThrottling__= ' + @preferenceXmlOld.value('(/Root/GenEnableAdaptiveQueryThrottling)[1]','varchar(10)') + ';'
                     + '_AD_IDS_QueryRejectReasonRequired__= ' + @preferenceXmlOld.value('(/Root/RequireRejectionReasonForQueryScript)[1]','varchar(10)') + ';'
                     + '_AD_IDS_AllowSelfApproval__=' + @preferenceXmlOld.value('(/Root/GenAllowSelfApprovalonQUERYScripts)[1]','varchar(10)') + '; '
                     + '_AD_IDS_TxScriptApproval__=' + @preferenceXmlOld.value('(/Root/GenTransactionWorkflowrequired)[1]','varchar(10)') + ';'
                     + '_AD_IDS_SaveToCENTRAL__=' + @preferenceXmlOld.value('(/Root/GenSavetoCENTRAL)[1]','varchar(10)') + '; '
                     + '_AD_IDS_RunOnErrors__=' + @preferenceXmlOld.value('(/Root/GenRunTransactionScriptswitherrors)[1]','varchar(10)') + ';'
                     + '_AD_IDS_RunReasonReqd__=' + @preferenceXmlOld.value('(/Root/GenRunTransactionScriptreasonrequired)[1]','varchar(10)') + ';'               
                     + '_AD_IDS_TxrRejectReasonRequired__=' + @preferenceXmlOld.value('(/Root/RequireRejectionReasonForTransactionScript)[1]','varchar(10)') + ';'
                     + '_AD_IDS_AllowRevisionOfFiles__=' + @preferenceXmlOld.value('(/Root/GenAllowRevisionofDataTemplates)[1]','varchar(10)') + ';'
                     + 'Allow User to Manage string Padding of Criteria =' + @preferenceXmlOld.value('(/Root/GenAllowUsertoManagestringPaddingofCriteria)[1]','varchar(10)') + ';'
                     + 'Remove Central Workflows =' + @preferenceXmlOld.value('(/Root/RemoveCentralWorkflows)[1]','varchar(10)') + ';'
                     + '_AD_IDS_DataRejectReasonRequired__=' + @preferenceXmlOld.value('(/Root/RequireRejectionReasonForTransactionDataFile)[1]','varchar(10)')
                     + 'Enable Property Promotion =' + @preferenceXmlOld.value('(/Root/GenPropertyPromotion)[1]','varchar(10)') + ';'
                     + 'Enable Auto-Run Success Email = ' + @preferenceXmlOld.value('(/Root/GenAutorunSuccessEmail)[1]','varchar(10)') + ';'
                     + 'Enable Auto-Run Error Email = ' + @preferenceXmlOld.value('(/Root/GenAutorunFailureEmail)[1]','varchar(10)') + ';'                
                     + 'Control version of Data Templates = ' + @preferenceXmlOld.value('(/Root/GenControlVersionofDataTemplates)[1]','varchar(10)') + ';'             
                     + '_AD_IDS_schedulewithchangedsettings__ =' + @preferenceXmlOld.value('(/Root/GenAllowScheduleWithChangedSettings)[1]','varchar(10)') + ';'
                     + '_AD_IDS_RestrictGUIfilesonServer__ =' + @preferenceXmlOld.value('(/Root/GenRestrictGuiFileOnServer)[1]','varchar(10)') + ';'
                     
                     

                     
          IF  @preferenceXmlOld.value('(/Root/GenEnableItemLevelPermissions)[1]','varchar(50)') IS NOT NULL 
        Begin
           SET @_oldvalue = @_oldvalue + '_AD_IDS_EnableItemLevelPermissions__=' + @preferenceXmlOld.value('(/Root/GenEnableItemLevelPermissions)[1]','varchar(10)') + ';'
              END


          select 
                     @_username = modifiedby,
                     @_date = modifiedon 
              from 
                     inserted;            

              set @_isupdate = 1;
              set @_action = '_AD_IDS_Update__';
          END
          
          Set @preferenceXmlNew = @_newvalue;
          
        

            
          
          select 
                     @_newvalue = '_AD_IDS_CentralizedDDA__= ' + @preferenceXmlNew.value('(/Root/GenCentralizedDataDictionaryUsage)[1]','varchar(50)') + ';'
                     + '_AD_IDS_AllowSelfApproval__= ' + @preferenceXmlNew.value('(/Root/GenAllowSelfApprovalonTRANSACTIONScripts)[1]','varchar(50)') + ';'
                     + '_AD_IDS_QsScriptApproval__= ' + @preferenceXmlNew.value('(/Root/GenQueryScriptApproval)[1]','varchar(50)') + '; '
                     + '_AD_IDS_QueryThrottling__= ' + @preferenceXmlNew.value('(/Root/GenEnableAdaptiveQueryThrottling)[1]','varchar(50)') + ';'
                     + '_AD_IDS_QueryRejectReasonRequired__= ' + @preferenceXmlNew.value('(/Root/RequireRejectionReasonForQueryScript)[1]','varchar(50)') + ';'
                     + '_AD_IDS_AllowSelfApproval__=' + @preferenceXmlNew.value('(/Root/GenAllowSelfApprovalonQUERYScripts)[1]','varchar(50)') + '; '
                     + '_AD_IDS_TxScriptApproval__=' + @preferenceXmlNew.value('(/Root/GenTransactionWorkflowrequired)[1]','varchar(50)') + ';'
                     + '_AD_IDS_SaveToCENTRAL__=' + @preferenceXmlNew.value('(/Root/GenSavetoCENTRAL)[1]','varchar(50)') + '; '
                     + '_AD_IDS_RunOnErrors__=' + @preferenceXmlNew.value('(/Root/GenRunTransactionScriptswitherrors)[1]','varchar(50)') + ';'
                     + '_AD_IDS_RunReasonReqd__=' + @preferenceXmlNew.value('(/Root/GenRunTransactionScriptreasonrequired)[1]','varchar(50)') + ';'               
                     + '_AD_IDS_TxrRejectReasonRequired__=' + @preferenceXmlNew.value('(/Root/RequireRejectionReasonForTransactionScript)[1]','varchar(50)') + ';'
                     + '_AD_IDS_AllowRevisionOfFiles__=' + @preferenceXmlNew.value('(/Root/GenAllowRevisionofDataTemplates)[1]','varchar(50)') + ';'
                     + 'Allow User to Manage string Padding of Criteria =' + @preferenceXmlNew.value('(/Root/GenAllowUsertoManagestringPaddingofCriteria)[1]','varchar(50)') + ';'
                     + 'Remove Central Workflows =' + @preferenceXmlNew.value('(/Root/RemoveCentralWorkflows)[1]','varchar(50)') + ';'
                     + '_AD_IDS_DataRejectReasonRequired__=' + @preferenceXmlNew.value('(/Root/RequireRejectionReasonForTransactionDataFile)[1]','varchar(50)')
                     + 'Enable Property Promotion =' + @preferenceXmlNew.value('(/Root/GenPropertyPromotion)[1]','varchar(50)') + ';'
                     + 'Enable Auto-Run Success Email = ' + @preferenceXmlNew.value('(/Root/GenAutorunSuccessEmail)[1]','varchar(50)') + ';'
                     + 'Enable Auto-Run Error Email = ' + @preferenceXmlNew.value('(/Root/GenAutorunFailureEmail)[1]','varchar(50)') + ';'                
                     + 'Control version of Data Templates = ' + @preferenceXmlNew.value('(/Root/GenControlVersionofDataTemplates)[1]','varchar(50)') + ';'
                     + '_AD_IDS_schedulewithchangedsettings__ =' + @preferenceXmlNew.value('(/Root/GenAllowScheduleWithChangedSettings)[1]','varchar(10)') + ';'
                     + '_AD_IDS_RestrictGUIfilesonServer__ =' + @preferenceXmlNew.value('(/Root/GenRestrictGuiFileOnServer)[1]','varchar(10)') + ';'
                     
          
           IF  @preferenceXmlNew.value('(/Root/GenEnableItemLevelPermissions)[1]','varchar(50)') IS NOT NULL 
        Begin
           SET @_newvalue = @_newvalue + '_AD_IDS_EnableItemLevelPermissions__=' + @preferenceXmlNew.value('(/Root/GenEnableItemLevelPermissions)[1]','varchar(10)') + ';'
              END

          if @_isupdate = 0
       begin  
           set @_oldvalue = ''
              select @_username = createdby, @_date = createdon from inserted;
              set @_action = '_AD_IDS_Create__';
       end    
         if @_oldvalue != @_newvalue
          insert into 
              auditlog
              (
                     createdon, 
                     username, 
                     activity, 
                     configurationtype, 
                     newvalues, 
                     oldvalues,
                     siteidentifier
              ) 
              values
              (
                     @_date, 
                     @_username, 
                     @_action, 
                     '_AD_IDS_FoundationSitePrefs__', 
                     @_newvalue, 
                     @_oldvalue,
                     @_siteidentifier
              );
          
          END
          
       ELSE
       
       BEGIN
       if @_oldvalue != @_newvalue
       insert into 
              auditlog
              (
                     createdon, 
                     username, 
                     activity, 
                     configurationtype, 
                     newvalues, 
                     oldvalues,
                     siteidentifier
              ) 
              values
              (
                     @_date, 
                     @_username, 
                     @_action, 
                     '_AD_IDS_AuthorizationFieldsSettings__', 
                     @_newvalue, 
                     @_oldvalue,
                     @_siteidentifier
              );
       
       END
END


GO

