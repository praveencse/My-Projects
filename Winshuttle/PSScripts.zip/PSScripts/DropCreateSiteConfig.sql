


/********* Create Scripts for New Tables start from Here *******************/

drop table  SiteConfiguration

/****** Object:  Table [dbo].[SiteConfiguration]    Script Date: 08/22/2012 12:03:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SiteConfiguration](
	[SiteConfigurationId] [int] IDENTITY(1,1) NOT NULL,
	[ConfigurationKey] [nvarchar](200) NOT NULL,
	[Value] [nvarchar](max) NULL,
	[SiteIdentifier] [uniqueidentifier] NOT NULL,
	[CreatedBy] [nvarchar](200) NULL,
	[CreatedOn] [datetime] NULL,
	[ModifiedBy] [nvarchar](200) NULL,
	[ModifiedOn] [datetime] NULL,
 CONSTRAINT [PK_SiteConfiguration] PRIMARY KEY CLUSTERED 
(
	[ConfigurationKey] ASC,
	[SiteIdentifier] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)  
)  


GO


/********* Create Scripts for New Tables Ends from Here *******************/


