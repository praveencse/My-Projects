﻿<#.SYNOPSIS
Enable Git SourceControl for Webapp and slots and publishes code/binaries respectively.
.DESCRIPTION
Enable Git SourceControl for Webapp and slots and publishes code/binaries respectively.
Throws an exception if the fails.
.EXAMPLE
.\7-Provision-Publish -JsonFilePath $JsonFilePath -ProvisionAcctName $ProvisionAcctName -SlotName $SlotName 
	
.NOTES
Author:		Padma Peddigari
Version:    1.1
#>


param(
    
   
    [string]$JsonFilePath=$(throw "Please pass the input json file" ),
    [string]$ProvisionAcctName=$(throw "Please pass the account name for provisioning"),
    [string]$SlotName=$(throw "Please pass the SlotName")


)


Function Provision-Publish
{

try
{
            # reading the Json file with given username and Password
            $jsonFile=[string]::Concat("\json\",$ProvisionAcctName,"-",$SlotName,"-ProvisionData.json")
            $ProvisionData=Join-Path $JsonFilePath $jsonFile -ErrorAction Stop
            $Content= ConvertFrom-Json -InputObject (gc $ProvisionData -Raw) -ErrorAction Stop
            
            # Decrypting Sunscription Username and password

            $executablesPath= Join-Path $JsonFilePath "\Executable"

            $DecryptexePath= Join-Path $executablesPath "Decrypt\Decrypt.exe"

            $subusername=$Content.'Provisioninfo'.SubscriptionUsername
            $subpassword=$Content.'Provisioninfo'.SubscriptionPassword
            $SubID=$Content.'Provisioninfo'.SubscriptionId

            $Serviceusername = & $DecryptexePath 'W1n$hutt13C10ud' $subusername
            $Servicepassword = & $DecryptexePath 'W1n$hutt13C10ud' $subpassword

            
           
            $secpasswd = ConvertTo-SecureString $Servicepassword -AsPlainText -Force
            $credential = New-Object -TypeName System.Management.Automation.PSCredential ($Serviceusername, $secpasswd)
            $cred = Get-Credential -cred $credential


            Write-Host "Authenticating to azure" -ForegroundColor Green
            $account = Add-AzureRmAccount -Credential $cred -ErrorAction Stop -SubscriptionId $SubID

            #Reading ProvisionData json file for inputs and assining to variables

            

            $ProviderApiVersion= $Content.Configuration.ApiVersion;
             $BuildVersion=$content.'Provisioninfo'.BuildVersion;
            $BuildPath=$Content.Provisioninfo.BuildPath;
           $SourePath=[string]::Concat($BuildPath,"\",$BuildVersion,"\Publish","\Site");
            $ResourceGroupNamePrimary=$Content.Provisioninfo.ResourceGroupsName;
            $IsHA=$Content.Provisioninfo.IsHA;
            $AzureSiteName=$Content.Provisioninfo.AzureSiteName;
            $SubscriptionId=$Content.Provisioninfo.SubscriptionId;


            # Setting ResourceId for slot

            if($SlotName -ne "Production")
            {  $ResourceId = "/subscriptions/$SubscriptionId/resourcegroups/$ResourceGroupNamePrimary/providers/Microsoft.Web/sites/$AzureSiteName/slots/$SlotName/Config/web"}
            else
            {  $ResourceId ="/subscriptions/$SubscriptionId/resourcegroups/$ResourceGroupNamePrimary/providers/Microsoft.Web/sites/$AzureSiteName/Config/web"}


            # Setting SourceControl to LocalGIt 

            Write-Host "Configuring SourceControl to LocalGit to $AzureSiteName [$SlotName Slot] Primary Website" -ForegroundColor Green
            $a = Get-AzureRmResource -ResourceId $ResourceId -ApiVersion 2015-08-01
            $a.Properties.scmType = "LocalGit"
            Set-AzureRmResource -PropertyObject $a.Properties -ResourceId $ResourceId -ApiVersion $ProviderApiVersion -Force



            [xml]$xml=(Get-AzureRmWebAppSlotPublishingProfile -Name $AzureSiteName -ResourceGroupName $ResourceGroupNamePrimary -Slot $SlotName -OutputFile null )

            $username = $xml.SelectNodes("//publishProfile[@publishMethod=`"MSDeploy`"]/@userName").value
            $password = $xml.SelectNodes("//publishProfile[@publishMethod=`"MSDeploy`"]/@userPWD").value

            # Add the Azure remote to your local Git respository and push your code

            Write-Host "Initializing Git and publishing code to Primary Website for $SlotName" -ForegroundColor Green

            Write-Host "Publishing GIT URL for $AzureSiteName $SlotName Slot [Primary WebApp] : "$GITURL -ForegroundColor Yellow
            
            Set-Location $SourePath

            if(Test-Path -Path .\.git){Remove-Item -Path .\.git -Recurse -Force} else {Write-Host "No git Repo"}

            if(!(Test-Path -Path .\.git)){git init}
             Write-Host "$SlotName"

             if($SlotName -eq "Production") 
             {
            
                 git remote add $AzureSiteName "https://${username}:$password@$AzureSiteName.scm.azurewebsites.net"
                
             }
             else 
             {
             
              git remote add $AzureSiteName "https://${username}:$password@$AzureSiteName-$SlotName.scm.azurewebsites.net"
             }

            
            git  add *

            git  commit -m ' Initial Provisioning '  
            git push $AzureSiteName master
            
            <#

            # CREATING GIT WINDOWS CREDENTAIL FOR PRIMARY WEBSITE
             if($SlotName -ne 'Production') 
             {
                $GitSiteName=[string]::Concat($Content.'Provisioninfo'.AzureSiteName,"-",$Content.'Provisioninfo'.Slot_name); 
                AddCred $GitSiteName
             }
             else 
             {  $GitSiteName = $Content.'Provisioninfo'.AzureSiteName;
                AddCred $GitSiteName
             }

            $GITURL= [STRING]::Concat("https://DevProvisioningUser@",$GitSiteName,".scm.azurewebsites.net:443/",$AzureSiteName,".git");
            

            Write-Host "Initializing Git and publishing code to Primary Website for $SlotName" -ForegroundColor Green

            Write-Host "Publishing GIT URL for $AzureSiteName $SlotName Slot [Primary WebApp] : "$GITURL -ForegroundColor Yellow
            
            Set-Location $SourePath

            if(Test-Path -Path .\.git){Remove-Item -Path .\.git -Recurse -Force} else {Write-Host "No git Repo"}

            if(!(Test-Path -Path .\.git)){git init}

            #git  init
             
            git  remote add $GitSiteName $GITURL
            
            git  add *

            git  commit -m ' Initial Provisioning '           

            git  push $GitSiteName master -f      
            
            Start-Sleep -Seconds 5

            DeleteCred($GitSiteName)#>

            IF($slotname -eq "Development" -or $SlotName -eq "Production")
            {
                   
                   
                   if($SlotName -eq "Development")
                   {
                     $tempslotname="Temp"
                   }

                   if($SlotName -eq "Production")
                   {
                     $tempslotname="BackUp"
                   }

                      # Setting ResourceId for Temp slot
                    $ResourceIdTemp = "/subscriptions/$SubscriptionId/resourcegroups/$ResourceGroupNamePrimary/providers/Microsoft.Web/sites/$AzureSiteName/slots/$tempslotname/Config/web"

                     # Setting SourceControl to LocalGIt 

                    Write-Host "Configuring SourceControl to LocalGit to $AzureSiteName [$tempslotname Slot] Primary Website" -ForegroundColor Green

                    $atemp = Get-AzureRmResource -ResourceId $ResourceIdTemp -ApiVersion 2015-08-01
                    $atemp.Properties.scmType = "LocalGit"
                    Set-AzureRmResource -PropertyObject $atemp.Properties -ResourceId $ResourceIdTemp -ApiVersion $ProviderApiVersion -Force

                    [xml]$xml=(Get-AzureRmWebAppSlotPublishingProfile -Name $AzureSiteName -ResourceGroupName $ResourceGroupNamePrimary -Slot "$tempslotname" -OutputFile null )

                    $username1 = $xml.SelectNodes("//publishProfile[@publishMethod=`"MSDeploy`"]/@userName").value
                    $password1 = $xml.SelectNodes("//publishProfile[@publishMethod=`"MSDeploy`"]/@userPWD").value

                    # Add the Azure remote to your local Git respository and push your code

                    Write-Host "Initializing Git and publishing code to Primary Website for Temp" -ForegroundColor Green

                    Write-Host "Publishing GIT URL for $AzureSiteName $tempslotname Slot [Primary WebApp] : " -ForegroundColor Yellow
            
                    Set-Location $SourePath

                    if(Test-Path -Path .\.git){Remove-Item -Path .\.git -Recurse -Force} else {Write-Host "No git Repo"}

                    if(!(Test-Path -Path .\.git)){git init}
                     Write-Host "$SlotName"

                     
             
                      git remote add $AzureSiteName "https://${username1}:$password1@$AzureSiteName-$tempslotname.scm.azurewebsites.net"
                     

            
                    git  add *

                    git  commit -m ' Initial Provisioning '  
                    git push $AzureSiteName master
             
            }
          

    if($IsHA -eq "True")
            {
             
             $SecondaryWebsite=$Content.Provisioninfo.SecondaryAzureSiteName

             $ResourceGroupsNameSecondary=$Content.Provisioninfo.ResourceGroupsNameSecondary;

             
                if($SlotName -ne "Production")
                {
            
                $ResourceId = "/subscriptions/$SubscriptionId/resourcegroups/$ResourceGroupsNameSecondary/providers/Microsoft.Web/sites/$SecondaryWebsite/slots/$SlotName/Config/web"
                }
                else
                {
                 $ResourceId ="/subscriptions/$SubscriptionId/resourcegroups/$ResourceGroupsNameSecondary/providers/Microsoft.Web/sites/$SecondaryWebsite/Config/web"
                }



               Write-Host "Configuring SourceControl to LocalGit to $SecondaryWebsite [$SlotName Slot] Secondary Website" -ForegroundColor Green

               $a2 = Get-AzureRmResource -ResourceId $ResourceId -ApiVersion $ProviderApiVersion -ErrorAction Stop

               $a2.Properties.scmType = "LocalGit"
               
               Set-AzureRmResource -PropertyObject $a.Properties -ResourceId $ResourceId -ApiVersion $ProviderApiVersion -Force -ErrorAction Stop

                Write-Host "Initializing Git and publishing code to $SecondaryWebsite $SlotName Slot [Secondary WebApp]" -ForegroundColor Green
                 
                 [xml]$xml1=(Get-AzureRmWebAppSlotPublishingProfile -Name $SecondaryWebsite -ResourceGroupName $ResourceGroupsNameSecondary -Slot $SlotName -OutputFile null )

            $username1 = $xml1.SelectNodes("//publishProfile[@publishMethod=`"MSDeploy`"]/@userName").value
            $password1 = $xml1.SelectNodes("//publishProfile[@publishMethod=`"MSDeploy`"]/@userPWD").value

             Set-Location $SourePath

               if(Test-Path -Path .\.git){Remove-Item -Path .\.git -Recurse -Force} else {Write-Host "No git Repo"}
   
                    if(!(Test-Path -Path .\.git)){git init}

            # Add the Azure remote to your local Git respository and push your code
            if($SlotName -eq 'Production') 
                 {
                    git remote add $SecondaryWebsite "https://${username1}:$password1@$SecondaryWebsite.scm.azurewebsites.net"
                 }
                else 
                 {  git remote add $SecondaryWebsite "https://${username1}:$password1@$SecondaryWebsite-$SlotName.scm.azurewebsites.net"
                 }
            
            git  add *
            git  commit -m 'Initial Provisioning'
            git push $SecondaryWebsite master
               <#

                Write-Host "Adding Git Credential to WCM for secondary Website" -ForegroundColor Green

               if($SlotName -ne 'Production') 
                 {
                    $GitSiteName=[string]::Concat($SecondaryWebsite,"-",$Content.'Provisioninfo'.Slot_name); 
                    AddCred $GitSiteName
                 }
                else 
                 {  $GitSiteName = $SecondaryWebsite;
                    AddCred $GitSiteName
                 }
               
               $GITSecondaryURL= [STRING]::Concat("https://DevProvisioningUser@",$GitSiteName,".scm.azurewebsites.net:443/",$SecondaryWebsite,".git");

                Write-Host "Initializing Git and publishing code to $SecondaryWebsite $SlotName Slot [Secondary WebApp]" -ForegroundColor Green

                Write-Host "Publishing GIT URL for $SecondaryWebsite $SlotName Slot [Secondary WebApp] : "$GITSecondaryURL -ForegroundColor Yellow
          
                                    
               Set-Location $SourePath

               if(Test-Path -Path .\.git){Remove-Item -Path .\.git -Recurse -Force} else {Write-Host "No git Repo"}
   
                    if(!(Test-Path -Path .\.git)){git init}

                    git  remote add $SecondaryWebsite $GITSecondaryURL

                    git  add *

                    git  commit -m 'Initial Provisioning'
                    
            
                    git  push $SecondaryWebsite master -f

                    Start-Sleep -Seconds 5
                    
                    DeleteCred($GitSiteName)#>

            #In case of Development we create Temp slot and publish binaries and in case of  Production we create Backup Slot
             IF($slotname -eq "Development" -or $SlotName -eq "Production")
            {
                   
                   
                   if($SlotName -eq "Development")
                   {
                     $tempslotname="Temp"
                   }

                   if($SlotName -eq "Production")
                   {
                     $tempslotname="BackUp"
                   }

                    # Setting ResourceId for Temp slot
                    $ResourceIdTemps = "/subscriptions/$SubscriptionId/resourcegroups/$ResourceGroupsNameSecondary/providers/Microsoft.Web/sites/$SecondaryWebsite/slots/$tempslotname/Config/web"

                    # Setting SourceControl to LocalGIt 

                    Write-Host "Configuring SourceControl to LocalGit to $SecondaryWebsite [$tempslotname Slot] Primary Website" -ForegroundColor Green

                    $atemps = Get-AzureRmResource -ResourceId $ResourceIdTemps -ApiVersion 2015-08-01
                    $atemps.Properties.scmType = "LocalGit"
                    Set-AzureRmResource -PropertyObject $atemps.Properties -ResourceId $ResourceIdTemps -ApiVersion $ProviderApiVersion -Force

                    [xml]$xml=(Get-AzureRmWebAppSlotPublishingProfile -Name $SecondaryWebsite -ResourceGroupName $ResourceGroupsNameSecondary -Slot "$tempslotname" -OutputFile null )

                    $usernames = $xml.SelectNodes("//publishProfile[@publishMethod=`"MSDeploy`"]/@userName").value
                    $passwords = $xml.SelectNodes("//publishProfile[@publishMethod=`"MSDeploy`"]/@userPWD").value

                    # Add the Azure remote to your local Git respository and push your code

                    Write-Host "Initializing Git and publishing code to Secondary Website for Temp" -ForegroundColor Green

                    Write-Host "Publishing GIT URL for $SecondaryWebsite $tempslotname Slot [Secondary WebApp] : " -ForegroundColor Yellow
            
                    Set-Location $SourePath

                    if(Test-Path -Path .\.git){Remove-Item -Path .\.git -Recurse -Force} else {Write-Host "No git Repo"}

                    if(!(Test-Path -Path .\.git)){git init}
                     
                     Write-Host "$SlotName"
                                         
                     git remote add $SecondaryWebsite "https://${usernames}:$passwords@$SecondaryWebsite-$tempslotname.scm.azurewebsites.net"
                     
            
                     git  add *

                     git  commit -m ' Initial Provisioning '  
                     git push $SecondaryWebsite master
             
            }
          
                    

    }

    
}
Catch [System.Exception]
{       
        write-host "Exception Block"
		write-host $_.exception.message
        Exit 1
        
}




}

function AddCred([string]$sitename)
{
    Add-Type -Path 'C:\Program Files\Git\mingw64\libexec\git-core\Microsoft.Alm.Authentication.dll'

    $credentials = New-Object -TypeName Microsoft.Alm.Authentication.Credential('DevProvisioningUser', '$abcde1234')
    $targetUri = New-Object -TypeName Microsoft.Alm.Authentication.TargetUri("https://$sitename.scm.azurewebsites.net")
    $secretStore = New-Object -TypeName Microsoft.Alm.Authentication.SecretStore("git", $null, $null, $null)

    $foundCredentials = $null

    $foundCredentials=$secretStore.ReadCredentials($targetUri) 


    if ($foundCredentials -ne $null) 
    {
        Write-host "Credentials already found, not inserting"
    } 
    else 
    {
        Write-Host "Inserting Git Windows credentials for $sitename"
        Write-host "$secretStore.WriteCredentials($targetUri, $credentials)"

        $secretStore.WriteCredentials($targetUri, $credentials)
    
    }


}


Function DeleteCred ([string]$sitename)
{   

        Add-Type -Path 'C:\Program Files\Git\mingw64\libexec\git-core\Microsoft.Alm.Authentication.dll'

        $credentials = New-Object -TypeName Microsoft.Alm.Authentication.Credential('DevProvisioningUser', '$abcde1234')
        $targetUri = New-Object -TypeName Microsoft.Alm.Authentication.TargetUri("https://$sitename.scm.azurewebsites.net")
        $secretStore = New-Object -TypeName Microsoft.Alm.Authentication.SecretStore("git", $null, $null, $null)

        $foundCredentials=$null

        $foundCredentials=$secretStore.ReadCredentials($targetUri) 

        if ($foundCredentials -ne $null) 
        {
            Write-Host "Deleting Git Stored Windows credentials"
            Write-host "$secretStore.WriteCredentials($targetUri, $credentials)"

            $secretStore.DeleteCredentials($targetUri)
            
        } 
        else 
        {
           Write-host "Credentials not found for deletion"
        }

}

Provision-Publish -JsonFilePath $JsonFilePath -ProvisionAcctName $ProvisionAcctName -SlotName $SlotName