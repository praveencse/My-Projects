﻿<#
.SYNOPSIS
Creates Webjobs and Schedulars to run them.
.DESCRIPTION
Creates Webjobs and Schedulars to run them.
Throws an exception in failure case.
.EXAMPLE
.\Provision-WebJob -JsonFilePath $JsonFilePath -ProvisionAcctName -$ProvisionAcctName -SlotName $SlotName
	
.NOTES
Author:		Padma P Peddigari
Version:    1.1
#>


param(
     
   
    [string]$JsonFilePath=$(throw "Please pass the input Json ProvisionData file" ),
    [string]$ProvisionAcctName=$(throw "Please pass the account name for provisioning"),
    [string]$SlotName=$(throw "Please pass SlotNAme")

)

Function Provision-WebJob
{
 try
 {
            # reading the Json file with given username and Password
            $jsonFile=[string]::Concat("\json\",$ProvisionAcctName,"-",$SlotName,"-ProvisionData.json")
            $ProvisionData=Join-Path $JsonFilePath $jsonFile -ErrorAction Stop
            $Content= ConvertFrom-Json -InputObject (gc $ProvisionData -Raw) -ErrorAction Stop


            # Decrypting Sunscription Username and password

            $executablesPath= Join-Path $JsonFilePath "\Executable"

            $DecryptexePath= Join-Path $executablesPath "Decrypt\Decrypt.exe"

            $subusername=$Content.'Provisioninfo'.SubscriptionUsername
            $subpassword=$Content.'Provisioninfo'.SubscriptionPassword
            $SubID=$Content.'Provisioninfo'.SubscriptionId

            $Serviceusername = & $DecryptexePath 'W1n$hutt13C10ud' $subusername
            $Servicepassword = & $DecryptexePath 'W1n$hutt13C10ud' $subpassword

             # User Id and Password for Slient log-in onto Azure Portal.
           
            #$Serviceusername=$subusername;
            #$Servicepassword=$subpassword;
            $secpasswd = ConvertTo-SecureString $Servicepassword -AsPlainText -Force
            $credential = New-Object -TypeName System.Management.Automation.PSCredential ($Serviceusername, $secpasswd)
            $cred = Get-Credential -cred $credential

            Write-Host "Authenticating to Azure" -ForegroundColor Green
            $account = Add-AzureRmAccount -Credential $cred  -ErrorAction Stop -SubscriptionId $SubID
            $account1=Add-AzureAccount -Credential $cred  -ErrorAction Stop

        
        
       
       
        

        # Switch to Azure mode by using below mentioned command
        #Switch-AzureMode -Name AzureResourceManager 

        #  Execute the below mentioned query to get the required values needed to create the new azure database.

        $AzureSiteName=$Content.Provisioninfo.AzureSiteName;

        $primaryJobcollectionname=$Content.Provisioninfo.primaryJobcollectionname;
        $BuildVersion=$content.'Provisioninfo'.BuildVersion;
        $BuildPath=Join-Path $Content.Provisioninfo.BuildPath $BuildVersion;
        $IsHA=$Content.Provisioninfo.IsHA;
        $WSServiceURL="/api/triggeredwebjobs/WSService/run";
        $WSTimerURL="/api/triggeredwebjobs/WSTimer/run"

        $schedulerResourceGroupPrimary=$Content.Provisioninfo.PrimaryCloudServiceName;

        $WSSerrviceJobFilePath=Join-Path $BuildPath "\publish\site\App_Data\jobs\triggered\WSService\SVConsole_SingleApp.exe";
        $WSTimerJobFilePath=Join-Path $BuildPath "\publish\site\App_Data\jobs\triggered\WSTimer\Winshuttle.Central.Timer.exe";
        #$WSSerrviceJobFilePath="D:\Padma\WSOnline\AutomationScripts\Post\11.00.00150.6113\Site\Site\App_Data\jobs\triggered\WSService\SVConsole_SingleApp.exe";
        #$WSTimerJobFilePath="D:\Padma\WSOnline\AutomationScripts\Post\11.00.00150.6113\Site\Site\App_Data\jobs\triggered\WSTimer\Winshuttle.Central.Timer.exe";

        Clear-AzureProfile -Force 
        $account1=Add-AzureAccount -Credential $cred  -ErrorAction Stop

        

        $PublishingProfile=Get-AzureWebsite -Name $AzureSiteName -Slot $SlotName -ErrorAction Stop
        #$PublishingUsername=$PublishingProfile.PublishingUsername;
        #$PublishingPassword=$PublishingProfile.PublishingPassword;
        #$AuthenticationPair="($PublishingUsername):($PublishingPassword)";

        $WebAppScmhostname=$PublishingProfile.EnabledHostNames | Where-Object {$_.Contains(".scm.azurewebsites.net")}
        #$WSTimerScmhostname=$PublishingProfile.EnabledHostNames | Where-Object {$_.Contains("scm")}
        $WSServiceScmURL=[string]::Concat("https://",$WebAppScmhostname,$WSServiceURL);
        $WSTimerScmURL=[string]::Concat("https://",$WebAppScmhostname,$WSTimerURL);
        #$WSServiceScmURL=[string]::Concat("https://",$AzureSiteName,".scm.azurewebsites.net",$WSServiceURL);
        #$WSTimerScmURL=[string]::Concat("https://",$AzureSiteName,".scm.azurewebsites.net",$WSTimerURL);
        
        $WSServiceSchdlrJobName=[string]::Concat($PublishingProfile.Name,"-","WFService");
        $WSTimerSchdlrJobName=[string]::Concat($PublishingProfile.Name,"-","WSTimer");


        $AuthenticationPair = "$($PublishingProfile.PublishingUsername):$($PublishingProfile.PublishingPassword)";
        $pairBytes = [System.Text.Encoding]::UTF8.GetBytes($AuthenticationPair);
        $encodedPair = [System.Convert]::ToBase64String($pairBytes);
        $WSServiceName="WSService";
        $WSTimerName="WSTimer"


        Write-Host "********* Properties for creating Webjob and schedular for $AzureSiteName ($SlotName) Primary website *********" -ForegroundColor Green
        Write-host "AzureSiteName : "$AzureSiteName -ForegroundColor Yellow
        Write-host "primaryJobcollectionname : "$primaryJobcollectionname -ForegroundColor Yellow
        Write-host "WSServiceURL : "$WSServiceURL -ForegroundColor Yellow
        Write-host "WSTimerURL : "$WSTimerURL -ForegroundColor Yellow
        Write-host "schedulerResourceGroup - Primary : "$schedulerResourceGroupPrimary -ForegroundColor Yellow
        Write-host "WSSerrviceJobFilePath : "$WSSerrviceJobFilePath -ForegroundColor Yellow
        Write-host "WSTimerJobFilePath : "$WSTimerJobFilePath -ForegroundColor Yellow
        Write-host "WSServiceScmURL : "$WSServiceScmURL -ForegroundColor Yellow
        Write-host "WSTimerScmURL : "$WSTimerScmURL -ForegroundColor Yellow
        Write-host "PublishingUsername : "$PublishingUsername -ForegroundColor Yellow
        Write-host "PublishingPassword : "$PublishingPassword -ForegroundColor Yellow
        Write-host "AuthenticationPair : "$AuthenticationPair -ForegroundColor Yellow
        Write-Host "WSServiceSchdlrJobName : "$WSServiceSchdlrJobName -ForegroundColor Yellow
        Write-Host "WSTimerSchdlrJobName : "$WSTimerSchdlrJobName -ForegroundColor Yellow
        Write-Host "IsHA : "$IsHA -ForegroundColor Yellow


        $webjobExists=Get-AzureWebsiteJob -JobName "$WSServiceName" -Name "$AzureSiteName" -JobType Triggered -Slot $SlotNAme -ErrorAction SilentlyContinue

        if($webjobExists -eq $null)
        {
            Write-Host "------------------------------------------------------------------------------" -ForegroundColor Green
            Write-Host " *** Creating WSService Job For $AzureSiteName ($SlotName) Primary Website ***" -ForegroundColor Green
            Write-Host "------------------------------------------------------------------------------" -ForegroundColor Green

            Write-Host "New-AzureWebsiteJob -JobName "$WSServiceName" -Name "$AzureSiteName" -JobType Triggered -JobFile "$WSSerrviceJobFilePath" -Slot $SlotNAme -ErrorAction Stop"
                        New-AzureWebsiteJob -JobName "$WSServiceName" -Name "$AzureSiteName" -JobType Triggered -JobFile "$WSSerrviceJobFilePath" -Slot $SlotNAme -ErrorAction Stop 
            
         }
         else 
         {
          Write-Host "------------------------------------------------------------------------------" -ForegroundColor Green
          Write-Host "$WSServiceName Job for $AzureSiteName ($SlotName) already exists" -ForegroundColor Gray
          Write-Host "------------------------------------------------------------------------------" -ForegroundColor Green
          }

         $webschrjob=Get-AzureRmSchedulerJob -ResourceGroupName "$schedulerResourceGroupPrimary" -JobCollectionName "$primaryJobcollectionname" -JobName "$WSServiceSchdlrJobName" -ErrorAction SilentlyContinue

         if($webschrjob -eq $null)
         {
               Write-Host "-------------------------------------------------------------------------------------" -ForegroundColor Green
               Write-Host "*** Creating Schedular for WSService [$AzureSiteName ($SlotName)] Primary Website ***" -ForegroundColor Green
               Write-Host "-------------------------------------------------------------------------------------" -ForegroundColor Green

               Write-Host "New-AzureRmSchedulerHttpJob -ResourceGroupName "$schedulerResourceGroupPrimary"  -JobCollectionName "$primaryJobcollectionname" -JobName "$WSServiceSchdlrJobName" -Method POST -Uri "$WSServiceScmURL" -StartTime "2014-01-01" -Interval 5 -Frequency Minute -Headers @{"Authorization" = "Basic $encodedPair" } -ErrorAction Stop"
                           New-AzureRmSchedulerHttpJob -ResourceGroupName "$schedulerResourceGroupPrimary"  -JobCollectionName "$primaryJobcollectionname" -JobName "$WSServiceSchdlrJobName" -Method POST -Uri "$WSServiceScmURL" -StartTime "2014-01-01" -Interval 5 -Frequency Minute -Headers @{"Authorization" = "Basic $encodedPair" } -ErrorAction Stop
           #New-AzureRmSchedulerHttpJob -ResourceGroupName CS-WebJobs-SoutheastAsia-scheduler  -JobCollectionName webjobs-southeastasia -JobName wsjenkinstestwinshuttleSEA-WSTimer -Method POST -Uri "https://wsjenkinstestwinshuttleSEA.scm.azurewebsites.net/api/triggeredwebjobs/WSTimer/run" -StartTime  2014-01-01 -Interval 3 -Frequency Minute -Headers @{"Authorization" = "Basic JHdzamVua2luc3Rlc3R3aW5zaHV0dGxlU0VBOmJiWFlLc2Q3UEFZTjh1TmJmdkdzTG41b2F0bnJvWG1oS2pwTlNNU0tyd1JiM1pocUVpbEh1bHd3MnU5Zw==";"Content-Type" = "text/plain" }
         }
         else
          {
          Write-Host "------------------------------------------------------------------------------" -ForegroundColor Green
          Write-Host " $WSServiceSchdlrJobName Schedular for $AzureSiteName ($SlotName) already exists" -ForegroundColor Gray
          Write-Host "------------------------------------------------------------------------------" -ForegroundColor Green
          }

        $webjobExists=Get-AzureWebsiteJob -JobName "$WSTimerName" -Name "$AzureSiteName" -JobType Triggered -Slot $SlotName -ErrorAction SilentlyContinue

        if($webjobExists -eq $null)
        {
            Write-Host "---------------------------------------------------------------------------" -ForegroundColor Green
            Write-Host "*** Creating WSTimer Job For $AzureSiteName ($SlotName) Primary Website ***" -ForegroundColor Green
            Write-Host "---------------------------------------------------------------------------" -ForegroundColor Green

            Write-Host "New-AzureWebsiteJob -JobName "WSTimer" -Name "$AzureSiteName" -JobType Triggered -JobFile "$WSTimerJobFilePath" -Slot $SlotName -ErrorAction Stop"
                        New-AzureWebsiteJob -JobName "WSTimer" -Name "$AzureSiteName" -JobType Triggered -JobFile "$WSTimerJobFilePath" -Slot $SlotName -ErrorAction Stop
        }
        else {
         Write-Host "------------------------------------------------------------------------------" -ForegroundColor Green
         Write-Host "$WSTimerName Job for $AzureSiteName ($SlotName) already exists" -ForegroundColor Gray
         Write-Host "------------------------------------------------------------------------------" -ForegroundColor Green
         }
        $webschrjob=Get-AzureRmSchedulerJob -ResourceGroupName "$schedulerResourceGroupPrimary" -JobCollectionName "$primaryJobcollectionname" -JobName "$WSTimerSchdlrJobName" -ErrorAction SilentlyContinue

         if($webschrjob -eq $null)
         {

            Write-Host "---------------------------------------------------------------------------------------" -ForegroundColor Green
            Write-Host "*** Creating Schedular for WSTimer Job [$AzureSiteName ($SlotName)] Primary Website ***" -ForegroundColor Green
            Write-Host "---------------------------------------------------------------------------------------" -ForegroundColor Green
            Write-Host "New-AzureRmSchedulerHttpJob -ResourceGroupName "$schedulerResourceGroupPrimary"  -JobCollectionName "$primaryJobcollectionname" -JobName "$WSTimerSchdlrJobName" -Method POST -Uri "$WSTimerScmURL" -StartTime "2014-01-01" -Interval 3 -Frequency Minute -Headers @{"Authorization" = "Basic $encodedPair" } -ErrorAction Stop"
                        New-AzureRmSchedulerHttpJob -ResourceGroupName "$schedulerResourceGroupPrimary"  -JobCollectionName "$primaryJobcollectionname" -JobName "$WSTimerSchdlrJobName" -Method POST -Uri "$WSTimerScmURL" -StartTime "2014-01-01" -Interval 3 -Frequency Minute -Headers @{"Authorization" = "Basic $encodedPair" } -ErrorAction Stop
         }
         else {
          Write-Host "------------------------------------------------------------------------------" -ForegroundColor Green
          Write-Host " $WSTimerSchdlrJobName Schedular for $AzureSiteName ($SlotName) already exists" -ForegroundColor Gray
          Write-Host "------------------------------------------------------------------------------" -ForegroundColor Green
          }


        if ($IsHA -eq "True")
        {

                $SecondaryWebsite=$Content.Provisioninfo.SecondaryAzureSiteName
                 
                $SecondaryJobcollectionname=$Content.Provisioninfo.SecondaryJobcollectionname;
                $schedulerResourceGroupSecondary=$Content.Provisioninfo.SecondaryCloudServiceName;

                $SecondaryPublishingProfile=Get-AzureWebsite -Name $SecondaryWebsite -Slot $SlotName -ErrorAction Stop
                $SecondaryPublishingUsername=$SecondaryPublishingProfile.PublishingUsername;
                $SecondaryPublishingPassword=$SecondaryPublishingProfile.PublishingPassword;

                $AuthenticationPairSecondary = "$($SecondaryPublishingProfile.PublishingUsername):$($SecondaryPublishingProfile.PublishingPassword)";
                $pairBytesSecondary = [System.Text.Encoding]::UTF8.GetBytes($AuthenticationPairSecondary);
                $encodedPairSecondary = [System.Convert]::ToBase64String($pairBytesSecondary);

                
                $WSServiceSchdlrJobNameSecondary=[string]::Concat($SecondaryPublishingProfile.Name,"-","WFService");
                $WSTimerSchdlrJobNameSecondary=[string]::Concat($SecondaryPublishingProfile.Name,"-","WSTimer");


                $WebAppScmhostname=$SecondaryPublishingProfile.EnabledHostNames | Where-Object {$_.Contains(".scm.azurewebsites.net")};
                $WSServiceScmURLSecondary=[string]::Concat("https://",$WebAppScmhostname,$WSServiceURL);
                $WSTimerScmURLSecondary=[string]::Concat("https://",$WebAppScmhostname,$WSTimerURL);


                Write-Host "********* Properties for creating Webjob and schedular for $SecondaryWebsite ($SlotName) Secondary website *********" -ForegroundColor Green
                Write-host "AzureSiteName - Secondary :"$SecondaryWebsite
                Write-host "SecondaryJobcollectionname :"$SecondaryJobcollectionname
                Write-host "WSServiceURL :"$WSServiceURL
                Write-host "WSTimerURL :"$WSTimerURL
                Write-host "schedulerResourceGroupSecondary - Primary :"$schedulerResourceGroupSecondary
                Write-host "WSSerrviceJobFilePath :"$WSSerrviceJobFilePath
                Write-host "WSTimerJobFilePath :"$WSTimerJobFilePath
                Write-host "WSServiceScmURLSecondary :"$WSServiceScmURLSecondary
                Write-host "WSTimerScmURLSecondary :"$WSTimerScmURLSecondary
                Write-host "PublishingUsername -Secondary :"$SecondaryPublishingUsername
                Write-host "PublishingPassword -Secondary :"$SecondaryPublishingPassword
                Write-host "AuthenticationPair -Secondary :"$encodedPairSecondary


                   $webjobExists=Get-AzureWebsiteJob -JobName "$WSServiceName" -Name "$SecondaryWebsite" -JobType Triggered -Slot $SlotNAme -ErrorAction SilentlyContinue

                    if($webjobExists -eq $null)
                    {
                        Write-Host "-----------------------------------------------------------------------------------------" -ForegroundColor Green
                        Write-Host " *** Creating WSService Job For $SecondaryWebsite ($SlotName) Secondary Website *** " -ForegroundColor Green
                        Write-Host "-----------------------------------------------------------------------------------------" -ForegroundColor Green

                        Write-Host "New-AzureWebsiteJob -JobName "$WSServiceName" -Name "$SecondaryWebsite" -JobType Triggered -JobFile "$WSSerrviceJobFilePath" -Slot $SlotName -ErrorAction Stop"
                                    New-AzureWebsiteJob -JobName "$WSServiceName" -Name "$SecondaryWebsite" -JobType Triggered -JobFile "$WSSerrviceJobFilePath" -Slot $SlotName -ErrorAction Stop
    
                    }
                    
                    else {
                    Write-Host "-----------------------------------------------------------------------------------------" -ForegroundColor Green
                    Write-Host "$WSServiceName Job for $SecondaryWebsite ($SlotName) already exists" -ForegroundColor Gray
                    Write-Host "-----------------------------------------------------------------------------------------" -ForegroundColor Green
                    }

                    $webschrjob=Get-AzureRmSchedulerJob -ResourceGroupName "$schedulerResourceGroupSecondary" -JobCollectionName "$SecondaryJobcollectionname" -JobName "$WSServiceSchdlrJobNameSecondary" -ErrorAction SilentlyContinue

                    if($webschrjob -eq $null)
                    {
                        Write-Host "---------------------------------------------------------------------------------------------------" -ForegroundColor Green
                        Write-Host "*** Creating Schedular for WSService job [$SecondaryWebsite ($SlotName)] Secondary Website ***" -ForegroundColor Green
                        Write-Host "---------------------------------------------------------------------------------------------------" -ForegroundColor Green

                        Write-Host "New-AzureRmSchedulerHttpJob -ResourceGroupName "$schedulerResourceGroupSecondary"  -JobCollectionName "$SecondaryJobcollectionname" -JobName "$WSServiceSchdlrJobNameSecondary" -Method POST -Uri "$WSServiceScmURLSecondary" -StartTime "2014-01-01" -Interval 5 -Frequency Minute -Headers @{"Authorization" = "Basic $encodedPairSecondary" } -ErrorAction Stop"
                                    New-AzureRmSchedulerHttpJob -ResourceGroupName "$schedulerResourceGroupSecondary"  -JobCollectionName "$SecondaryJobcollectionname" -JobName "$WSServiceSchdlrJobNameSecondary" -Method POST -Uri "$WSServiceScmURLSecondary" -StartTime "2014-01-01" -Interval 5 -Frequency Minute -Headers @{"Authorization" = "Basic $encodedPairSecondary" } -ErrorAction Stop

                    }
                    else {
                    Write-Host "-----------------------------------------------------------------------------------------" -ForegroundColor Green
                    Write-Host " $WSServiceSchdlrJobName Schedular for $SecondaryWebsite ($SlotName) already exists" -ForegroundColor Gray
                    Write-Host "-----------------------------------------------------------------------------------------" -ForegroundColor Green
                    }

                   $webjobExists=Get-AzureWebsiteJob -JobName "$WSTimerName" -Name "$SecondaryWebsite" -JobType Triggered -Slot $SlotNAme -ErrorAction SilentlyContinue

                    if($webjobExists -eq $null)
                    {
                        Write-Host "--------------------------------------------------------------------------------------" -ForegroundColor Green
                        Write-Host " *** Creating WSTimer Job For $SecondaryWebsite ($SlotName) Secondary Website ***" -ForegroundColor Green
                        Write-Host "--------------------------------------------------------------------------------------" -ForegroundColor Green

                        Write-Host "New-AzureWebsiteJob -JobName "$WSTimerName" -Name "$SecondaryWebsite" -JobType Triggered -JobFile "$WSTimerJobFilePath" -Slot $SlotName -ErrorAction Stop"
                                    New-AzureWebsiteJob -JobName "$WSTimerName" -Name "$SecondaryWebsite" -JobType Triggered -JobFile "$WSTimerJobFilePath" -Slot $SlotName -ErrorAction Stop
                    }
                    else {
                    Write-Host "-----------------------------------------------------------------------------------------" -ForegroundColor Green
                    Write-Host "$WSTimerName Job for $SecondaryWebsite ($SlotName) already exists" -ForegroundColor Gray
                    Write-Host "-----------------------------------------------------------------------------------------" -ForegroundColor Green
                    }


                   $webschrjob=Get-AzureRmSchedulerJob -ResourceGroupName "$schedulerResourceGroupSecondary" -JobCollectionName "$SecondaryJobcollectionname" -JobName "$WSTimerSchdlrJobNameSecondary" -ErrorAction SilentlyContinue

                    if($webschrjob -eq $null)
                    {
                        Write-Host "-------------------------------------------------------------------------------------------------" -ForegroundColor Green
                        Write-Host "*** Creating Schedular for WSTimer Job [$SecondaryWebsite ($SlotName)] Secondary Website ***" -ForegroundColor Green
                        Write-Host "-------------------------------------------------------------------------------------------------" -ForegroundColor Green

                        Write-Host "New-AzureRmSchedulerHttpJob -ResourceGroupName "$schedulerResourceGroupSecondary"  -JobCollectionName "$SecondaryJobcollectionname" -JobName "$WSTimerSchdlrJobNameSecondary" -Method POST -Uri "$WSTimerScmURLSecondary" -StartTime "2014-01-01" -Interval 3 -Frequency Minute -Headers @{"Authorization" = "Basic $encodedPairSecondary"} -ErrorAction Stop"
                                    New-AzureRmSchedulerHttpJob -ResourceGroupName "$schedulerResourceGroupSecondary"  -JobCollectionName "$SecondaryJobcollectionname" -JobName "$WSTimerSchdlrJobNameSecondary" -Method POST -Uri "$WSTimerScmURLSecondary" -StartTime "2014-01-01" -Interval 3 -Frequency Minute -Headers @{"Authorization" = "Basic $encodedPairSecondary"} -ErrorAction Stop
                    }
                    else {
                    Write-Host "-----------------------------------------------------------------------------------------" -ForegroundColor Green
                    Write-Host " $WSTimerSchdlrJobName Schedular for $SecondaryWebsite ($SlotName) already exists" -ForegroundColor Gray
                    Write-Host "-----------------------------------------------------------------------------------------" -ForegroundColor Green
                    }


        }
  }
  Catch [System.Exception]
{
       
        write-host "Exception Block"
		write-host $_.exception.message
 Exit 1

        
	}

}

Provision-WebJob -JsonFilePath $JsonFilePath -ProvisionAcctName -$ProvisionAcctName -SlotName $SlotName