﻿<#
.SYNOPSIS
Creates Azure Traffic Manager with Endpoints
.DESCRIPTION
Creates Azure Traffic Manager with Endpoints
Throws an exception if fails.
.EXAMPLE
.\Provision-TrafficManager -JsonFilePath $JsonFilePath -ProvisionAcctName -$ProvisionAcctName -SlotName $SlotName
	
.NOTES
Author:		Padma P Peddigari
Version:    1.1
#>


param(
      
   
    [string]$JsonFilePath=$(throw "Please pass the input Json ProvisionData file" ),
    [string]$ProvisionAcctName=$(throw "Please pass the account name for provisioning"),
    [string]$SlotName=$(throw "Please pass the SlotName")

)

Function Provision-TrafficManager
{
  try
  {
    
        # reading the Json file with given username and Password
        $jsonFile=[string]::Concat("\json\",$ProvisionAcctName,"-",$SlotName,"-ProvisionData.json")
        $ProvisionData=Join-Path $JsonFilePath $jsonFile -ErrorAction Stop
        $Content= ConvertFrom-Json -InputObject (gc $ProvisionData -Raw) -ErrorAction Stop
        
           
        # Decrypt.exe path
        $executablesPath= Join-Path $JsonFilePath "\Executable"
        $DecryptexePath= Join-Path $executablesPath "Decrypt\Decrypt.exe"

        
       
        # Decrypting Sunscription Username and password
        $subusername=$Content.'Provisioninfo'.SubscriptionUsername
        $subpassword=$Content.'Provisioninfo'.SubscriptionPassword
        $SubID=$Content.'Provisioninfo'.SubscriptionId
        
        # User Id and Password to do log-in on Azure Portal.
        $Serviceusername = & $DecryptexePath 'W1n$hutt13C10ud' $subusername
        $Servicepassword = & $DecryptexePath 'W1n$hutt13C10ud' $subpassword 
        $secpasswd = ConvertTo-SecureString $Servicepassword -AsPlainText -Force
        $credential = New-Object -TypeName System.Management.Automation.PSCredential ($Serviceusername, $secpasswd)
        $cred = Get-Credential -cred $credential

        Write-Host "Authenticating to Azure" -ForegroundColor Green
        $account = Add-AzureRMAccount -Credential $cred -ErrorAction Stop -SubscriptionId $SubID

       
       

        $TrafficeManagerName=$Content.Provisioninfo.TrafficeManagerName;
        $MonitorRelativePath="/_layouts/winshuttle.central/ping.aspx"
       
        $LocationPrimary=$Content.Provisioninfo.Location;
        $ResourceGroupsName=$Content.Provisioninfo.ResourceGroupsName;
        $AzureSiteName=$Content.Provisioninfo.AzureSiteName;
        $TrafficmanagerResourceGrp="Default-TrafficManager";
        $IsHA=$Content.Provisioninfo.IsHA;
        #$TrafficeManagerEndPointDomainName=[string]::Concat($Content.Provisioninfo.AzureSiteName,".azurewebsites.net");

        # Switch to Azure mode by using below mentioned command
        #Switch-AzureMode -Name AzureResourceManager 

        
        $webapp=Get-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsName -Name $AzureSiteName -Slot $SlotName -ErrorAction SilentlyContinue
        $TrafficeManagerEndPointDomainName=$webapp.DefaultHostName;
        #$TrafficeManagerProfileDomainName=[string]::Concat($webapp.SiteName,".trafficmanager.net");


        Write-Host " -------------------------------------------------------------------------------------------- " -ForegroundColor Green
        Write-Host " ****** Properties for Creating TrafficManager Profile and Primary Website as EndPoint ****** " -ForegroundColor Green
        Write-Host " -------------------------------------------------------------------------------------------- " -ForegroundColor Green
        Write-host "TrafficeManagerName : "$TrafficeManagerName -ForegroundColor Yellow
        Write-Host "TrafficmanagerResourceGrp : "$TrafficmanagerResourceGrp -ForegroundColor Yellow
        Write-host "MonitorRelativePath : "$MonitorRelativePath -ForegroundColor Yellow
        Write-host "Primary EndPoint : "$TrafficeManagerEndPointDomainName -ForegroundColor Yellow
        Write-host "Primary Location : "$LocationPrimary -ForegroundColor Yellow
        
        #Write-Host "IsHA : "$IsHA
        #Write-host "TrafficeManagerProfileDomainName : "$TrafficeManagerProfileDomainName

        
        
        $Profile=Get-AzureRmTrafficManagerProfile -Name $TrafficeManagerName -ResourceGroupName $TrafficmanagerResourceGrp -ErrorAction SilentlyContinue

        if ($Profile -eq $null)
        {

            Write-Host " ----------------------------------------------------------- " -ForegroundColor Green
            Write-Host " ***** Creating TrafficManager : $TrafficeManagerName  ***** " -ForegroundColor Green
            Write-Host " ----------------------------------------------------------- " -ForegroundColor Green
              
            Write-Host "New-AzureRmTrafficManagerProfile -Name $TrafficeManagerName -ProfileStatus Enabled -ResourceGroupName $TrafficmanagerResourceGrp -RelativeDnsName $TrafficeManagerName -TrafficRoutingMethod Priority -Ttl 30 -MonitorProtocol HTTPS -MonitorPort 443 -MonitorPath $MonitorRelativePath -ErrorAction Stop"
               $Profile=New-AzureRmTrafficManagerProfile -Name $TrafficeManagerName -ProfileStatus Enabled -ResourceGroupName $TrafficmanagerResourceGrp -RelativeDnsName $TrafficeManagerName -TrafficRoutingMethod Priority -Ttl 30 -MonitorProtocol HTTPS -MonitorPort 443 -MonitorPath $MonitorRelativePath -ErrorAction Stop 

        } else {Write-Host "TrafficManager : $TrafficeManagerName already exists" -ForegroundColor Gray}

        
            #Write-Host "Add-AzureTrafficManagerEndpoint -TrafficManagerProfile $Profile -Type AzureWebsite -DomainName $TrafficeManagerEndPointDomainName -Status Enabled | Set-AzureTrafficManagerProfile"
            #Add-AzureTrafficManagerEndpoint -TrafficManagerProfile $Profile -Type AzureWebsite -DomainName $TrafficeManagerEndPointDomainName -Status Enabled | Set-AzureTrafficManagerProfile 
         $webendpntExists=Get-AzureRmTrafficManagerEndpoint -Name $TrafficeManagerEndPointDomainName -ResourceGroupName $TrafficmanagerResourceGrp -Type AzureEndpoints -ProfileName $Profile.Name -ErrorAction SilentlyContinue
            
         if($webendpntExists -eq $null)
           {
               
                $primarywebappid= Get-AzureRmWebAppSlot -Name $AzureSiteName -ResourceGroupName $ResourceGroupsName -Slot $SlotName -ErrorAction Stop
                
                Write-Host " -----------------------------------------------------------------" -ForegroundColor Green
                Write-Host " ***** Adding Primary website to Trafficmanager as Endpoint ***** " -ForegroundColor Green
                Write-Host " -----------------------------------------------------------------" -ForegroundColor Green

                Write-Host "Add-AzureRmTrafficManagerEndpointConfig -EndpointName $TrafficeManagerEndPointDomainName -TrafficManagerProfile $Profile -Type AzureEndpoints -EndpointStatus Enabled -TargetResourceId $primarywebappid.Id -ErrorAction Stop" 
                            Add-AzureRmTrafficManagerEndpointConfig -EndpointName $TrafficeManagerEndPointDomainName -TrafficManagerProfile $Profile -Type AzureEndpoints -EndpointStatus Enabled -TargetResourceId $primarywebappid.Id -ErrorAction Stop
                            Set-AzureRmTrafficManagerProfile -TrafficManagerProfile $Profile -ErrorAction Stop

            } else {Write-Host "Primary Website [$TrafficeManagerEndPointDomainName] is already added as Endpoint to  TrafficManager" -ForegroundColor Yellow}


        if ($IsHA -eq "True")
        {
                $ResourceGroupsNameSecondary=$Content.Provisioninfo.ResourceGroupsNameSecondary;
                $SecondaryWebsite=$Content.Provisioninfo.SecondaryAzureSiteName;
                $SecondaryLocation=$Content.Provisioninfo.SecondaryLocation;
                $webapp2=Get-AzureRmWebAppSlot -ResourceGroupName $ResourceGroupsNameSecondary -Name $SecondaryWebsite -Slot $SlotName -ErrorAction SilentlyContinue
                $TrafficeManagerSecondaryEndPointDomainName=$webapp2.DefaultHostName;
                
               

        Write-Host " -------------------------------------------------------------------------------------------- " -ForegroundColor Green
        Write-Host " ****** Properties for adding Secondary Website as EndPoint ****** " -ForegroundColor Green
        Write-Host " -------------------------------------------------------------------------------------------- " -ForegroundColor Green
        Write-host "TrafficeManagerSecondaryEndPointDomainName : "$TrafficeManagerSecondaryEndPointDomainName
        Write-host "SecondaryLocation : "$SecondaryLocation


        Write-Host "***** Adding Secondary website to Trafficmanager as Endpoint *******" -ForegroundColor Green
        #$Profile= Get-AzureTrafficManagerProfile -Name $TrafficeManagerName
        #Write-Host "Add-AzureTrafficManagerEndpoint -TrafficManagerProfile $profile1 -Type AzureWebsite -DomainName "$TrafficeManagerSecondaryEndPointDomainName" -Status Enabled  | Set-AzureTrafficManagerProfile"
        #Add-AzureTrafficManagerEndpoint -TrafficManagerProfile $profile1 -Type AzureWebsite -DomainName "$TrafficeManagerSecondaryEndPointDomainName" -Status Enabled  | Set-AzureTrafficManagerProfile

         $webendpntExists=Get-AzureRmTrafficManagerEndpoint -Name $TrafficeManagerSecondaryEndPointDomainName -ResourceGroupName $TrafficmanagerResourceGrp -Type AzureEndpoints -ProfileName $Profile.Name -ErrorAction SilentlyContinue

         if($webendpntExists -eq $null)
           {
                $secondarywebappid= Get-AzureRmWebAppSlot -Name $SecondaryWebsite -ResourceGroupName $ResourceGroupsNameSecondary -Slot $SlotName -ErrorAction Stop

                Write-Host "Add-AzureRmTrafficManagerEndpointConfig -EndpointName $TrafficeManagerSecondaryEndPointDomainName -TrafficManagerProfile $Profile -Type AzureEndpoints -EndpointStatus Enabled -TargetResourceId $secondarywebappid.Id -ErrorAction Stop" 
                            Add-AzureRmTrafficManagerEndpointConfig -EndpointName $TrafficeManagerSecondaryEndPointDomainName -TrafficManagerProfile $Profile -Type AzureEndpoints -EndpointStatus Enabled -TargetResourceId $secondarywebappid.Id -ErrorAction Stop
                            Set-AzureRmTrafficManagerProfile -TrafficManagerProfile $Profile -ErrorAction Stop

           } else {Write-Host "Secondary Website [$TrafficeManagerSecondaryEndPointDomainName] is already added as Endpoint to TrafficManager" -ForegroundColor Gray}
              
        }
  }
  Catch [System.Exception]
  {
       
        write-host "Exception Block"
		write-host $_.exception.message
        Exit 1

  }
}


Provision-TrafficManager -JsonFilePath $JsonFilePath -ProvisionAcctName -$ProvisionAcctName -SlotName $SlotName