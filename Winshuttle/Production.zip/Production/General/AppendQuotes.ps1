param(
	[string]$StringValue = $(throw "Pass the StringValue")
)

Function AppendQuotes
{
	try
	{
		$StringValueOut = '`"' + '$StringValue' + '`"'
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

AppendQuotes -StringValue $StringValue




