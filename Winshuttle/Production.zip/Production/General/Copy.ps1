param(
	[string]$Source = $(throw "Pass the Source")
	,[string]$Destination = $(throw "Pass the Destination")
)

Function Copy
{
	try
	{
		Copy-Item $Source -Recurse $Destination
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

Copy -Source $Source -Destination $Destination