param(
	[string]$CommandString = $(throw "Pass the CommandString with required parameters list ")
)

Function RunCmdFile
{
	try
	{
		cmd.exe /c $CommandString
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

RunCmdFile -CommandString $CommandString

