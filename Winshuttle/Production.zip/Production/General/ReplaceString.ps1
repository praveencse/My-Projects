param(
	[string]$ReplaceString = $(throw "Pass the ReplaceString")
   ,[string]$OldValue = $(throw "Pass the OldValue")
   ,[string]$NewValue = $(throw "Pass the NewValue")
)

Function ReplaceString
{
	try
	{
		$DBCONNECTIONSTRING = $ReplaceString -replace $OldValue, $NewValue
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

ReplaceString -ReplaceString $ReplaceString -OldValue $OldValue -NewValue $NewValue