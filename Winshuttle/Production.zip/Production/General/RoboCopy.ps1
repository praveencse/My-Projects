param(
	[string]$Source = $(throw "Pass the Source")
   ,[string]$Destination = $(throw "Pass the Destination")
)

Function RoboCopy
{
	try
	{
		$RESOURCESPATH = "$Source"
		$TARGETDIR = "$Destination"
		$robocmd = "RoboCopy.exe " + "'" + $RESOURCESPATH + "' '" + $TARGETDIR + "' /E"
		Invoke-Expression -command $robocmd
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

RoboCopy -Source $Source -Destination $Destination

