param(
	[string]$Path = $(throw "Pass the Path")
   ,[string]$FileName = $(throw "Pass the FileName")
)

Function ReadXML
{	
	try
	{
		[xml] $list = Get-Content "$Path\$FileName"
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}		
}

ReadXML -Path $Path -FileName $FileName
