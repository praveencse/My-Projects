param([string]$ExePath = $(throw "Pass the Exe path and name"))

Function ExecuteCustomCommand
{
	$LogFile = "RunExecutable.log"
	try
	{
		"Executing file:  $ExePath" | Out-File $LogFile
		& "$ExePath"
		"Finished executing file:  $ExePath" | Out-File $LogFile -Append
	}
	Catch [system.exception]
	{
		write-output $_.exception.message | Out-File $LogFile -Append
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully" | Out-File $LogFile -Append
	}
}

ExecuteCustomCommand -ExePath $ExePath