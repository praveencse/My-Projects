param(
	[string]$ReplaceStringKey = $(throw "Pass the ReplaceStringKey")
  , [string]$ReplaceStringValue = $(throw "Pass the ReplaceStringValue")
)

Function OctopusRunFileUpdate
{
	try
	{
		$octopusRunFileNameFull = $installDir.tostring() + "\run.cmd" 

		$string1 = $ReplaceStringKey

		$string2 = $ReplaceStringValue

		# to support a special characters in the password we need to use $_.replace

		(Get-Content $octopusRunFileNameFull) | Foreach-Object {$_.replace($string1, $string2)} | Set-Content $octopusRunFileNameFull	
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
)

OctopusRunFileUpdate -ReplaceStringKey  $ReplaceStringKey  -ReplaceStringValue  $ReplaceStringValue


