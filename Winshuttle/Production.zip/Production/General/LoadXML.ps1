param(
	[string]$ConfigFileName = $(throw "Pass the ConfigFileName")
)

Function LoadXML
{
	try
	{
		$curentDir = [IO.Directory]::GetCurrentDirectory()

		if($ConfigFileName.Contains("\"))
		{
			 $configurationFileNameFull = $ConfigFileName
		}
		else
		{
			 $configurationFileNameFull = $curentDir + "\" + $ConfigFileName
		}
 
		if (![System.IO.File]::Exists($configurationFileNameFull))  
		{  
			$errorMessage = "Config file does not exists. " + $configurationFileNameFull
			throw $errorMessage
		} 
 
		[System.Xml.XmlDocument] $xd = new-object System.Xml.XmlDocument

		$xd.load($configurationFileNameFull)
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

LoadXML -ConfigFileName $ConfigFileName
