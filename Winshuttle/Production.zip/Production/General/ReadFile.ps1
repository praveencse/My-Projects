param(
	[string]$Path = $(throw "Pass the Path")
   ,[string]$FileName = $(throw "Pass the FileName")
)

Function ReadTextFile
{
	try
	{
		$FileContent = Get-Content $Path\$FileName
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

ReadTextFile -Path $Path -FileName $FileName

