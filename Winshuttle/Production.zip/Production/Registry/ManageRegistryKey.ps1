param(
    [string]$Source = $(throw "Pass the Source")
  , [string]$RegistryKey = $(throw "Pass the RegistryKey")
  , [string]$KeyValue = $(throw "Pass the KeyValue")
)

Function ManageRegistry
{
	try
	{
		New-Item -Path $Source\$RegistryKey -Value "$KeyValue"
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

ManageRegistry -Source $Source -RegistryKey $RegistryKey -KeyValue $KeyValue