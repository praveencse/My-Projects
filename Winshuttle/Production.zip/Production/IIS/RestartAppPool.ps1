param(
	[string[]]$IISPoolList = $(throw "Pass the IISPoolList as common saparated if more than one pool to be set")
)

Function RestartIISAppPool
{
	try
	{
		$IISBox = "$env:computername"
		$s = new-pssession -computer $IISBox

		invoke-command $s {Import-Module WebAdministration}

		foreach ($elem in $IISPoolList)
		{
			invoke-command $s {Restart-WebItem iis:\apppools\$elem}
		}
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

RestartIISAppPool -IISPoolList $IISPoolList
