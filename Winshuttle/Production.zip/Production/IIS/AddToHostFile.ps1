param(
		[string[]]$HostFilePath = $(throw "Pass the HostFileName - Provide full path of this file (C:\Windows\System32\drivers\etc\)")
	   ,[string[]]$HostFileName = $(throw "Pass the HostFileName - (Hosts)")
	   ,[string[]]$IPAddress = $(throw "Pass the IPAddress")
	   ,[string[]]$MappingServerName = $(throw "Pass the MappingServerName")
)

Function AddContentToHostFile
{
	try
	{
		Add-Content $HostFilePath\$HostFileName $IPAddress $MappingServerName
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

AddContentToHostFile -HostFilePath $HostFilePath -HostFileName $HostFileName -IPAddress $IPAddress -MappingServerName $MappingServerName

