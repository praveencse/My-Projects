param(
    [string[]]$EnableWinAuth = $(throw "Pass the EnableWinAuth True / False")
   ,[string[]]$AnonymousAuth = $(throw "Pass the AnonymousAuth True / False")
)

Function SetIISAuthentication
{
	Set APPCMD="%systemroot%\system32\inetsrv\APPCMD"
	%APPCMD% Set Config "Default Web Site/vir_dir" /section:windowsAuthentication /enabled:$EnableWinAuth /commit:apphost
	%APPCMD% Set Config "Default Web Site/vir_dir " /section:AnonymousAuthentication /enabled:$AnonymousAuth /commit:apphost
}

SetIISAuthentication -EnableWinAuth $EnableWinAuth -AnonymousAuth $AnonymousAuth