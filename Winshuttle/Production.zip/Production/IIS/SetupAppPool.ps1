param(
    [string[]]$AppPoolName = $(throw "Pass the AppPoolName")
   ,[string[]]$UserName = $(throw "Pass the UserName")
   ,[string[]]$UserPassword = $(throw "Pass the UserPassword")
   ,[string[]]$Port = $(throw "Pass the Port")
   ,[string[]]$PhysicalPath = $(throw "Pass the PhysicalPath")
)
Function SetAppPool
{
	try
	{
		Set APPCMD="%systemroot%\system32\inetsrv\APPCMD"
		%APPCMD% set config  -section:system.applicationHost/applicationPools /+"[name='$AppPoolName']" /commit:apphost  
		%APPCMD% set apppool /apppool.name:$AppPoolName /managedRuntimeVersion:v4.0
		%APPCMD% set config /section:applicationpools /[Name='$AppPoolName'].managedPipelineMode:Integrated
		%APPCMD% set config /section:applicationPools /[Name='$AppPoolName'].processModel.identityType:SpecificUser /[Name='$AppPoolName '].processModel.userName:$UserName /[name='$AppPoolName '].processModel.password:$UserPassword
		%APPCMD% list site "Default Web Site"
		%APPCMD% add site /name:"Default Web Site" /physicalPath:"$PhysicalPath" /bindings:"http/*:$Port:"
		%APPCMD% set app "Default Web Site/" /applicationPool:$AppPoolName
		%APPCMD% add app /site.name:"Default Web Site" /path:/vir_dir /physicalPath:$PhysicalPath
		%APPCMD% set app /app.name:"Default Web Site/vir_dir" /applicationPool:$AppPoolName
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

SetAppPool -AppPoolName $AppPoolName -UserName $UserName -UserPassword $UserPassword -Port $Port -PhysicalPath $PhysicalPath

