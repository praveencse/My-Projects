param(
	[string]$ShareName = $(throw "Pass the ShareName")
   ,[string]$ServiceAccount = $(throw "Pass the ServiceAccount")
   ,[string]$AccessLevel = $(throw "Pass the AccessLevel")
)

Function CreateFileShare
{
	try
	{	
		$Folder = $ShareName
		$UserAlias = "$ServiceAccount"
		$eone = "$AccessLevel"

		# Testing if folder exist, if not creating folder.
		IF (!(Test-Path c:\$ShareName)) {New-Item c:\$ShareName -type Directory} 
	
		#Providing permission at folder security level
		$FolderPermission = Get-Acl c:\$ShareName

		$AddPermission = New-Object System.Security.AccessControl.FileSystemAccessRule($UserAlias,"FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
		$FolderPermission.AddAccessRule($AddPermission)
		Set-Acl c:\$ShareName $FolderPermission

		# Creating Share and providing folder sharing access
		$CreateShare = '"' +"net share " + '"' + $Folder +'"' + "=" + '"' + "c:\"+ $ShareName + '"' + " /GRANT:" +'"' + $UserAlias + '"' + ",FULL" + " /GRANT:" +'"' + $eone + '"' + ',Read /UNLIMITED /REMARK:' +'"' + $Folder + '"'
	
		cmd.exe /c $CreateShare
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

CreateFileShare -ShareName $ShareName -ServiceAccount $ServiceAccount -AccessLevel $AccessLevel

