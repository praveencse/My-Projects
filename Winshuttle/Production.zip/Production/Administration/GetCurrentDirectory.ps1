Function CreateLogFile
{
	try
	{
		$curentDir = [IO.Directory]::GetCurrentDirectory()
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

GetCurrentDirectory



