param(
	[string]$DirectoryName = $(throw "Pass the DirectoryName")
)

Function CreateDirectory
{
	try
	{
		# Create new directory 
		New-Item $DirectoryName -type directory -force
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

CreateDirectory -DirectoryName $DirectoryName


