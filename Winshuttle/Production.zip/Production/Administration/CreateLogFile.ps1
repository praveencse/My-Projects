param(
	    [string]$LogFileName = $(throw "Pass the LogFileName")
	 )

Function CreateLogFile
{
	try
	{
		$curentDir = [IO.Directory]::GetCurrentDirectory()
 
		if(-not $LogFileName.Contains("\"))
		{
			 $LogFileName = $curentDir + "\" + $LogFileName
		} 

		New-Item -Path $LogFileName -Force -Type File  -ErrorAction "Stop"
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

CreateLogFile -LogFileName $LogFileName

