param(
		[string]$DatabaseName = $(throw "Pass the DatabaseName")
	 )

Function AddCurrentUser
{
	try
	{
		#======================================
		# Deploy Restore database
		#======================================

		$currentUser =  [Security.Principal.WindowsIdentity]::GetCurrent().Name
		write-host "Contest user account:  $currentUser" 

		Write-Host "Add current user to the $DatabaseName db as db_owner role ..."
		$db = $srvr.Databases["$DatabaseName"]

		if ($LASTEXITCODE -eq 1)
		{
			$SQLScript= "IF NOT EXISTS (SELECT * FROM master.sys.syslogins WHERE [Name]= N'" + $currentUser + "') BEGIN  CREATE LOGIN [$currentUser] FROM WINDOWS WITH DEFAULT_DATABASE=[$DatabaseName], DEFAULT_LANGUAGE=[us_english]; END"
		}
		else
		{
			$SQLScript= "IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'" + $currentUser + "') BEGIN DROP USER [$currentUser] END; CREATE USER [$currentUser] FOR LOGIN [" + $currentUser + "];EXEC sp_addrolemember N'db_owner', N'$currentUser';"
		}
		$db.ExecuteNonQuery($SQLScript)
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

AddCurrentUser -DatabaseName $DatabaseName




