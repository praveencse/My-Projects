param(
	[string]$TargetServerName = $(throw "Pass the DatabaseName")
   ,[string]$Drive =  $(throw "Pass the Drive")
)

Function CheckServer
{
	try
	{
		write-host "Cecking if server is reachable..."
		$serverPath = "\\" + $TargetServerName + "\$Drive$"
 
		for ($i=1; $i -le 100; $i++)
		{
			if ($i -eq 99)
			{
				$errorMessage = "Server is not accessible: $targetServerName" 
				throw $errorMessage
			}
		
			Write-Host "Attempt  $i to connect to the server $targetServerName"
		
			if ([System.IO.Directory]::Exists($serverPath)) 
			{
				write-host "Server $targetServerName is validated: OK. "
				return
			}

			write-host "Server is not accessible. Wait (60 sec) for next try..."
			TIMEOUT 60
		}
	}
	Catch [system.exception]
	{
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully"
	}
}

CheckServer -TargetServerName $TargetServerName -Drive $Drive
