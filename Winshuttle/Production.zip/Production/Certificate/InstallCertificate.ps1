param(
		[string]$FILEPATH = $(throw "Pass the File Path"),
		[string]$PASSWORD = $(throw "Pass the Password")
)

Function InstallCertificate
{
	$LogFile = "InstallCertificate.log"

	try
	{
		"certUtil -p $PASSWORD -importPFX $FILEPATH" | Out-File $LogFile
		write-host "certUtil -p $PASSWORD -importPFX $FILEPATH"
		certUtil -p $PASSWORD -importPFX $FILEPATH
	}
	Catch [system.exception]
	{
		write-output $_.exception.message | Out-File $LogFile -Append
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully" | Out-File $LogFile -Append
	}
}

InstallCertificate -FILEPATH $FILEPATH -PASSWORD $PASSWORD