param([string]$GroupName = $(throw "Pass the User Group Name"))

$LogFile = "CreateLocalGroup.log"

Function CreateLocalGroup
{
	try
	{
		$GroupName = $GroupName.split(";")
		for($i=0; $i -lt $groupname.length ; $i++)
		{
			$grp=$groupname[$i]
			NET LocalGroup $grp /ADD
			write-output"The user group " + $grp + " has been added in the server " | Out-File $LogFile
		}
	}
	Catch [system.exception]
	{
		write-output $_.exception.message | Out-File $LogFile -Append
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully" | Out-File $LogFile -Append
	}
}

CreateLocalGroup -GroupName $GroupName