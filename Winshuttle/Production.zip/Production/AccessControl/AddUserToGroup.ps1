param (
		[string] $Group = $(throw "Pass the Group"),
		[string] $AdminUserName = $(throw "Pass the AdminUserName")
      )
      
$LogFile = "AddUserToGroup.log"

Function AddUserToGroup
{      
    try
	{   
		$ComputerName = "$env:computername"
		"Computer Name: $ComputerName" | Out-File $LogFile
		Write-host "Computer Name:" $ComputerName

		[string]$DomainName = ([ADSI]'').name
		"Domain Name: $DomainName" | Out-File $LogFile -Append
		Write-host "Domain Name: $DomainName"

		([ADSI]"WinNT://$ComputerName/$Group,group").Add("WinNT://$DomainName/$AdminUserName")
	}
	Catch [system.exception]
	{
		write-host $_.exception.message | Out-File $LogFile -Append
	}
	Finally
	{
		"Executed Successfully" | Out-File $LogFile -Append
	}
}    
    
AddUserToGroup -Group $Group -AdminUserName $AdminUserName