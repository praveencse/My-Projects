param(
	  [String]$Function = $(throw "Pass the Function"),
	  [String]$TargetDir_Path = $(throw "Pass the Target Directory Path"),
	  [String]$TargetAccount = $(throw "Pass the Target Account"),
	  [String]$Permissions #OPTIONAL
)

Function ManageFolderPermission
{
	try
	{
		$LogFile="ManageFolderPermission.log"

		switch($Function)
		{
			"Remove"
			{
				write-output "icacls.exe $TargetDir_Path /inheritance:d /remove:g $TargetAccount" | Out-File $LogFile
				icacls.exe $TargetDir_Path /inheritance:d /remove:g $TargetAccount
			}
			"Grant"
			{
				if(!$Permissions -eq "")
				{
					write-output "icacls.exe $TargetDir_Path /inheritance:d /grant $TargetAccount`:$Permissions" | Out-File $LogFile
					icacls.exe "$TargetDir_Path" /inheritance:d /grant $TargetAccount`:$Permissions
				}
				else
				{
					write-output "Please provide permissions parameter." | Out-File $LogFile
					write-host "Please provide permissions parameter." 
				}
			}
			"Deny"
			{
				if(!$Permissions -eq "")
				{
					write-output "icacls.exe $TargetDir_Path /inheritance:d /deny $TargetAccount`:$Permissions" | Out-File $LogFile
					icacls.exe "$TargetDir_Path" /inheritance:d /deny $TargetAccount`:$Permissions
				}
				else
				{
					write-output "Please provide permissions parameter." | Out-File $LogFile
					write-host "Please provide permissions parameter."
				}
			}
			default{
				write-host "Please provide proper Function parameter:  Grant, Remove, or Deny" | Out-File $LogFile
			}
		}
	}
	Catch [system.exception]
	{
		write-output $_.exception.message | Out-File $LogFile -Append
		write-host $_.exception.message
	}
	Finally
	{
		"Executed Successfully" | Out-File $LogFile -Append
	}
}

ManageFolderPermission -TargetDir_Path $TargetDir_Path -GroupName $GroupName




